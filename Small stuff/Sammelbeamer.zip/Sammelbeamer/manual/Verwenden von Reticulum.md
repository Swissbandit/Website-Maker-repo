# Verwenden von Reticulum auf Ihrem System 

Reticulum wird nicht als Treiber oder Kernelmodul installiert, wie man
es von einem Netzwerk-Stack erwarten würde. Stattdessen wird Reticulum
als Python-Modul verteilt, das den Netzwerkkern sowie eine Reihe von
Dienstprogrammen und Daemon-Programmen enthält.

Dies bedeutet, dass für die Installation oder Verwendung keine
besonderen Berechtigungen erforderlich sind. Außerdem ist es sehr
leichtgewichtig und lässt sich problemlos auf neue Systeme übertragen
und dort installieren.

Wenn Sie Reticulum installiert haben, wird jedes Programm oder jede
Anwendung, die Reticulum verwendet, beim Start automatisch geladen und
initialisiert, sofern es nicht bereits ausgeführt wird.

In vielen Fällen ist dieser Ansatz ausreichend. Wenn ein Programm
Reticulum verwenden muss, wird es geladen, initialisiert, Schnittstellen
werden aufgerufen und das Programm kann nun über alle verfügbaren
Reticulum-Netzwerke kommunizieren. Wenn ein anderes Programm gestartet
wird und ebenfalls auf dasselbe Reticulum-Netzwerk zugreifen möchte,
wird die bereits laufende Instanz einfach freigegeben. Dies funktioniert
für eine beliebige Anzahl gleichzeitig laufender Programme und ist sehr
einfach zu verwenden, aber je nach Anwendungsfall gibt es auch andere
Optionen.

## Konfiguration & Daten 

Reticulum speichert alle Informationen, die es zum Funktionieren
benötigt, in einem einzigen Dateisystemverzeichnis. Wenn Reticulum
gestartet wird, sucht es an den folgenden Orten nach einem gültigen
Konfigurationsverzeichnis:

- **/etc/reticulum**
- **~/.config/reticulum**
- **~/.reticulum**

Wenn kein vorhandenes Konfigurationsverzeichnis gefunden
wird, **~/.reticulum** wird das Verzeichnis erstellt und die
Standardkonfiguration wird hier automatisch erstellt. Sie können es bei
Bedarf an einen der anderen Speicherorte verschieben.

Es ist auch möglich, völlig beliebige Konfigurationsverzeichnisse zu
verwenden, indem Sie beim Ausführen von Reticulum-basierten Programmen
die entsprechenden Befehlszeilenparameter angeben. Sie können auch
mehrere separate Reticulum-Instanzen auf demselben physischen System
ausführen, entweder isoliert voneinander oder miteinander verbunden.

In den meisten Fällen muss ein einzelnes physisches System nur eine
Reticulum-Instanz ausführen. Diese kann entweder beim Booten als
Systemdienst gestartet oder einfach aufgerufen werden, wenn ein Programm
sie benötigt. In beiden Fällen teilen sich beliebig viele Programme, die
auf demselben System ausgeführt werden, automatisch dieselbe
Reticulum-Instanz, wenn die Konfiguration dies zulässt, was
standardmäßig der Fall ist.

Die gesamte Konfiguration von Reticulum befindet sich in
der **~/.reticulum/config** Datei. Wenn Reticulum zum ersten Mal auf
einem neuen System gestartet wird, wird eine einfache, aber voll
funktionsfähige Konfigurationsdatei erstellt. Die Standardkonfiguration
sieht folgendermaßen aus:

<span id="anchor"></span>\# This is the default Reticulum config file.

\# You should probably edit it to include any additional,

\# interfaces and settings you might need.

\# Only the most basic options are included in this default

\# configuration. To see a more verbose, and much longer,

\# configuration example, you can run the command:

\# rnsd --exampleconfig

**\[**reticulum**\]**

\# If you enable Transport, your system will route traffic

\# for other peers, pass announces and serve path requests.

\# This should only be done for systems that are suited to

\# act as transport nodes, ie. if they are stationary and

\# always-on. This directive is optional and can be removed

\# for brevity.

enable_transport **=** **False**

\# By default, the first program to launch the Reticulum

\# Network Stack will create a shared instance, that other

\# programs can communicate with. Only the shared instance

\# opens all the configured interfaces directly, and other

\# local programs communicate with the shared instance over

\# a local socket. This is completely transparent to the

\# user, and should generally be turned on. This directive

\# is optional and can be removed for brevity.

share_instance **=** Yes

\# If you want to run multiple \*different\* shared instances

\# on the same system, you will need to specify different

\# shared instance ports for each. The defaults are given

\# below, and again, these options can be left out if you

\# don't need them.

shared_instance_port **=** **37428**

instance_control_port **=** **37429**

\# On systems where running instances may not have access

\# to the same shared Reticulum configuration directory,

\# it is still possible to allow full interactivity for

\# running instances, by manually specifying a shared RPC

\# key. In almost all cases, this option is not needed, but

\# it can be useful on operating systems such as Android.

\# The key must be specified as bytes in hexadecimal.

\# rpc_key = e5c032d3ec4e64a6aca9927ba8ab73336780f6d71790

\# You can configure Reticulum to panic and forcibly close

\# if an unrecoverable interface error occurs, such as the

\# hardware device for an interface disappearing. This is

\# an optional directive, and can be left out for brevity.

\# This behaviour is disabled by default.

panic_on_interface_error **=** No

\# When Transport is enabled, it is possible to allow the

\# Transport Instance to respond to probe requests from

\# the rnprobe utility. This can be a useful tool to test

\# connectivity. When this option is enabled, the probe

\# destination will be generated from the Identity of the

\# Transport Instance, and printed to the log at startup.

\# Optional, and disabled by default.

respond_to_probes **=** No

**\[**logging**\]**

\# Valid log levels are 0 through 7:

\# 0: Log only critical information

\# 1: Log errors and lower log levels

\# 2: Log warnings and lower log levels

\# 3: Log notices and lower log levels

\# 4: Log info and lower (this is the default)

\# 5: Verbose logging

\# 6: Debug logging

\# 7: Extreme logging

loglevel **=** **4**

\# The interfaces section defines the physical and virtual

\# interfaces Reticulum will use to communicate on. This

\# section will contain examples for a variety of interface

\# types. You can modify these or use them as a basis for

\# your own config, or simply remove the unused ones.

**\[**interfaces**\]**

*\# This interface enables communication with other*

*\# link-local Reticulum nodes over UDP. It does not*

*\# need any functional IP infrastructure like routers*

*\# or DHCP servers, but will require that at least link-*

*\# local IPv6 is enabled in your operating system, which*

*\# should be enabled by default in almost any OS. See*

*\# the Reticulum Manual for more configuration options.*

**\[\[**Default Interface**\]\]**

type **=** AutoInterface

interface_enabled **=** **True**

Wenn die Reticulum-Infrastruktur lokal bereits vorhanden ist, müssen Sie
wahrscheinlich nichts ändern und sind möglicherweise bereits mit einem
größeren Netzwerk verbunden. Andernfalls müssen Sie der Konfiguration
wahrscheinlich relevante *Schnittstellen* hinzufügen , um mit anderen
Systemen kommunizieren zu können.

Sie können ein viel ausführlicheres Konfigurationsbeispiel generieren,
indem Sie den folgenden Befehl ausführen:

**rnsd --exampleconfig**

Die Ausgabe enthält Beispiele für die meisten von Reticulum
unterstützten Schnittstellentypen sowie zusätzliche Optionen und
Konfigurationsparameter.

Es ist eine gute Idee, die Kommentare und Erklärungen in der obigen
Standardkonfiguration zu lesen. Sie lernen darin die grundlegenden
Konzepte kennen, die Sie verstehen müssen, um Ihr Netzwerk zu
konfigurieren. Wenn Sie das getan haben, werfen Sie einen Blick auf das
Kapitel [„Schnittstellen“](https://reticulum.network/manual/interfaces.html#interfaces-main) in
diesem Handbuch.

## Enthaltene Dienstprogramme 

Reticulum umfasst eine Reihe nützlicher Dienstprogramme sowohl für die
Verwaltung Ihrer Reticulum-Netzwerke als auch für die Ausführung
gängiger Aufgaben über Reticulum-Netzwerke, z. B. das Übertragen von
Dateien auf Remotesysteme und das Remote-Ausführen von Befehlen und
Programmen.

Wenn Sie Reticulum häufig aus mehreren verschiedenen Programmen heraus
verwenden oder einfach möchten, dass Reticulum ständig verfügbar bleibt
(beispielsweise wenn Sie einen Transportknoten hosten), möchten Sie
Reticulum möglicherweise als separaten Dienst ausführen, den andere
Programme, Anwendungen und Dienste nutzen können.

### Das rnsd Utility 

Es ist sehr einfach, Reticulum als Dienst auszuführen. Führen Sie
einfach den enthaltenen **rnsd**Befehl aus. Wenn **rnsd**es ausgeführt
wird, hält es alle konfigurierten Schnittstellen offen, übernimmt den
Transport (sofern aktiviert) und ermöglicht allen anderen Programmen,
das Reticulum-Netzwerk, für das es konfiguriert ist, sofort zu nutzen.

Sie können sogar mehrere Instanzen **rnsd**mit unterschiedlichen
Konfigurationen auf demselben System ausführen.

**Anwendungsbeispiele**

Laufen **rnsd**:

<span id="anchor-1"></span>$ rnsd

\[2023-08-18 17:59:56\] \[Notice\] Started rnsd version 0.5.8

Führen Sie die Ausführung **rnsd**im Servicemodus aus und stellen Sie
sicher, dass die gesamte Protokollausgabe direkt an die Datei gesendet
wird:

<span id="anchor-2"></span>$ rnsd -s

Generieren Sie ein ausführliches und detailliertes
Konfigurationsbeispiel mit Erklärungen aller verschiedenen
Konfigurationsoptionen und Beispielen für die
Schnittstellenkonfiguration:

<span id="anchor-3"></span>$ rnsd --exampleconfig

**Alle Befehlszeilenoptionen**

<span id="anchor-4"></span>usage: rnsd.py \[-h\] \[--config CONFIG\]
\[-v\] \[-q\] \[-s\] \[--exampleconfig\] \[--version\]

Reticulum Network Stack Daemon

options:

-h, --help show this help message and exit

--config CONFIG path to alternative Reticulum config directory

-v, --verbose

-q, --quiet

-s, --service rnsd is running as a service and should log to file

--exampleconfig print verbose configuration example to stdout and exit

--version show program's version number and exit

Sie können es ganz einfach **rnsd**als ständig verfügbaren Dienst
hinzufügen, indem Sie [einen Dienst
konfigurieren](https://reticulum.network/manual/using.html#using-systemd) .

### Das rnstatus-Dienstprogramm 

Mit dem **rnstatus**Dienstprogramm können Sie den Status der
konfigurierten Reticulum-Schnittstellen anzeigen, ähnlich wie
im **ifconfig**Programm.

**Anwendungsbeispiele**

Laufen **rnstatus**:

<span id="anchor-5"></span>$ rnstatus

Shared Instance\[37428\]

Status : Up

Serving : 1 program

Rate : 1.00 Gbps

Traffic : 83.13 KB↑

86.10 KB↓

AutoInterface\[Local\]

Status : Up

Mode : Full

Rate : 10.00 Mbps

Peers : 1 reachable

Traffic : 63.23 KB↑

80.17 KB↓

TCPInterface\[RNS Testnet Dublin/dublin.connect.reticulum.network:4965\]

Status : Up

Mode : Full

Rate : 10.00 Mbps

Traffic : 187.27 KB↑

74.17 KB↓

RNodeInterface\[RNode UHF\]

Status : Up

Mode : Access Point

Rate : 1.30 kbps

Access : 64-bit IFAC by \<…e702c42ba8\>

Traffic : 8.49 KB↑

9.23 KB↓

Reticulum Transport Instance \<5245a8efe1788c6a1cd36144a270e13b\>
running

Filtern Sie die Ausgabe, um nur einige Schnittstellen anzuzeigen:

<span id="anchor-6"></span>$ rnstatus rnode

RNodeInterface\[RNode UHF\]

Status : Up

Mode : Access Point

Rate : 1.30 kbps

Access : 64-bit IFAC by \<…e702c42ba8\>

Traffic : 8.49 KB↑

9.23 KB↓

Reticulum Transport Instance \<5245a8efe1788c6a1cd36144a270e13b\>
running

**Alle Befehlszeilenoptionen**

<span id="anchor-7"></span>usage: rnstatus.py \[-h\] \[--config CONFIG\]
\[--version\] \[-a\] \[-A\] \[-s SORT\]

\[-r\] \[-j\] \[-v\] \[filter\]

Reticulum Network Stack Status

positional arguments:

filter only display interfaces with names including filter

options:

-h, --help show this help message and exit

--config CONFIG path to alternative Reticulum config directory

--version show program's version number and exit

-a, --all show all interfaces

-A, --announce-stats show announce stats

-s SORT, --sort SORT sort interfaces by \[rate, traffic, rx, tx,
announces, arx, atx, held\]

-r, --reverse reverse sorting

-j, --json output in JSON format

-v, --verbose

### Das rnid-Dienstprogramm 

Mit dem **rnid**Dienstprogramm können Sie Reticulum-Identitäten
generieren, verwalten und anzeigen. Das Programm kann auch Ziel-Hashes
berechnen und Dateien ver- und entschlüsseln.

Mithilfe von **rnid**ist es möglich, Dateien und Informationen für jeden
Reticulum-Ziel-Hash asymmetrisch zu verschlüsseln und auch
kryptografische Signaturen zu erstellen und zu überprüfen.

**Anwendungsbeispiele**

Generieren Sie eine neue Identität:

<span id="anchor-8"></span>$ rnid -g ./new_identity

Identitätsschlüsselinformationen anzeigen:

<span id="anchor-9"></span>$ rnid -i ./new_identity -p

Loaded Identity \<984b74a3f768bef236af4371e6f248cd\> from new_id

Public Key :
0f4259fef4521ab75a3409e353fe9073eb10783b4912a6a9937c57bf44a62c1e

Private Key : Hidden

Verschlüsseln Sie eine Datei für einen LXMF-Benutzer:

<span id="anchor-10"></span>$ rnid -i 8dd57a738226809646089335a6b03695
-e my_file.txt

Recalled Identity \<bc7291552be7a58f361522990465165c\> for destination
\<8dd57a738226809646089335a6b03695\>

Encrypting my_file.txt

File my_file.txt encrypted for \<bc7291552be7a58f361522990465165c\> to
my_file.txt.rfe

Wenn die Identität für das Ziel noch nicht bekannt ist, können Sie sie
mithilfe der **-R**Befehlszeilenoption aus dem Netzwerk abrufen:

<span id="anchor-11"></span>$ rnid -R -i
30602def3b3506a28ed33db6f60cc6c9 -e my_file.txt

Requesting unknown Identity for \<30602def3b3506a28ed33db6f60cc6c9\>...

Received Identity \<2b489d06eaf7c543808c76a5332a447d\> for destination
\<30602def3b3506a28ed33db6f60cc6c9\> from the network

Encrypting my_file.txt

File my_file.txt encrypted for \<2b489d06eaf7c543808c76a5332a447d\> to
my_file.txt.rfe

Entschlüsseln Sie eine Datei mithilfe der Reticulum-Identität, für die
sie verschlüsselt wurde:

<span id="anchor-12"></span>$ rnid -i ./my_identity -d my_file.txt.rfe

Loaded Identity \<2225fdeecaf6e2db4556c3c2d7637294\> from ./my_identity

Decrypting ./my_file.txt.rfe...

File ./my_file.txt.rfe decrypted with
\<2225fdeecaf6e2db4556c3c2d7637294\> to ./my_file.txt

**Alle Befehlszeilenoptionen**

<span id="anchor-13"></span>usage: rnid.py \[-h\] \[--config path\] \[-i
identity\] \[-g path\] \[-v\] \[-q\] \[-a aspects\]

\[-H aspects\] \[-e path\] \[-d path\] \[-s path\] \[-V path\] \[-r
path\] \[-w path\]

\[-f\] \[-R\] \[-t seconds\] \[-p\] \[-P\] \[--version\]

Reticulum Identity & Encryption Utility

options:

-h, --help show this help message and exit

--config path path to alternative Reticulum config directory

-i identity, --identity identity

hexadecimal Reticulum Destination hash or path to Identity file

-g path, --generate path

generate a new Identity

-v, --verbose increase verbosity

-q, --quiet decrease verbosity

-a aspects, --announce aspects

announce a destination based on this Identity

-H aspects, --hash aspects

show destination hashes for other aspects for this Identity

-e path, --encrypt path

encrypt file

-d path, --decrypt path

decrypt file

-s path, --sign path sign file

-V path, --validate path

validate signature

-r path, --read path input file path

-w path, --write path

output file path

-f, --force write output even if it overwrites existing files

-R, --request request unknown Identities from the network

-t seconds identity request timeout before giving up

-p, --print-identity print identity info and exit

-P, --print-private allow displaying private keys

--version show program's version number and exit

### Das rnpath-Dienstprogramm 

Mit dem **rnpath**Dienstprogramm können Sie Pfade für Ziele im
Reticulum-Netzwerk nachschlagen und anzeigen.

**Anwendungsbeispiele**

Pfad zu einem Ziel auflösen:

<span id="anchor-14"></span>$ rnpath c89b4da064bf66d280f0e4d8abfd9806

Path found, destination \<c89b4da064bf66d280f0e4d8abfd9806\> is 4 hops
away via \<f53a1c4278e0726bb73fcc623d6ce763\> on
TCPInterface\[Testnet/dublin.connect.reticulum.network:4965\]

**Alle Befehlszeilenoptionen**

<span id="anchor-15"></span>usage: rnpath.py \[-h\] \[--config CONFIG\]
\[--version\] \[-t\] \[-r\] \[-d\] \[-D\]

\[-x\] \[-w seconds\] \[-v\] \[destination\]

Reticulum Path Discovery Utility

positional arguments:

destination hexadecimal hash of the destination

options:

-h, --help show this help message and exit

--config CONFIG path to alternative Reticulum config directory

--version show program's version number and exit

-t, --table show all known paths

-r, --rates show announce rate info

-d, --drop remove the path to a destination

-D, --drop-announces drop all queued announces

-x, --drop-via drop all paths via specified transport instance

-w seconds timeout before giving up

-v, --verbose

### Das rnprobe-Dienstprogramm 

Mit dem **rnprobe**Dienstprogramm können Sie ein Ziel auf Konnektivität
prüfen, ähnlich wie mit dem **ping**Programm. Bitte beachten Sie, dass
Tests nur beantwortet werden, wenn das angegebene Ziel so konfiguriert
ist, dass es Nachweise für empfangene Pakete sendet. Bei vielen Zielen
ist diese Option nicht aktiviert, daher sind die meisten Ziele nicht
wahrscheinlich.

Sie können ein Testantwortziel auf Reticulum-Transportinstanzen
aktivieren, indem Sie die **respond_to_probes**Konfigurationsanweisung
festlegen. Reticulum druckt dann das Testziel beim Start der
Transportinstanz in das Protokoll.

**Anwendungsbeispiele**

Prüfen Sie ein Ziel:

<span id="anchor-16"></span>$ rnprobe rnstransport.probe
2d03725b327348980d570f739a3a5708

Sent 16 byte probe to \<2d03725b327348980d570f739a3a5708\>

Valid reply received from \<2d03725b327348980d570f739a3a5708\>

Round-trip time is 38.469 milliseconds over 2 hops

Senden Sie eine größere Sonde:

<span id="anchor-17"></span>$ rnprobe rnstransport.probe
2d03725b327348980d570f739a3a5708 -s 256

Sent 16 byte probe to \<2d03725b327348980d570f739a3a5708\>

Valid reply received from \<2d03725b327348980d570f739a3a5708\>

Round-trip time is 38.781 milliseconds over 2 hops

Wenn die Schnittstelle, die die Testantworten empfängt, die Meldung von
Funkparametern wie **RSSI** und **SNR** unterstützt , druckt
das **rnprobe**Dienstprogramm diese ebenfalls als Teil des Ergebnisses
aus.

<span id="anchor-18"></span>$ rnprobe rnstransport.probe
e7536ee90bd4a440e130490b87a25124

Sent 16 byte probe to \<e7536ee90bd4a440e130490b87a25124\>

Valid reply received from \<e7536ee90bd4a440e130490b87a25124\>

Round-trip time is 1.809 seconds over 1 hop \[RSSI -73 dBm\] \[SNR 12.0
dB\]

**Alle Befehlszeilenoptionen**

<span id="anchor-19"></span>usage: rnprobe \[-h\] \[--config CONFIG\]
\[--version\] \[-v\] \[-s SIZE\]

\[full_name\] \[destination_hash\]

Reticulum Probe Utility

positional arguments:

full_name full destination name in dotted notation

destination_hash hexadecimal hash of the destination

optional arguments:

-h, --help show this help message and exit

--config CONFIG path to alternative Reticulum config directory

-s SIZE, --size SIZE size of probe packet payload in bytes

--version show program's version number and exit

-v, --verbose

### Das rncp-Dienstprogramm 

Das **rncp**Dienstprogramm ist ein einfaches Dateiübertragungstool.
Damit können Sie Dateien über Reticulum übertragen.

**Anwendungsbeispiele**

Führen Sie rncp auf dem empfangenden System aus und geben Sie an, welche
Identitäten Dateien senden dürfen:

<span id="anchor-20"></span>$ rncp --listen -a
1726dbad538775b5bf9b0ea25a4079c8 -a c50cc4e4f7838b6c31f60ab9032cbc62

Sie können zulässige Identitäts-Hashes (einen pro Zeile) auch in der
Datei ~/.rncp/allowed_identities angeben und das Programm einfach im
Listener-Modus ausführen:

<span id="anchor-21"></span>$ rncp --listen

Kopieren Sie eine Datei von einem anderen System auf das Empfangssystem:

<span id="anchor-22"></span>$ rncp ~/path/to/file.tgz
73cbd378bb0286ed11a707c13447bb1e

Oder holen Sie eine Datei vom Remote-System:

<span id="anchor-23"></span>$ rncp --fetch ~/path/to/file.tgz
73cbd378bb0286ed11a707c13447bb1e

**Alle Befehlszeilenoptionen**

<span id="anchor-24"></span>usage: rncp.py \[-h\] \[--config path\]
\[-v\] \[-q\] \[-S\] \[-l\] \[-f\] \[-b seconds\]

\[-a allowed_hash\] \[-n\] \[-p\] \[-w seconds\] \[--version\] \[file\]
\[destination\]

Reticulum File Transfer Utility

positional arguments:

file file to be transferred

destination hexadecimal hash of the receiver

options:

-h, --help show this help message and exit

--config path path to alternative Reticulum config directory

-v, --verbose increase verbosity

-q, --quiet decrease verbosity

-S, --silent disable transfer progress output

-l, --listen listen for incoming transfer requests

-f, --fetch fetch file from remote listener instead of sending

-b seconds announce interval, 0 to only announce at startup

-a allowed_hash accept from this identity

-n, --no-auth accept files and fetches from anyone

-p, --print-identity print identity and destination info and exit

-w seconds sender timeout before giving up

--version show program's version number and exit

### Das rnx-Dienstprogramm 

Das Dienstprogramm ist ein grundlegendes Programm zur
Remote-Befehlsausführung. Es ermöglicht Ihnen, Befehle auf
Remote-Systemen über Reticulum auszuführen und die zurückgegebene
Befehlsausgabe anzuzeigen. Für eine vollständig interaktive
Remote-Shell-Lösung sollten Sie sich auch
das [rnsh](https://github.com/acehoss/rnsh)**rnx** -Programm ansehen .

**Anwendungsbeispiele**

Führen Sie rnx auf dem Abhörsystem aus und geben Sie an, welche
Identitäten Befehle ausführen dürfen:

<span id="anchor-25"></span>$ rnx --listen -a
941bed5e228775e5a8079fc38b1ccf3f -a 1b03013c25f1c2ca068a4f080b844a10

Führen Sie von einem anderen System aus einen Befehl auf der
Fernbedienung aus:

<span id="anchor-26"></span>$ rnx 7a55144adf826958a9529a3bcf08b149 "cat
/proc/cpuinfo"

Oder rufen Sie die Pseudo-Shell im interaktiven Modus auf:

<span id="anchor-27"></span>$ rnx 7a55144adf826958a9529a3bcf08b149 -x

Die Standardidentitätsdatei ist in
gespeichert **~/.reticulum/identities/rnx**, Sie können jedoch eine
andere verwenden, die erstellt wird, wenn sie noch nicht vorhanden ist.

<span id="anchor-28"></span>$ rnx 7a55144adf826958a9529a3bcf08b149 -i
/path/to/identity -x

**Alle Befehlszeilenoptionen**

<span id="anchor-29"></span>usage: rnx \[-h\] \[--config path\] \[-v\]
\[-q\] \[-p\] \[-l\] \[-i identity\] \[-x\] \[-b\] \[-n\] \[-N\]

\[-d\] \[-m\] \[-a allowed_hash\] \[-w seconds\] \[-W seconds\]
\[--stdin STDIN\]

\[--stdout STDOUT\] \[--stderr STDERR\] \[--version\] \[destination\]
\[command\]

Reticulum Remote Execution Utility

positional arguments:

destination hexadecimal hash of the listener

command command to be execute

optional arguments:

-h, --help show this help message and exit

--config path path to alternative Reticulum config directory

-v, --verbose increase verbosity

-q, --quiet decrease verbosity

-p, --print-identity print identity and destination info and exit

-l, --listen listen for incoming commands

-i identity path to identity to use

-x, --interactive enter interactive mode

-b, --no-announce don't announce at program start

-a allowed_hash accept from this identity

-n, --noauth accept files from anyone

-N, --noid don't identify to listener

-d, --detailed show detailed result output

-m mirror exit code of remote command

-w seconds connect and request timeout before giving up

-W seconds max result download time

--stdin STDIN pass input to stdin

--stdout STDOUT max size in bytes of returned stdout

--stderr STDERR max size in bytes of returned stderr

--version show program's version number and exit

### Das Dienstprogramm rnodeconf 

Mit dem Dienstprogramm können Sie
vorhandene [RNodes](https://reticulum.network/manual/hardware.html#rnode-main)**rnodeconf** prüfen
und konfigurieren sowie
neue [RNodes](https://reticulum.network/manual/hardware.html#rnode-main) von
allen unterstützten Hardwaregeräten erstellen und bereitstellen .

**Alle Befehlszeilenoptionen**

<span id="anchor-30"></span>usage: rnodeconf.py \[-h\] \[-i\] \[-a\]
\[-u\] \[-U\] \[--fw-version version\] \[--nocheck\] \[-e\]

\[-E\] \[-C\] \[--baud-flash baud_flash\] \[-N\] \[-T\] \[-b\] \[-B\]
\[-p\] \[-D i\]

\[--freq Hz\] \[--bw Hz\] \[--txp dBm\] \[--sf factor\] \[--cr rate\]

\[--eeprom-backup\] \[--eeprom-dump\] \[--eeprom-wipe\] \[-P\]

\[--trust-key hexbytes\] \[--version\] \[port\]

RNode Configuration and firmware utility. This program allows you to
change various

settings and startup modes of RNode. It can also install, flash and
update the firmware

on supported devices.

positional arguments:

port serial port where RNode is attached

options:

-h, --help show this help message and exit

-i, --info Show device info

-a, --autoinstall Automatic installation on various supported devices

-u, --update Update firmware to the latest version

-U, --force-update Update to specified firmware even if version matches
or is older than installed version

--fw-version version Use a specific firmware version for update or
autoinstall

--nocheck Don't check for firmware updates online

-e, --extract Extract firmware from connected RNode for later use

-E, --use-extracted Use the extracted firmware for autoinstallation or
update

-C, --clear-cache Clear locally cached firmware files

--baud-flash baud_flash

Set specific baud rate when flashing device. Default is 921600

-N, --normal Switch device to normal mode

-T, --tnc Switch device to TNC mode

-b, --bluetooth-on Turn device bluetooth on

-B, --bluetooth-off Turn device bluetooth off

-p, --bluetooth-pair Put device into bluetooth pairing mode

-D i, --display i Set display intensity (0-255)

--freq Hz Frequency in Hz for TNC mode

--bw Hz Bandwidth in Hz for TNC mode

--txp dBm TX power in dBm for TNC mode

--sf factor Spreading factor for TNC mode (7 - 12)

--cr rate Coding rate for TNC mode (5 - 8)

--eeprom-backup Backup EEPROM to file

--eeprom-dump Dump EEPROM to console

--eeprom-wipe Unlock and wipe EEPROM

-P, --public Display public part of signing key

--trust-key hexbytes Public key to trust for device verification

--version Print program version and exit

Weitere Informationen zum Erstellen eigener RNodes finden Sie im
Abschnitt [„RNodes
erstellen“](https://reticulum.network/manual/hardware.html#rnode-creating) dieses
Handbuchs.

## Verbesserung der Systemkonfiguration 

Wenn Sie ein System für den dauerhaften Einsatz mit Reticulum
einrichten, können einige Änderungen an der Systemkonfiguration die
Verwaltung erleichtern. Diese Änderungen werden hier ausführlich
beschrieben.

### Feste serielle Portnamen 

Bei einer Reticulum-Instanz mit mehreren seriellen Schnittstellen kann
es von Vorteil sein, die festen Gerätenamen für die seriellen
Schnittstellen zu verwenden, anstatt der dynamisch zugewiesenen
Abkürzungen wie **/dev/ttyUSB0**. Unter den meisten Debian-basierten
Distributionen, einschließlich Ubuntu und Raspberry Pi OS, sind diese
Knoten unter zu finden **/dev/serial/by-id**.

Sie können einen solchen Gerätepfad direkt anstelle der nummerierten
Abkürzungen verwenden. Hier ist ein Beispiel für ein so konfiguriertes
Packet Radio TNC:

<span id="anchor-31"></span>\[\[Packet Radio KISS Interface\]\]

type = KISSInterface

interface_enabled = True

outgoing = true

port = /dev/serial/by-id/usb-FTDI_FT230X_Basic_UART_43891CKM-if00-port0

speed = 115200

databits = 8

parity = none

stopbits = 1

preamble = 150

txtail = 10

persistence = 200

slottime = 20

Durch die Verwendung dieser Methode werden mögliche Verwechslungen bei
der Benennung vermieden, wenn physische Geräte in unterschiedlicher
Reihenfolge ein- und ausgesteckt werden oder wenn die Gerätenamen von
einem Systemstart zum anderen unterschiedlich vergeben werden.

### <span id="anchor-32"></span>Reticulum als Systemdienst 

Anstatt Reticulum manuell zu starten, können Sie es **rnsd**als
Systemdienst installieren und beim Booten automatisch starten lassen.

#### Systemweiter Service 

Wenn Sie Reticulum mit installiert haben **pip**, befindet sich
das **rnsd**Programm höchstwahrscheinlich nur in einem lokalen
Benutzerinstallationspfad, was bedeutet, dass **systemd**es nicht
ausgeführt werden kann. In diesem Fall können Sie das **rnsd**Programm
einfach mit einem symbolischen Link in ein Verzeichnis im Pfad von
systemd verknüpfen:

<span id="anchor-33"></span>sudo ln -s $(which rnsd) /usr/local/bin/

Anschließend können Sie die
Servicedatei **/etc/systemd/system/rnsd.service**mit folgendem Inhalt
erstellen:

<span id="anchor-34"></span>\[Unit\]

Description=Reticulum Network Stack Daemon

After=multi-user.target

\[Service\]

\# If you run Reticulum on WiFi devices,

\# or other devices that need some extra

\# time to initialise, you might want to

\# add a short delay before Reticulum is

\# started by systemd:

\# ExecStartPre=/bin/sleep 10

Type=simple

Restart=always

RestartSec=3

User=USERNAMEHERE

ExecStart=rnsd --service

\[Install\]

WantedBy=multi-user.target

Ersetzen Sie es unbedingt **USERNAMEHERE**durch den Benutzer, als der
Sie die Ausführung durchführen möchten **rnsd**.

So starten Sie den Lauf manuell **rnsd**:

<span id="anchor-35"></span>sudo systemctl start rnsd

**rnsd**Wenn Sie beim Booten automatisch starten möchten , führen Sie
Folgendes aus:

<span id="anchor-36"></span>sudo systemctl enable rnsd

#### Userspace-Dienst 

Alternativ können Sie anstelle eines systemweiten Dienstes einen
Benutzer-Systemd-Dienst verwenden. Auf diese Weise kann die gesamte
Einrichtung als normaler Benutzer durchgeführt werden. Erstellen Sie
eine
Benutzer-Systemd-Dienstdatei **~/.config/systemd/user/rnsd.service**mit
folgendem Inhalt:

<span id="anchor-37"></span>\[Unit\]

Description=Reticulum Network Stack Daemon

After=default.target

\[Service\]

\# If you run Reticulum on WiFi devices,

\# or other devices that need some extra

\# time to initialise, you might want to

\# add a short delay before Reticulum is

\# started by systemd:

\# ExecStartPre=/bin/sleep 10

Type=simple

Restart=always

RestartSec=3

ExecStart=RNS_BIN_DIR/rnsd --service

\[Install\]

WantedBy=default.target

Ersetzen Sie es **RNS_BIN_DIR**durch den Pfad zu Ihrem
Reticulum-Binärverzeichnis (z. B. /home/BENUTZERNAMEHIER/rns/bin).

Benutzerdienst starten:

<span id="anchor-38"></span>systemctl --user daemon-reload

systemctl --user start rnsd.service

Wenn Sie automatisch starten möchten, **rnsd**ohne sich als USERNAMEHERE
anmelden zu müssen, gehen Sie wie folgt vor:

<span id="anchor-39"></span>sudo loginctl enable-linger USERNAMEHERE

systemctl --user enable rnsd.service
