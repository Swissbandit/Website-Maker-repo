# Unterstütze Reticulum 

Sie können die kontinuierliche Entwicklung offener, freier und privater
Kommunikationssysteme unterstützen, indem Sie spenden, Feedback geben
und Code und Lernressourcen beisteuern.

## Spenden 

Spenden werden über die folgenden Kanäle dankbar entgegengenommen:

<span id="anchor"></span>Monero:

84FpY1QbxHcgdseePYNmhTHcrgMX4nFfBYtz2GKYToqHVVhJp8Eaw1Z1EedRnKD19b3B8NiLCGVxzKV17UMmmeEsCrPyA5w

Ethereum:

0x81F7B979fEa6134bA9FD5c701b3501A2e61E897a

Bitcoin:

3CPmacGm34qYvR6XWLVEJmi2aNe3PZqUuq

Ko-Fi:

https://ko-fi.com/markqvist

Sind bestimmte Features in der Entwicklungs-Roadmap für Sie oder Ihre
Organisation wichtig? Machen Sie sie schnell zur Realität, indem Sie
ihre Implementierung sponsern.

## Rückmeldung geben 

Alle Rückmeldungen zur Nutzung, Funktionsweise und möglichen
Fehlfunktionen aller Systemkomponenten sind für die kontinuierliche
Entwicklung und Verbesserung von Reticulum sehr wertvoll. Reticulum
sammelt und meldet unter keinen Umständen automatisierte Analysen,
Telemetriedaten, Fehlerberichte oder Statistiken, daher verlassen wir
uns auf altmodisches menschliches Feedback.

## Code beitragen 

Besuchen Sie uns
im [GitHub-Repository,](https://github.com/markqvist/reticulum) um
Probleme zu melden, Funktionen vorzuschlagen und Code zu Reticulum
beizutragen.
