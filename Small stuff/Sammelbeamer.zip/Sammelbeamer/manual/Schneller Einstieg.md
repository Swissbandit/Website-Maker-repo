# Schneller Einstieg 

Der beste Weg, mit dem Reticulum Network Stack zu beginnen, hängt davon
ab, was Sie tun möchten. In diesem Handbuch werden sinnvolle Startpfade
für verschiedene Szenarien beschrieben.

## Standalone-Reticulum-Installation 

Wenn Sie Reticulum und zugehörige Dienstprogramme einfach auf einem
System installieren möchten, geht das am einfachsten über
den **pip**Paketmanager:

<span id="anchor"></span>pip install rns

Wenn Sie pip noch nicht installiert haben, können Sie es mithilfe des
Paketmanagers Ihres Systems mit einem Befehl wie oder einem ähnlichen
installieren.**sudo apt install python3-pipsudo pamac install python-pip**

Sie können die Reticulum-Release-Wheels auch von GitHub oder anderen
Release-Kanälen herunterladen und sie offline installieren mit **pip**:

<span id="anchor-1"></span>pip install
**./**rns**-0.5.1-**py3**-**none**-**any**.**whl

## Beheben von Abhängigkeits- und Installationsproblemen 

Auf einigen Plattformen sind möglicherweise nicht für alle
Abhängigkeiten Binärpakete verfügbar, und **pip**die Installation
schlägt möglicherweise mit einer Fehlermeldung fehl. In diesen Fällen
kann das Problem normalerweise behoben werden, indem Sie die
Entwicklungspakete für Ihre Plattform installieren:

<span id="anchor-2"></span>\# Debian / Ubuntu / Derivatives

sudo apt install build**-**essential

\# Arch / Manjaro / Derivatives

sudo pamac install base**-**devel

\# Fedora

sudo dnf groupinstall "Development Tools" "Development Libraries"

Wenn die grundlegenden Entwicklungspakete installiert
sind, **pip**sollten alle fehlenden Abhängigkeiten aus der Quelle
kompiliert werden können und die Installation sollte auch auf
Plattformen abgeschlossen werden können, für die keine vorkompilierten
Pakete verfügbar sind.

## Versuchen Sie es mit einem Reticulum-basierten Programm 

Wenn Sie einfach ein mit Reticulum erstelltes Programm ausprobieren
möchten, stehen Ihnen einige verschiedene Programme zur Verfügung, die
eine grundlegende Kommunikation und eine Reihe anderer nützlicher
Funktionen ermöglichen, sogar über Reticulum-Netzwerke mit extrem
geringer Bandbreite.

Mit diesen Programmen bekommen Sie ein Gefühl dafür, wie Reticulum
funktioniert. Sie wurden für den Betrieb über Netzwerke auf Basis von
LoRa oder Packet Radio entwickelt, können aber auch über schnelle
Verbindungen wie lokales WLAN, kabelgebundenes Ethernet, das Internet
oder eine beliebige Kombination davon verwendet werden.

So kann man ganz einfach mit dem Experimentieren beginnen, ohne dass man
zum Ausprobieren Funktransceiver oder Infrastruktur einrichten muss. Für
den Anfang reicht es aus, die Programme auf separaten Geräten zu
starten, die mit demselben WLAN-Netzwerk verbunden sind. Physische
Funkschnittstellen können dann später hinzugefügt werden.

### Remote-Shell 

Mit dem Programm [rnsh](https://github.com/acehoss/rnsh) können Sie
vollständig interaktive Remote-Shell-Sitzungen über Reticulum
einrichten. Sie können damit auch jedes Programm von oder zu einem
Remote-System leiten und es **ssh**funktioniert ähnlich wie . Das
Programm **rnsh**ist sehr effizient und kann vollständig interaktive
Shell-Sitzungen ermöglichen, sogar über Verbindungen mit extrem geringer
Bandbreite.

### Nomadennetzwerk 

Das terminalbasierte Programm [Nomad
Network](https://github.com/markqvist/nomadnet) bietet eine vollständige
Suite verschlüsselter Kommunikation, die mit Reticulum erstellt wurde.
Es bietet verschlüsselte Nachrichten (sowohl direkte als auch verzögerte
Zustellung für Offline-Benutzer), Dateifreigabe und verfügt über einen
integrierten Textbrowser und Seitenserver mit Unterstützung für
dynamisch gerenderte Seiten, Benutzerauthentifizierung und mehr.

[Nomad Network](https://github.com/markqvist/nomadnet) ist ein
benutzerorientierter Client für das Messaging- und
Informationsaustauschprotokoll [LXMF](https://github.com/markqvist/lxmf) ,
ein weiteres mit Reticulum erstelltes Projekt.

Sie können Nomad Network über Pip installieren:

<span id="anchor-3"></span>\# Install ...

pip install nomadnet

\# ... and run

nomadnet

**Bitte beachten** : Wenn Sie pip zum ersten Mal verwenden, um ein
Programm auf Ihrem System zu installieren, müssen Sie Ihr System
möglicherweise neu starten, damit das Programm verfügbar wird. Wenn beim
Ausführen des Programms die Fehlermeldung „Befehl nicht gefunden“ oder
ähnliches angezeigt wird, starten Sie Ihr System neu und versuchen Sie
es erneut.

### Seitenband 

[Wenn Sie lieber ein Programm mit grafischer Benutzeroberfläche
verwenden möchten, können Sie sich
Sideband](https://unsigned.io/sideband) ansehen , das für Android, Linux
und macOS verfügbar ist.

Sideband ermöglicht Ihnen die Kommunikation mit anderen Personen oder
LXMF-kompatiblen Systemen über Reticulum-Netzwerke mithilfe von LoRa,
Packet Radio, WiFi, I2P, verschlüsselten QR-Papiernachrichten oder allem
anderen, was Reticulum unterstützt. Es ist auch mit dem Nomad
Network-Programm kompatibel.

## Verwenden der enthaltenen Dienstprogramme 

Reticulum wird mit einer Reihe integrierter Dienstprogramme geliefert,
die die Verwaltung Ihres Netzwerks erleichtern, die Konnektivität
überprüfen und Reticulum anderen Programmen auf Ihrem System zur
Verfügung stellen.

Sie können **rnsd**Reticulum als Hintergrund- oder Vordergrunddienst
ausführen und die , **rnstatus**und **rnpath**Dienstprogramme
verwenden **rnprobe**, um Netzwerkstatus und Konnektivität anzuzeigen
und abzufragen.

Weitere Informationen zu diesen Dienstprogrammen finden Sie im
Kapitel [„Verwenden von Reticulum auf Ihrem
System“](https://reticulum.network/manual/using.html#using-main) in
diesem Handbuch.

## Erstellen eines Netzwerks mit Reticulum 

Um ein Netzwerk zu erstellen, müssen Sie eine oder
mehrere *Schnittstellen* angeben , die Reticulum verwenden soll. Dies
geschieht in der Reticulum-Konfigurationsdatei, die sich standardmäßig
unter befindet **~/.reticulum/config**. Eine Beispielkonfigurationsdatei
mit allen Optionen erhalten Sie über .**rnsd --exampleconfig**

Wenn Reticulum zum ersten Mal gestartet wird, wird eine
Standardkonfigurationsdatei mit einer aktiven Schnittstelle erstellt.
Diese Standardschnittstelle verwendet Ihre vorhandenen Ethernet- und
WiFi-Netzwerke (sofern vorhanden) und ermöglicht Ihnen nur die
Kommunikation mit anderen Reticulum-Peers innerhalb Ihrer lokalen
Broadcast-Domänen.

Um weiter kommunizieren zu können, müssen Sie eine oder mehrere
Schnittstellen hinzufügen. Die Standardkonfiguration umfasst eine Reihe
von Beispielen, von der Verwendung von TCP über das Internet bis hin zu
LoRa- und Packet Radio-Schnittstellen.

Mit Reticulum müssen Sie nur die Schnittstellen konfigurieren, über die
Sie kommunizieren möchten. Adressräume, Subnetze, Routing-Tabellen oder
andere Dinge, die Sie möglicherweise von anderen Netzwerktypen gewohnt
sind, müssen nicht konfiguriert werden.

Sobald Reticulum weiß, welche Schnittstellen es verwenden soll, erkennt
es automatisch die Topographie und konfiguriert den Datentransport zu
allen bekannten Zielen.

In Situationen, in denen Sie bereits über ein etabliertes WLAN- oder
Ethernet-Netzwerk verfügen und viele Geräte dieselben externen
Reticulum-Netzwerkpfade nutzen möchten (z. B. über LoRa), reicht es
häufig aus, ein System als Reticulum-Gateway fungieren zu lassen, indem
Sie der Konfiguration dieses Systems alle externen Schnittstellen
hinzufügen und dann den Transport darauf aktivieren. Jedes andere Gerät
in Ihrem lokalen WLAN kann dann mit diesem größeren Reticulum-Netzwerk
eine Verbindung herstellen, indem es einfach die Standardkonfiguration
( [AutoInterface](https://reticulum.network/manual/interfaces.html#interfaces-auto) )
verwendet.

Möglicherweise reichen die Beispiele in der Konfigurationsdatei für den
Anfang aus. Wenn Sie weitere Informationen wünschen, können Sie die
Kapitel [„Netzwerke](https://reticulum.network/manual/networks.html#networks-main) und [Schnittstellen](https://reticulum.network/manual/interfaces.html#interfaces-main) erstellen
“ in diesem Handbuch lesen.

## Reticulum-Instanzen über das Internet verbinden 

Reticulum bietet derzeit zwei Schnittstellen zum Verbinden von Instanzen
über das
Internet: [TCP](https://reticulum.network/manual/interfaces.html#interfaces-tcps) und [I2P](https://reticulum.network/manual/interfaces.html#interfaces-i2p) .
Jede Schnittstelle bietet einen anderen Funktionsumfang und
Reticulum-Benutzer sollten die Schnittstelle, die ihren Anforderungen am
besten entspricht, sorgfältig auswählen.

Mit **TCPServerInterface**können Benutzer eine Instanz hosten, auf die
über TCP/IP zugegriffen werden kann. Diese Methode ist im Allgemeinen
schneller, hat eine geringere Latenz und ist energieeffizienter als die
Verwendung von **I2PInterface**, allerdings werden dabei auch mehr Daten
über den Serverhost preisgegeben.

TCP-Verbindungen geben die IP-Adresse Ihrer Instanz und des Servers an
jeden weiter, der die Verbindung überprüfen kann. Jemand könnte diese
Informationen verwenden, um Ihren Standort oder Ihre Identität zu
ermitteln. Angreifer, die Ihre Pakete überprüfen, können möglicherweise
Paketmetadaten wie Übertragungszeit und Paketgröße aufzeichnen. Obwohl
Reticulum den Datenverkehr verschlüsselt, tut TCP dies nicht. Daher kann
ein Angreifer mithilfe der Paketüberprüfung möglicherweise herausfinden,
dass auf einem System Reticulum ausgeführt wird und welche anderen
IP-Adressen eine Verbindung damit herstellen. Das Hosten einer
öffentlich erreichbaren Instanz über TCP erfordert auch eine öffentlich
erreichbare IP-Adresse, die die meisten Internetverbindungen nicht mehr
bieten.

Das **I2PInterface**leitet Nachrichten über das [Invisible Internet
Protocol (I2P) weiter](https://geti2p.net/en/) . Um diese Schnittstelle
zu verwenden, müssen Benutzer parallel dazu auch einen I2P-Daemon
ausführen **rnsd**. Für ständig aktive I2P-Knoten wird die Verwendung
von [i2pd](https://i2pd.website/) empfohlen .

Standardmäßig verschlüsselt und mischt I2P den gesamten über das
Internet gesendeten Datenverkehr und verbirgt die IP-Adressen der
Reticulum-Instanzen von Absender und Empfänger. Beim Ausführen eines
I2P-Knotens werden auch die verschlüsselten Pakete anderer I2P-Benutzer
weitergeleitet, was zusätzliche Bandbreite und Rechenleistung
verbraucht, aber auch Timing-Angriffe und andere Formen der
Deep-Packet-Inspection erheblich erschwert.

I2P ermöglicht Benutzern außerdem, global verfügbare Reticulum-Instanzen
von nicht öffentlichen IPs und hinter Firewalls und NAT zu hosten.

Im Allgemeinen wird empfohlen, einen I2P-Knoten zu verwenden, wenn Sie
eine öffentlich zugängliche Instanz hosten und dabei die Anonymität
wahren möchten. Wenn Ihnen Leistung wichtiger ist und Sie eine etwas
einfachere Einrichtung wünschen, verwenden Sie TCP.

## Verbindung zum öffentlichen Testnetz herstellen 

Ein experimentelles öffentliches Testnetz wurde sowohl über I2P als auch
über TCP zugänglich gemacht. Sie können ihm beitreten, indem Sie
Ihrer **.reticulum/config**Datei eine der folgenden Schnittstellen
hinzufügen:

<span id="anchor-4"></span>\# TCP/IP interface to the RNS Amsterdam Hub

**\[\[**RNS Testnet Amsterdam**\]\]**

type **=** TCPClientInterface

enabled **=** yes

target_host **=** amsterdam**.**connect**.**reticulum**.**network

target_port **=** **4965**

\# TCP/IP interface to the BetweenTheBorders Hub (community-provided)

**\[\[**RNS Testnet BetweenTheBorders**\]\]**

type **=** TCPClientInterface

enabled **=** yes

target_host **=** betweentheborders**.**com

target_port **=** **4242**

\# Interface to Testnet I2P Hub

**\[\[**RNS Testnet I2P Hub**\]\]**

type **=** I2PInterface

enabled **=** yes

peers **=**
g3br23bvx3lq5uddcsjii74xgmn6y5q325ovrkq2zw2wbzbqgbuq**.**b32**.**i2p

Viele andere Reticulum-Instanzen stellen eine Verbindung zu diesem
Testnetz her, und Sie können sich auch über andere Einstiegspunkte
anschließen, wenn Sie diese kennen. Es besteht keinerlei Kontrolle über
die Netzwerktopografie, die Nutzung oder die Art der verbundenen
Instanzen. Es wird gelegentlich auch zum Testen verschiedener
Fehlerszenarien verwendet, und es gibt keine Verfügbarkeits- oder
Servicegarantien.

## Hinzufügen von Funkschnittstellen 

Sobald Sie Reticulum installiert und funktionsfähig haben, können Sie
Funkschnittstellen mit jeder verfügbaren kompatiblen Hardware
hinzufügen. Reticulum unterstützt eine breite Palette von Funkhardware,
und wenn Sie bereits welche zur Verfügung haben, ist es sehr
wahrscheinlich, dass sie mit Reticulum funktioniert. Informationen zur
Konfiguration finden Sie im
Abschnitt [„Schnittstellen“](https://reticulum.network/manual/interfaces.html#interfaces-main) dieses
Handbuchs.

Wenn Sie nicht bereits über Transceiver-Hardware verfügen, können Sie
einfach und kostengünstig
einen [RNode](https://reticulum.network/manual/hardware.html#rnode-main) bauen
. Dabei handelt es sich um einen universellen digitalen Funk-Transceiver
mit großer Reichweite, der sich problemlos in Reticulum integrieren
lässt.

Um selbst eines zu bauen, müssen Sie eine benutzerdefinierte Firmware
mit einem automatischen Installationsskript auf einer unterstützten
LoRa-Entwicklungsplatine installieren. Eine Anleitung finden Sie im
Kapitel
„ [Kommunikationshardware“](https://reticulum.network/manual/hardware.html#hardware-main) .
Wenn Sie lieber eine vorgefertigte Einheit kaufen möchten, können Sie
die Liste der Lieferanten zu Rate ziehen . Weitere Informationen zu
RNode finden Sie auch in diesen zusätzlichen externen Ressourcen:

- [So erstellen Sie Ihre eigenen
  RNodes](https://unsigned.io/how-to-make-your-own-rnodes/)
- [Installieren der RNode-Firmware auf kompatiblen
  LoRa-Geräten](https://unsigned.io/installing-rnode-firmware-on-supported-devices/)
- [Private, sichere und unzensierbare Nachrichtenübermittlung über ein
  LoRa Mesh](https://unsigned.io/private-messaging-over-lora/)
- [RNode Firmware](https://github.com/markqvist/RNode_Firmware/)

Wenn Sie Kommunikationshardware haben, die von keinem der [vorhandenen
Schnittstellentypen](https://reticulum.network/manual/interfaces.html#interfaces-main)[ unterstützt
wird, die Ihrer Meinung nach aber für die Verwendung mit Reticulum
geeignet wäre, können Sie gerne die Diskussionsseiten von
GitHub](https://github.com/markqvist/Reticulum/discussions) aufrufen und
das Hinzufügen einer Schnittstelle für die Hardware vorschlagen.

## Entwickeln Sie ein Programm mit Reticulum 

Wenn Sie Programme entwickeln möchten, die Reticulum verwenden, können
Sie am einfachsten mit der Installation der neuesten Version von
Reticulum über pip beginnen:

<span id="anchor-5"></span>pip install rns

Der obige Befehl installiert Reticulum und Abhängigkeiten, und Sie
können RNS in Ihre eigenen Programme importieren und verwenden. Der
nächste Schritt wird höchstwahrscheinlich darin bestehen, sich
einige [Beispielprogramme](https://reticulum.network/manual/examples.html#examples-main) anzusehen
.

Für erweiterte Funktionen können Sie optionale Abhängigkeiten
installieren:

<span id="anchor-6"></span>pip install pyserial

Weitere Informationen finden Sie in
der [API-Referenz](https://reticulum.network/manual/reference.html#api-main) .

## Nehmen Sie an der Retikulum-Entwicklung teil 

Wenn Sie an der Entwicklung von Reticulum und zugehörigen
Dienstprogrammen teilnehmen möchten, sollten Sie den neuesten Quellcode
von GitHub herunterladen. Verwenden Sie in diesem Fall nicht pip,
sondern versuchen Sie dieses Rezept:

<span id="anchor-7"></span>\# Install dependencies

pip install cryptography pyserial

\# Clone repository

git clone https**://**github**.**com**/**markqvist**/**Reticulum**.**git

\# Move into Reticulum folder and symlink library to examples folder

cd Reticulum

ln **-**s **../**RNS **./**Examples**/**

\# Run an example

python Examples**/**Echo**.**py **-**s

\# Unless you've manually created a config file, Reticulum will do so
now,

\# and immediately exit. Make any necessary changes to the file:

nano **~/.**reticulum**/**config

\# ... and launch the example again.

python Examples**/**Echo**.**py **-**s

\# You can now repeat the process on another computer,

\# and run the same example with -h to get command line options.

python Examples**/**Echo**.**py **-**h

\# Run the example in client mode to "ping" the server.

\# Replace the hash below with the actual destination hash of your
server.

python Examples**/**Echo**.**py **174**a64852a75682259ad8b921b8bf416

\# Have a look at another example

python Examples**/**Filetransfer**.**py **-**h

[Wenn Sie mit den grundlegenden Beispielen experimentiert haben, ist es
an der Zeit, das Kapitel „Reticulum
verstehen“](https://reticulum.network/manual/understanding.html#understanding-main) zu
lesen . Bevor Sie Ihren ersten Pull Request einreichen, ist es
wahrscheinlich eine gute Idee, sich im [Diskussionsforum auf
GitHub](https://github.com/markqvist/Reticulum/discussions) vorzustellen
oder einen der Entwickler oder Betreuer nach einem guten Ausgangspunkt
zu fragen.

## Plattformspezifische Installationshinweise 

Einige Plattformen erfordern ein leicht anderes Installationsverfahren
oder weisen verschiedene Eigenheiten auf, die Sie kennen sollten. Diese
sind hier aufgeführt.

### Android 

Reticulum kann auf Android auf verschiedene Arten verwendet werden. Der
einfachste Einstieg erfolgt über eine App
wie [Sideband](https://unsigned.io/sideband) .

Für mehr Kontrolle und Funktionen können Sie Reticulum und verwandte
Programme über die [Termux-App](https://termux.com/) verwenden , die zum
Zeitpunkt des Schreibens auf [F-droid](https://f-droid.org/) verfügbar
war .

Termux ist ein Terminalemulator und eine Linux-Umgebung für
Android-basierte Geräte, die die Möglichkeit bietet, viele verschiedene
Programme und Bibliotheken zu verwenden, darunter auch Reticulum.

Um Reticulum in der Termux-Umgebung zu verwenden, müssen
Sie **python**die **python-cryptography**Bibliothek mithilfe **pkg**des
in Termux integrierten Paketmanagers installieren. Anschließend können
Sie **pip**Reticulum mithilfe von installieren.

Führen Sie in Termux Folgendes aus:

<span id="anchor-8"></span>\# First, make sure indexes and packages are
up to date.

pkg update

pkg upgrade

\# Then install python and the cryptography library.

pkg install python python**-**cryptography

\# Make sure pip is up to date, and install the wheel module.

pip install wheel pip **--**upgrade

\# Install Reticulum

pip install rns

Wenn das Paket aus irgendeinem Grund **python-cryptography**über den
Termux-Paketmanager nicht für Ihre Plattform verfügbar ist, können Sie
versuchen, es mit dem folgenden Befehl lokal auf Ihrem Gerät zu
erstellen:

<span id="anchor-9"></span>\# First, make sure indexes and packages are
up to date.

pkg update

pkg upgrade

\# Then install dependencies for the cryptography library.

pkg install python build**-**essential openssl libffi rust

\# Make sure pip is up to date, and install the wheel module.

pip install wheel pip **--**upgrade

\# To allow the installer to build the cryptography module,

\# we need to let it know what platform we are compiling for:

export CARGO_BUILD_TARGET**=**"aarch64-linux-android"

\# Start the install process for the cryptography module.

\# Depending on your device, this can take several minutes,

\# since the module must be compiled locally on your device.

pip install cryptography

\# If the above installation succeeds, you can now install

\# Reticulum and any related software

pip install rns

Es ist auch möglich, Reticulum in Apps einzubinden, die als Android APKs
kompiliert und verteilt werden. Ein ausführliches Tutorial und
Beispielquellcode werden hier zu einem späteren Zeitpunkt enthalten
sein. Bis dahin können Sie
den [Sideband-Quellcode](https://github.com/markqvist/sideband) als
Beispiel und Ausgangspunkt verwenden.

### ARM64 

Auf einigen Architekturen, einschließlich ARM64, verfügen nicht alle
Abhängigkeiten über vorkompilierte Binärdateien. Auf solchen Systemen
müssen Sie möglicherweise **python3-dev**vor der Installation von
Reticulum oder von Programmen, die von Reticulum abhängen, eine
Installation durchführen.

<span id="anchor-10"></span>\# Install Python and development packages

sudo apt update

sudo apt install python3 python3**-**pip python3**-**dev

\# Install Reticulum

python3 **-**m pip install rns

### Himbeer-Pi 

Derzeit wird empfohlen, eine 64-Bit-Version des Raspberry
Pi-Betriebssystems zu verwenden, wenn Sie Reticulum auf Raspberry
Pi-Computern ausführen möchten, da für 32-Bit-Versionen nicht immer
Pakete für einige Abhängigkeiten verfügbar sind.

Obwohl es möglich ist, Reticulum auf 32-Bit-Rasperry-Pi-Betriebssystemen
zu installieren und auszuführen, ist hierfür die manuelle Konfiguration
und Installation einiger Pakete erforderlich. Dies wird in diesem
Handbuch nicht ausführlich beschrieben.

### Debian-Bücherwurm 

Bei Debian-Versionen, die nach April 2023 veröffentlicht wurden, ist es
standardmäßig nicht mehr möglich, **pip**Pakete auf Ihrem System zu
installieren. Leider müssen Sie **pipx**stattdessen den Ersetzungsbefehl
verwenden, der installierte Pakete in einer isolierten Umgebung
platziert. Dies sollte sich nicht negativ auf Reticulum auswirken,
funktioniert jedoch nicht, wenn Sie Reticulum in Ihre eigenen Skripte
und Programme einbinden und verwenden möchten.

<span id="anchor-11"></span>\# Install pipx

sudo apt install pipx

\# Make installed programs available on the command line

pipx ensurepath

\# Install Reticulum

pipx install rns

Alternativ können Sie das normale Verhalten
wiederherstellen, **pip**indem Sie die Konfigurationsdatei unter
erstellen oder bearbeiten **~/.config/pip/pip.conf**und den folgenden
Abschnitt hinzufügen:

<span id="anchor-12"></span>\[global\]

break-system-packages = true

Bitte beachten Sie, dass die Direktive „break-system-packages“ eine
etwas irreführende Wortwahl ist. Wenn Sie sie setzen, werden natürlich
keine Systempakete beschädigt, sondern es können lediglich **pip**Pakete
benutzer- und systemweit installiert werden. Dies *kann* zwar in
seltenen Fällen zu Versionskonflikten führen, stellt aber im Allgemeinen
keine Probleme dar.

### Ubuntu Lunar 

Bei Ubuntu-Versionen, die nach April 2023 veröffentlicht wurden, ist es
standardmäßig nicht mehr möglich, **pip**Pakete auf Ihrem System zu
installieren. Leider müssen Sie **pipx**stattdessen den Ersetzungsbefehl
verwenden, der installierte Pakete in einer isolierten Umgebung
platziert. Dies sollte sich nicht negativ auf Reticulum auswirken,
funktioniert jedoch nicht, wenn Sie Reticulum in Ihre eigenen Skripte
und Programme einbinden und verwenden möchten.

<span id="anchor-13"></span>\# Install pipx

sudo apt install pipx

\# Make installed programs available on the command line

pipx ensurepath

\# Install Reticulum

pipx install rns

Alternativ können Sie das normale Verhalten
wiederherstellen, **pip**indem Sie die Konfigurationsdatei unter
erstellen oder bearbeiten **~/.config/pip/pip.conf**und den folgenden
Abschnitt hinzufügen:

<span id="anchor-14"></span>\[global\]

break-system-packages = true

Bitte beachten Sie, dass die Direktive „break-system-packages“ eine
etwas irreführende Wortwahl ist. Wenn Sie sie setzen, werden natürlich
keine Systempakete beschädigt, sondern es wird lediglich
die **pip**benutzer- und systemweite Installation von Paketen
ermöglicht. Dies kann zwar in seltenen Fällen zu Versionskonflikten
führen, stellt aber im Allgemeinen keine Probleme dar.

## Reines Python-Retikulum 

In einigen seltenen Fällen und auf weniger bekannten Systemtypen ist es
nicht möglich, eine oder mehrere Abhängigkeiten zu installieren. In
solchen Situationen können Sie das **rnspure**Paket anstelle
des **rns**Pakets verwenden oder **pip** mit
der **--no-dependencies**Befehlszeilenoption verwenden.
Das **rnspure** Paket erfordert keine externen Abhängigkeiten für die
Installation. Bitte beachten Sie, dass der tatsächliche Inhalt der
Pakete **rns**und *vollständig identisch*rnspure** ist . Der einzige
Unterschied besteht darin, dass das Paket keine für die Installation
erforderlichen Abhängigkeiten auflistet.**rnspure**

Unabhängig davon, wie Reticulum installiert und gestartet wird, lädt es
externe Abhängigkeiten nur, wenn sie *benötigt* werden
und *verfügbar* sind . Wenn Sie Reticulum beispielsweise auf einem
System verwenden möchten, das nicht unterstützt , ist dies mit dem
Paket *rnspure*pyserial** problemlos möglich , aber Reticulum kann keine
seriellen Schnittstellen verwenden. Alle anderen verfügbaren Module
werden bei Bedarf weiterhin geladen.

**Bitte beachten!** Wenn Sie das *rnspure- Paket verwenden, um Reticulum
auf Systemen auszuführen,
die *[PyCA/Kryptografie](https://github.com/pyca/cryptography) nicht
unterstützen , ist es wichtig, dass Sie den Abschnitt [„Kryptografische
Grundelemente“](https://reticulum.network/manual/understanding.html#understanding-primitives) in
diesem Handbuch lesen und verstehen.
