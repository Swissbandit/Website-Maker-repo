# Netzwerke aufbauen 

In diesem Kapitel erhalten Sie das nötige Wissen zum Aufbau von
Netzwerken mit Reticulum. Dies ist oft einfacher als die Verwendung
herkömmlicher Stacks, da Sie sich nicht um die Koordination von
Adressen, Subnetzen und Routing für ein ganzes Netzwerk kümmern müssen,
dessen zukünftige Entwicklung Sie möglicherweise nicht kennen. Mit
Reticulum können Sie bei Bedarf einfach weitere Segmente zu Ihrem
Netzwerk hinzufügen, und Reticulum übernimmt automatisch die Konvergenz
des gesamten Netzwerks.

## Konzepte & Übersicht 

Beim Aufbau von Netzwerken mit Reticulum müssen wichtige Punkte beachtet
werden:

- In einem Reticulum-Netzwerk kann jeder Knoten autonom so viele
  > Adressen ( in der Reticulum-Terminologie *Ziele* genannt )
  > generieren, wie er benötigt, die dann global für den Rest des
  > Netzwerks erreichbar sind. Es gibt keinen zentralen Kontrollpunkt
  > für den Adressraum.

- Reticulum wurde für die Handhabung sowohl sehr kleiner als auch sehr
  > großer Netzwerke entwickelt. Obwohl der Adressraum Milliarden von
  > Endpunkten unterstützen kann, ist Reticulum auch sehr nützlich, wenn
  > nur wenige Geräte kommunizieren müssen.

- Netzwerke mit geringer Bandbreite, wie LoRa und Packet Radio, können
  > problemlos mit viel größeren Netzwerken mit höherer Bandbreite
  > interagieren und sich mit diesen verbinden. Reticulum verwaltet
  > automatisch den Informationsfluss zu und von verschiedenen
  > Netzwerksegmenten, und wenn die Bandbreite begrenzt ist, wird dem
  > lokalen Datenverkehr Vorrang eingeräumt.

- Reticulum bietet standardmäßig Absender-/Initiator-Anonymität. Es gibt
  > keine Möglichkeit, den Datenverkehr zu filtern oder ihn anhand
  > seiner Quelle zu unterscheiden.

- Der gesamte Datenverkehr wird mit temporären Schlüsseln verschlüsselt,
  > die durch einen Elliptic Curve Diffie-Hellman-Schlüsselaustausch auf
  > Curve25519 generiert werden. Es gibt keine Möglichkeit, den
  > Datenverkehr zu überprüfen und bestimmte Arten von Datenverkehr zu
  > priorisieren oder zu drosseln. Alle Transport- und Routing-Schichten
  > sind daher völlig unabhängig vom Datenverkehrtyp und leiten den
  > gesamten Datenverkehr gleichmäßig weiter.

- Reticulum kann sowohl mit als auch ohne Infrastruktur funktionieren.
  > Wenn *Transportknoten* verfügbar sind, können sie den Verkehr für
  > andere Knoten über mehrere Hops weiterleiten und als verteilter
  > kryptografischer Schlüsselspeicher fungieren. Wenn keine
  > Transportknoten verfügbar sind, können alle Knoten, die sich in
  > Kommunikationsreichweite befinden, trotzdem kommunizieren.

- Jeder Knoten kann zu einem Transportknoten werden, indem er einfach in
  > seiner Konfiguration aktiviert wird. Es ist jedoch nicht notwendig,
  > dass jeder Knoten im Netzwerk ein Transportknoten ist. Wenn jeder
  > Knoten ein Transportknoten ist, verschlechtert sich in den meisten
  > Fällen die Leistung und Zuverlässigkeit des Netzwerks.

  > *Allgemein gilt: Wenn ein Knoten stationär, gut vernetzt und die
  > meiste Zeit in Betrieb ist, ist er ein guter Kandidat für einen
  > Transportknoten. Für eine optimale Leistung sollte ein Netzwerk die
  > Anzahl an Transportknoten enthalten, die eine Verbindung zum
  > vorgesehenen Gebiet/zur vorgesehenen Topografie bietet, und nicht
  > viel mehr.*

- Reticulum ist so konzipiert, dass es in offenen, vertrauenslosen
  > Umgebungen zuverlässig funktioniert. Das heißt, Sie können damit
  > Netzwerke mit offenem Zugriff erstellen, denen Teilnehmer frei und
  > unorganisiert beitreten und sie verlassen können. Diese Eigenschaft
  > ermöglicht eine völlig neue und bislang weitgehend unerforschte
  > Klasse vernetzter Anwendungen, in denen sich Netzwerke und der
  > Informationsfluss innerhalb dieser Netzwerke organisch bilden und
  > auflösen können.

- Sie können genauso einfach geschlossene Netzwerke erstellen, da Sie
  > mit Reticulum jeder Schnittstelle eine Authentifizierung hinzufügen
  > können. Das bedeutet, dass Sie den Zugriff auf jeden
  > Schnittstellentyp beschränken können, selbst wenn Sie ältere Geräte
  > wie Modems verwenden. Sie können auch authentifizierte und offene
  > Schnittstellen auf demselben System mischen. Informationen zum
  > Einrichten der Schnittstellenauthentifizierung finden Sie im
  > Abschnitt [„Gemeinsame
  > Schnittstellenoptionen“](https://reticulum.network/manual/interfaces.html#interfaces-options) des
  > Kapitels „ [Schnittstellen“ dieses
  > Handbuchs.](https://reticulum.network/manual/interfaces.html#interfaces-main)

Mit Reticulum können Sie sehr unterschiedliche Arten von Netzwerkmedien
in einem einheitlichen Mesh mischen oder alles in einem Medium
zusammenfassen. Sie können ein „virtuelles Netzwerk“ aufbauen, das
vollständig über das Internet läuft und in dem alle Knoten über TCP- und
UDP-„Kanäle“ kommunizieren. Sie können ein solches Netzwerk auch unter
Verwendung anderer bereits etablierter Kommunikationskanäle als zugrunde
liegender Träger für Reticulum aufbauen.

Die meisten realen Netzwerke werden jedoch wahrscheinlich entweder eine
Form von drahtloser oder direkter Festnetzkommunikation beinhalten.
Damit Reticulum über ein beliebiges Medium kommunizieren kann, müssen
Sie dies in der Konfigurationsdatei angeben, die sich standardmäßig
unter befindet **~/.reticulum/config**. Beispiele für
Schnittstellenkonfigurationen finden Sie im Kapitel [„Unterstützte
Schnittstellen“](https://reticulum.network/manual/interfaces.html#interfaces-main) dieses
Handbuchs.

Es kann eine beliebige Anzahl von Schnittstellen konfiguriert werden und
Reticulum entscheidet automatisch, welche in einer bestimmten Situation
geeignet sind, je nachdem, wohin der Datenverkehr fließen muss.

## Beispielszenarien 

In diesem Abschnitt werden einige Beispielszenarien veranschaulicht und
wie diese im Allgemeinen geplant, implementiert und konfiguriert werden
würden.

### Vernetzte LoRa-Standorte 

Eine Organisation möchte ihren Mitgliedern, die sich hauptsächlich in
drei verschiedenen Gebieten befinden, Kommunikations- und
Informationsdienste anbieten. Es werden drei geeignete Standorte auf
Hügeln gefunden, an denen die Organisation Geräte installieren kann:
Standort A, B und C.

Da die zwischen den Benutzern auszutauschende Datenmenge hauptsächlich
textbasiert ist, ist der Bandbreitenbedarf gering und für die Verbindung
der Benutzer mit dem Netzwerk werden LoRa-Funkgeräte ausgewählt.

Aufgrund der Lage auf einem Hügel besteht eine Funkverbindung zwischen
den Standorten A und B sowie B und C. Daher muss die Organisation zur
Verbindung der Standorte nicht auf das Internet zurückgreifen, sondern
kann vier Point-to-Point-Funkgeräte auf WiFi-Basis erwerben.

An jedem Standort wird ein Raspberry Pi installiert, der als Gateway
fungiert. Ein LoRa-Radio wird über ein USB-Kabel mit dem Pi verbunden
und das WiFi-Radio wird mit dem Ethernet-Port des Pi verbunden. An
Standort B werden zwei WiFi-Radios benötigt, um sowohl Standort A als
auch Standort C erreichen zu können, daher wird an diesem Standort ein
zusätzlicher Ethernet-Adapter mit dem Pi verbunden.

Sobald die Hardware installiert ist, wird Reticulum auf allen Pis
installiert und an den Standorten A und C wird eine Schnittstelle für
das LoRa-Radio sowie eine für das WiFi-Radio hinzugefügt. An Standort B
wird der Reticulum-Konfigurationsdatei eine Schnittstelle für das
LoRa-Radio und eine Schnittstelle für jedes WiFi-Radio hinzugefügt. Die
Transportknotenoption wird in der Konfiguration aller drei Gateways
aktiviert.

Das Netzwerk ist nun betriebsbereit und kann Benutzer in allen drei
Bereichen bedienen. Die Organisation bereitet ein LoRa-Radio vor, das
den Endbenutzern zusammen mit einer Reticulum-Konfigurationsdatei zur
Verfügung gestellt wird. Diese enthält die richtigen Parameter für die
Kommunikation mit den an den Gateway-Standorten installierten
LoRa-Radios.

Sobald Benutzer eine Verbindung zum Netzwerk herstellen, kann jeder an
allen drei Standorten mit jedem anderen kommunizieren.

### Überbrückung über das Internet 

Mit dem Wachstum der Organisation bilden sich mehrere neue Communities
an Orten, die zu weit vom Kernnetz entfernt sind, um über
WLAN-Verbindungen erreichbar zu sein. Für die neuen Communities an den
neuen Standorten D und E werden neue Gateways ähnlich den zuvor
installierten eingerichtet, sie sind jedoch vom Kernnetz isoliert und
dienen nur den lokalen Benutzern.

Nach der Untersuchung der Optionen stellt sich heraus, dass es möglich
ist, an Standort A eine Internetverbindung zu installieren, und es wird
eine Schnittstelle der Internetverbindung für Reticulum auf dem
Raspberry Pi an Standort A konfiguriert.

Ein Mitglied der Organisation am Standort D namens Dori ist bereit zu
helfen, indem sie die Internetverbindung, die sie bereits zu Hause hat,
teilt und einen Raspberry Pi laufen lässt. Auf ihrem Pi wird eine neue
Reticulum-Schnittstelle konfiguriert, die eine Verbindung zur neu
aktivierten Internetschnittstelle am Gateway am Standort A herstellt.
Dori ist nun sowohl mit allen Knoten an ihrem eigenen lokalen Standort
(über das LoRa-Gateway auf dem Hügel) als auch mit allen kombinierten
Benutzern der Standorte A, B und C verbunden. Anschließend aktiviert sie
den Transport auf ihrem Knoten, und der Datenverkehr von Standort D kann
nun alle an Standort A, B und C erreichen und umgekehrt.

### Wachstum und Konvergenz 

Mit dem Wachstum der Organisation werden weitere Gateways hinzugefügt,
um mit der wachsenden Benutzerbasis Schritt zu halten. Einige lokale
Gateways fügen sogar UKW-Funkgeräte und Paketmodems hinzu, um abgelegene
Benutzer und Gemeinden zu erreichen, die für LoRa-Funkgeräte und
WiFi-Backhauls unerreichbar sind.

Da immer mehr Standorte, Gateways und Benutzer verbunden werden, wird
der erforderliche Koordinationsaufwand auf ein Minimum reduziert. Wenn
eine Community die Konnektivität zur nächsten Community hinzufügen
möchte, kann dies einfach erfolgen, ohne dass alle beteiligt werden oder
Adressraum oder Routingtabellen koordiniert werden müssen.

Mit der erweiterten geografischen Abdeckung stellen die Betreiber am
Standort A eines Tages fest, dass die ursprünglichen
Internet-Schnittstellen nicht mehr genutzt werden. Das Netzwerk ist
inzwischen vollständig selbstverbunden und die Standorte, die einst
schlecht verbundene Außenseiter waren, sind nun ein integraler
Bestandteil des Netzwerks.
