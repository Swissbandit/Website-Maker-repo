# Retikulum verstehen 

In diesem Kapitel werden der allgemeine Zweck und die Funktionsweise von
Reticulum kurz beschrieben. Es soll Ihnen einen Überblick über die
Funktionsweise des Stacks und ein Verständnis für die Entwicklung
vernetzter Anwendungen mit Reticulum geben.

Dieses Kapitel ist keine umfassende Informationsquelle zu Reticulum,
zumindest noch nicht. Derzeit ist die einzige vollständige Quelle und
letzte Autorität zur tatsächlichen Funktionsweise von Reticulum die
Python-Referenzimplementierung und die API-Referenz. Dennoch ist dieses
Kapitel eine wichtige Ressource, um die Funktionsweise von Reticulum aus
einer übergeordneten Perspektive sowie die allgemeinen Prinzipien von
Reticulum zu verstehen und zu erfahren, wie Sie diese beim Erstellen
Ihrer eigenen Netzwerke oder Software anwenden können.

Nach der Lektüre dieses Dokuments sollten Sie gut gerüstet sein, um zu
verstehen, wie ein Reticulum-Netzwerk funktioniert, was es leisten kann
und wie Sie es selbst nutzen können. Wenn Sie bei der Entwicklung
mithelfen möchten, ist dies auch der richtige Ausgangspunkt, da es einen
ziemlich klaren Überblick über die Gedanken und die Philosophie hinter
Reticulum bietet, welche Probleme es lösen soll und wie es diese
Lösungen angeht.

## <span id="anchor"></span>Motivation 

Der Hauptgrund für die Entwicklung und Implementierung von Reticulum war
der derzeitige Mangel an zuverlässigen, funktionalen und sicheren
digitalen Kommunikationsmethoden mit minimaler Infrastruktur. Ich bin
überzeugt, dass es äußerst wünschenswert ist, eine zuverlässige und
effiziente Methode zu entwickeln, um weitreichende digitale
Kommunikationsnetzwerke einzurichten, die einen sicheren
Informationsaustausch zwischen Menschen und Maschinen ermöglichen, ohne
dass es eine zentrale Autorität, Kontrolle, Zensur oder Zugangsbarrieren
gibt.

Fast alle der heute genutzten Netzwerksysteme haben eine gemeinsame
Einschränkung: Sie erfordern ein hohes Maß an Koordination sowie
zentralisiertes Vertrauen und Macht, um zu funktionieren. Um solchen
Netzwerken beizutreten, braucht man die Zustimmung der Gatekeeper, die
die Kontrolle haben. Dieses Bedürfnis nach Koordination und Vertrauen
führt unweigerlich zu einer Umgebung zentraler Kontrolle, in der es für
Infrastrukturbetreiber oder Regierungen sehr einfach ist, den
Datenverkehr zu kontrollieren oder zu verändern und unerwünschte Akteure
zu zensieren oder zu verfolgen. Es macht es auch völlig unmöglich,
Netzwerke nach Belieben frei einzusetzen und zu nutzen, wie man es bei
anderen gängigen Tools tun würde, die die Handlungsfähigkeit und
Freiheit des Einzelnen stärken.

Reticulum zielt darauf ab, so wenig Koordination und Vertrauen wie
möglich zu erfordern. Ziel ist es, sicheres, anonymes und
erlaubnisfreies Networking und Informationsaustausch zu einem Tool zu
machen, das jeder einfach nutzen kann.

Da Reticulum vollständig medienunabhängig ist, können Sie damit
Netzwerke auf dem aufbauen, was für die jeweilige Situation am besten
geeignet ist oder was Ihnen zur Verfügung steht. In einigen Fällen kann
es sich dabei um Paketfunkverbindungen über UKW-Frequenzen handeln, in
anderen Fällen um ein 2,4-GHz-Netzwerk mit handelsüblichen Funkgeräten
oder um gängige LoRa-Entwicklungsboards.

Zum Zeitpunkt der Veröffentlichung dieses Dokuments ist die schnellste
und einfachste Einrichtung für Entwicklung und Tests die Verwendung von
LoRa-Funkmodulen mit einer Open-Source-Firmware (siehe Abschnitt
„ [Referenz-Setup](https://reticulum.network/manual/understanding.html#understanding-referencesystem) “),
die an jeden Computer oder jedes Mobilgerät angeschlossen sind, auf dem
Reticulum ausgeführt werden kann.

Das ultimative Ziel von Reticulum ist es, jedem zu ermöglichen, sein
eigener Netzwerkbetreiber zu sein, und es kostengünstig und einfach zu
machen, riesige Gebiete mit einer Vielzahl unabhängiger, vernetzbarer
und autonomer Netzwerke abzudecken. Reticulum **ist kein ***einzelnes
Netzwerk* , sondern **ein Tool** zum Aufbau *Tausender Netzwerke* .
Netzwerke ohne Kill-Switches, Überwachung, Zensur und Kontrolle.
Netzwerke, die frei miteinander interagieren, sich verbinden und trennen
können und keiner zentralen Aufsicht bedürfen. Netzwerke für
Menschen. *Netzwerke für die Menschen* .

## <span id="anchor-1"></span>Ziele 

Um eine möglichst breite Nutzung und effiziente Bereitstellung zu
gewährleisten, wurden bei der Entwicklung von Reticulum die folgenden
Ziele verfolgt:

- **Vollständig nutzbar als Open Source Software-Stack**

  > Reticulum muss mit Open-Source-Software implementiert werden und nur
  > mit dieser ausgeführt werden können. Dies ist entscheidend, um die
  > Verfügbarkeit, Sicherheit und Transparenz des Systems zu
  > gewährleisten.

- **Agnostizismus auf Hardwareebene**

  > Reticulum muss vollständig hardwareunabhängig sein und über eine
  > Vielzahl von physischen Netzwerkschichten verwendet werden können,
  > wie etwa Datenfunkgeräte, serielle Leitungen, Modems, tragbare
  > Transceiver, kabelgebundenes Ethernet, WLAN oder alles andere, was
  > einen digitalen Datenstrom übertragen kann. Hardware, die für den
  > dedizierten Einsatz von Reticulum hergestellt wird, muss so günstig
  > wie möglich sein und handelsübliche Komponenten verwenden, damit sie
  > von jedem, der daran interessiert ist, leicht modifiziert und
  > repliziert werden kann.

- **Sehr geringer Bandbreitenbedarf**

  > *Reticulum sollte über Verbindungen mit einer Übertragungskapazität
  > von nur 5 Bit pro Sekunde* zuverlässig funktionieren .

- **Standardmäßige Verschlüsselung**

  > Reticulum muss für die gesamte Kommunikation standardmäßig eine
  > starke Verschlüsselung verwenden.

- **Anonymität des Initiators**

  > Es muss möglich sein, über ein Reticulum-Netzwerk zu kommunizieren,
  > ohne identifizierende Informationen über sich preiszugeben.

- **Unlizenzierte Nutzung**

  > Reticulum muss über physische Kommunikationsmedien funktionieren,
  > für deren Nutzung keine Lizenz erforderlich ist. Reticulum muss so
  > konzipiert sein, dass es über ISM-Funkfrequenzbänder verwendet
  > werden kann und unter solchen Bedingungen funktionsfähige
  > Fernverbindungen bereitstellen kann, beispielsweise durch Anschluss
  > eines Modems an ein PMR- oder CB-Funkgerät oder durch Verwendung von
  > LoRa- oder WiFi-Modulen.

- **Mitgelieferte Software**

  > Zusätzlich zum zentralen Netzwerk-Stack und der API, die es einem
  > Entwickler ermöglicht, Anwendungen mit Reticulum zu erstellen, muss
  > ein grundlegender Satz von Reticulum-basierten Kommunikationstools
  > implementiert und zusammen mit Reticulum selbst veröffentlicht
  > werden. Diese sollen sowohl als funktionale, grundlegende
  > Kommunikationssuite als auch als Beispiel und Lernressource für
  > andere dienen, die Anwendungen mit Reticulum erstellen möchten.

- **Benutzerfreundlichkeit**

  > Die Referenzimplementierung von Reticulum ist in Python geschrieben,
  > um die Verwendung und das Verständnis zu vereinfachen. Ein
  > Programmierer mit nur grundlegender Erfahrung sollte in der Lage
  > sein, mit Reticulum vernetzte Anwendungen zu schreiben.

- **Niedrige Kosten**

  > Die Bereitstellung eines auf Reticulum basierenden
  > Kommunikationssystems soll so kostengünstig wie möglich sein. Dies
  > soll durch die Verwendung handelsüblicher Hardware erreicht werden,
  > die potenzielle Benutzer möglicherweise bereits besitzen. Die Kosten
  > für die Einrichtung eines funktionierenden Knotens sollten weniger
  > als 100 US-Dollar betragen, selbst wenn alle Teile gekauft werden
  > müssen.

## <span id="anchor-2"></span>Einführung & Grundfunktionen 

Reticulum ist ein Netzwerk-Stack, der für Verbindungen mit hoher Latenz
und geringer Bandbreite geeignet ist. Reticulum ist im Kern
ein *nachrichtenorientiertes* System. Es eignet sich sowohl für lokale
Punkt-zu-Punkt- oder Punkt-zu-Mehrpunkt-Szenarien, in denen sich alle
Knoten in Reichweite zueinander befinden, als auch für Szenarien, in
denen Pakete über mehrere Hops in einem komplexen Netzwerk transportiert
werden müssen, um den Empfänger zu erreichen.

Reticulum verzichtet auf das Konzept von Adressen und Ports, wie man es
von IP, TCP und UDP kennt. Stattdessen verwendet Reticulum das singuläre
Konzept von *Zielen* . Jede Anwendung, die Reticulum als Netzwerk-Stack
verwendet, muss ein oder mehrere Ziele zum Empfangen von Daten erstellen
und die Ziele kennen, an die sie Daten senden muss.

Alle Ziele in Reticulum werden als 16-Byte-Hash \_dargestellt\_. Dieser
Hash wird durch Abschneiden eines vollständigen SHA-256-Hashs mit
identifizierenden Merkmalen des Ziels abgeleitet. Benutzern werden die
Zieladressen als 16 hexadezimale Bytes angezeigt, wie in diesem
Beispiel: **\<13425ec15b621c1d928589718000d814\>**.

Die Kürzungsgröße von 16 Bytes (128 Bits) für Ziele wurde als
vernünftiger Kompromiss zwischen Adressraum und Paket-Overhead gewählt.
Der Adressraum, der durch diese Größe abgedeckt wird, kann viele
Milliarden gleichzeitig aktiver Geräte im selben Netzwerk unterstützen,
während der Paket-Overhead niedrig gehalten wird, was bei Netzwerken mit
geringer Bandbreite unerlässlich ist. In dem sehr unwahrscheinlichen
Fall, dass dieser Adressraum fast überlastet ist, kann eine einzeilige
Codeänderung den Reticulum-Adressraum auf bis zu 256 Bits erweitern und
so sicherstellen, dass der Reticulum-Adressraum potenziell Netzwerke von
galaktischem Ausmaß unterstützen kann. Dies ist offensichtlich eine
völlige und lächerliche Überbelegung, und daher sollten die aktuellen
128 Bits auch in ferner Zukunft ausreichen.

Standardmäßig verschlüsselt Reticulum alle Daten mit Elliptic Curve
Cryptography und AES. Jedes an ein Ziel gesendete Paket wird mit einem
pro Paket abgeleiteten Schlüssel verschlüsselt. Reticulum kann auch
einen verschlüsselten Kanal zu einem Ziel einrichten, der
als *Link* bezeichnet wird . Sowohl über Links gesendete Daten als auch
einzelne Pakete bieten *Initiator Anonymity* , und Links bieten
zusätzlich *Forward Secrecy* durch Verwendung eines Elliptic Curve
Diffie Hellman-Schlüsselaustauschs auf Curve25519, um flüchtige
Schlüssel pro Link abzuleiten. Die Multi-Hop-Transport-, Koordinations-,
Verifizierungs- und Zuverlässigkeitsebenen sind vollständig autonom und
basieren ebenfalls auf Elliptic Curve Cryptography.

Reticulum bietet außerdem symmetrische Schlüsselverschlüsselung für
gruppenorientierte Kommunikation sowie unverschlüsselte Pakete für
lokale Übertragungszwecke.

Reticulum kann mit einer Vielzahl von Schnittstellen wie Funkmodems,
Datenfunkgeräten und seriellen Anschlüssen verbunden werden und bietet
die Möglichkeit, den Reticulum-Verkehr problemlos über IP-Links wie das
Internet oder private IP-Netzwerke zu tunneln.

### <span id="anchor-3"></span>Reiseziele 

Um Daten mit dem Reticulum-Stack zu empfangen und zu senden, muss eine
Anwendung ein oder mehrere Ziele erstellen. Reticulum verwendet drei
verschiedene grundlegende Zieltypen und einen speziellen:

- **Einzel**

  > Der *Einzelzieltyp* ist der häufigste Typ in Reticulum und sollte
  > für die meisten Zwecke verwendet werden. Er wird immer durch einen
  > eindeutigen öffentlichen Schlüssel identifiziert. Alle an dieses
  > Ziel gesendeten Daten werden mit temporären Schlüsseln
  > verschlüsselt, die aus einem ECDH-Schlüsselaustausch abgeleitet
  > werden, und sind nur für den Ersteller des Ziels lesbar, der den
  > entsprechenden privaten Schlüssel besitzt.

- **Schmucklos**

  > Ein *einfacher* Zieltyp ist unverschlüsselt und für Datenverkehr
  > geeignet, der an eine Reihe von Benutzern gesendet oder von jedem
  > gelesen werden soll. Datenverkehr zu einem *einfachen* Ziel ist
  > nicht verschlüsselt. Im Allgemeinen können *einfache* Ziele für
  > Broadcast-Informationen verwendet werden, die öffentlich sein
  > sollen. Einfache Ziele sind nur direkt erreichbar, und an einfache
  > Ziele adressierte Pakete werden nie über mehrere Hops im Netzwerk
  > transportiert. Um in Reticulum über mehrere Hops transportiert
  > werden zu können, *müssen* Informationen verschlüsselt werden, da
  > Reticulum die Verschlüsselung pro Paket verwendet, um Routingpfade
  > zu überprüfen und sie aktiv zu halten.

- **Gruppe**

  > Der spezielle *Gruppenzieltyp* , der ein symmetrisch verschlüsseltes
  > virtuelles Ziel definiert. An dieses Ziel gesendete Daten werden mit
  > einem symmetrischen Schlüssel verschlüsselt und sind für jeden
  > lesbar, der den Schlüssel besitzt. Wie beim *einfachen* Zieltyp
  > werden Pakete an diesen Zieltyp derzeit jedoch nicht über mehrere
  > Hops transportiert, obwohl ein geplantes Upgrade von Reticulum
  > global erreichbare *Gruppenziele* ermöglichen wird .

- **Verknüpfung**

  > Ein *Link* ist ein spezieller Zieltyp, der als abstrakter Kanal zu
  > einem *einzelnen* Ziel dient, direkt verbunden oder über mehrere
  > Hops. Der *Link* bietet außerdem Zuverlässigkeit und effizientere
  > Verschlüsselung, Vorwärtsgeheimnis, Initiatoranonymität und kann
  > daher auch dann nützlich sein, wenn ein Knoten direkt erreichbar
  > ist. Er bietet außerdem eine leistungsfähigere API und ermöglicht
  > die einfache Ausführung von Anfragen und Antworten, großen
  > Datenübertragungen und mehr.

#### <span id="anchor-4"></span>Zielbenennung 

Ziele werden in einer leicht verständlichen Punktnotation
von *Aspekten* erstellt und benannt und im Netzwerk als Hash dieses
Wertes dargestellt. Der Hash ist ein auf 128 Bit gekürzter SHA-256. Der
Aspekt der obersten Ebene sollte immer ein eindeutiger Bezeichner für
die Anwendung sein, die das Ziel verwendet. Die nächsten Ebenen von
Aspekten können vom Ersteller der Anwendung beliebig definiert werden.

Aspekte können beliebig lang und zahlreich sein, wie erforderlich. Ein
daraus resultierender langer Zielname wirkt sich nicht auf die Effizienz
aus, da Namen im Netzwerk immer als gekürzte SHA-256-Hashes dargestellt
werden.

Beispielsweise könnte ein Ziel für eine Anwendung zur Umweltüberwachung
aus dem Anwendungsnamen, einem Gerätetyp und einem Messtyp wie folgt
bestehen:

<span id="anchor-5"></span>app name : environmentlogger

aspects : remotesensor, temperature

full name : environmentlogger.remotesensor.temperature

hash : 4faf1b2e0a077e6a9d92fa051f256038

Für das *einzelne* Ziel hängt Reticulum vor dem Hashen automatisch den
zugehörigen öffentlichen Schlüssel als Zielaspekt an. Dies geschieht, um
sicherzustellen, dass nur das richtige Ziel erreicht wird, da jeder
jeden Zielnamen abhören kann. Durch das Anhängen des öffentlichen
Schlüssels wird sichergestellt, dass ein bestimmtes Paket nur an das
Ziel gesendet wird, das den entsprechenden privaten Schlüssel zum
Entschlüsseln des Pakets besitzt.

**Beachten Sie!** Es gibt hier ein sehr wichtiges Konzept, das Sie
verstehen müssen:

- Jeder kann den Zielnamen
  verwenden**environmentlogger.remotesensor.temperature**
- Jedes Ziel, das dies tut, verfügt weiterhin über einen eindeutigen
  Ziel-Hash und ist somit eindeutig adressierbar, da sich die
  öffentlichen Schlüssel unterscheiden.

Bei der tatsächlichen Verwendung der Benennung *einzelner* Ziele ist es
ratsam, bei der Benennung von Aspekten keine eindeutig identifizierenden
Merkmale zu verwenden. Aspektnamen sollten allgemeine Begriffe sein, die
beschreiben, welche Art von Ziel dargestellt wird. Der eindeutig
identifizierende Aspekt wird immer durch das Anhängen des öffentlichen
Schlüssels erreicht, der das Ziel zu einem eindeutig identifizierbaren
Ziel erweitert. Reticulum erledigt dies automatisch.

Jedes Ziel in einem Reticulum-Netzwerk kann angesprochen und erreicht
werden, indem man einfach seinen Ziel-Hash (und den öffentlichen
Schlüssel) kennt. Wenn der öffentliche Schlüssel jedoch nicht bekannt
ist, kann er einfach vom Netzwerk angefordert werden, indem man den
Ziel-Hash kennt. Die Verwendung von App-Namen und Aspekten erleichtert
die Strukturierung von Reticulum-Programmen und ermöglicht es, zu
filtern, welche Informationen und Daten Ihr Programm empfängt.

Zusammenfassend sollten die verschiedenen Zieltypen in den folgenden
Situationen verwendet werden:

- **Einzel**

  > Wenn private Kommunikation zwischen zwei Endpunkten erforderlich
  > ist. Unterstützt mehrere Hops.

- **Gruppe**

  > Wenn private Kommunikation zwischen zwei oder mehr Endpunkten
  > erforderlich ist. Unterstützt mehrere Hops indirekt, muss aber
  > zuerst über ein *einzelnes* Ziel hergestellt werden.

- **Schmucklos**

  > Wenn eine Klartextkommunikation erwünscht ist, beispielsweise beim
  > Senden von Informationen oder für lokale Ermittlungszwecke.

Um mit einem *einzelnen* Ziel zu kommunizieren, müssen Sie dessen
öffentlichen Schlüssel kennen. Jede Methode zum Abrufen des öffentlichen
Schlüssels ist gültig, aber Reticulum enthält einen einfachen
Mechanismus, um andere Knoten auf den öffentlichen Schlüssel Ihres Ziels
aufmerksam zu machen, der als „ *announce“* bezeichnet wird . Es ist
auch möglich, einen unbekannten öffentlichen Schlüssel vom Netzwerk
anzufordern, da alle Transportinstanzen als verteiltes Hauptbuch
öffentlicher Schlüssel dienen.

Beachten Sie, dass öffentliche Schlüsselinformationen auch auf andere
Weise als mit der integrierten *Ankündigungsfunktion* weitergegeben und
überprüft werden können und dass es daher nicht erforderlich ist,
die *Ankündigungs-* und *Pfadanforderungsfunktion* zu verwenden , um
öffentliche Schlüssel zu erhalten. Dies ist jedoch bei weitem die
einfachste Methode und sollte auf jeden Fall verwendet werden, wenn es
keinen sehr guten Grund gibt, es anders zu machen.

### <span id="anchor-6"></span>Ankündigungen öffentlicher Schlüssel 

Bei einer *Ankündigung* wird ein spezielles Paket über alle relevanten
Schnittstellen gesendet, das alle erforderlichen Informationen über den
Ziel-Hash und den öffentlichen Schlüssel enthält und möglicherweise auch
einige zusätzliche, anwendungsspezifische Daten enthält. Das gesamte
Paket wird vom Absender signiert, um die Authentizität sicherzustellen.
Die Verwendung der Ankündigungsfunktion ist nicht erforderlich, in
vielen Fällen ist dies jedoch die einfachste Möglichkeit, öffentliche
Schlüssel im Netzwerk zu teilen. Der Ankündigungsmechanismus dient auch
dazu, eine End-to-End-Konnektivität zum angekündigten Ziel herzustellen,
während sich die Ankündigung durch das Netzwerk ausbreitet.

Beispielsweise könnte eine Ankündigung in einer einfachen
Messenger-Anwendung folgende Informationen enthalten:

- Der Ziel-Hash des Ansagers
- Der öffentliche Schlüssel des Ansagers
- Anwendungsspezifische Daten, in diesem Fall der Spitzname und der
  Verfügbarkeitsstatus des Benutzers
- Ein zufälliger Blob, der jede neue Ankündigung einzigartig macht
- Eine Ed25519-Signatur der obigen Informationen, die die Authentizität
  bestätigt

Mit diesen Informationen kann jeder Reticulum-Knoten, der sie empfängt,
ein ausgehendes Ziel rekonstruieren, um sicher mit diesem Ziel zu
kommunizieren. Ihnen ist vielleicht aufgefallen, dass eine Information
fehlt, um das vollständige Wissen über das angekündigte Ziel zu
rekonstruieren, und das sind die Aspektnamen des Ziels. Diese werden
absichtlich weggelassen, um Bandbreite zu sparen, da sie in fast allen
Fällen implizit sind. Die empfangende Anwendung kennt sie bereits. Wenn
ein Zielname nicht vollständig implizit ist, können Informationen in den
anwendungsspezifischen Datenteil aufgenommen werden, die es dem
Empfänger ermöglichen, die Benennung abzuleiten.

Es ist wichtig zu beachten, dass Ankündigungen nach einem bestimmten
Muster im gesamten Netzwerk weitergeleitet werden. Dies wird im
Abschnitt [Der Ankündigungsmechanismus im
Detail](https://reticulum.network/manual/understanding.html#understanding-announce) ausführlich
beschrieben .

In Reticulum dürfen sich Ziele beliebig im Netzwerk bewegen. Dies
unterscheidet sich stark von Protokollen wie IP, bei denen eine Adresse
immer innerhalb des Netzwerksegments bleiben muss, dem sie zugewiesen
wurde. Diese Einschränkung gibt es in Reticulum nicht, und jedes Ziel
ist über die gesamte Topographie des Netzwerks hinweg *vollständig
portierbar und kann sogar in andere Reticulum-Netzwerke* als das, in dem
es erstellt wurde, verschoben werden und bleibt dennoch erreichbar. Um
seine Erreichbarkeit zu aktualisieren, muss ein Ziel lediglich eine
Ankündigung an alle Netzwerke senden, zu denen es gehört. Nach kurzer
Zeit ist es im Netzwerk global erreichbar.

Die Tatsache, dass *einzelne* Ziele immer an ein privates/öffentliches
Schlüsselpaar gebunden sind, führt uns zum nächsten Thema.

### <span id="anchor-7"></span>Identitäten 

In Reticulum stellt eine *Identität* nicht unbedingt eine persönliche
Identität dar, sondern ist eine Abstraktion, die jede Art
von *verifizierbarer Entität* darstellen kann . Dies könnte durchaus
eine Person sein, aber auch die Steuerschnittstelle einer Maschine,
eines Programms, Roboters, Computers, Sensors oder etwas ganz anderem.
Im Allgemeinen kann jede Art von Agent, der handeln oder beeinflusst
werden oder Informationen speichern oder manipulieren kann, als
Identität dargestellt werden. Eine *Identität* kann verwendet werden, um
eine beliebige Anzahl von Zielen zu erstellen.

Einem *einzelnen* Ziel ist immer eine *Identität* zugeordnet, nicht
jedoch *einfachen* oder *Gruppenzielen* . Ziele und Identitäten haben
eine multilaterale Verbindung. Sie können ein Ziel erstellen, und wenn
es bei der Erstellung nicht mit einer Identität verknüpft ist, wird
einfach automatisch ein neues Ziel erstellt. Dies kann in manchen
Situationen wünschenswert sein, aber oft möchten Sie wahrscheinlich
zuerst die Identität erstellen und sie dann zum Erstellen neuer Ziele
verwenden.

Beispielsweise könnten wir eine Identität verwenden, um den Benutzer
einer Messaging-Anwendung darzustellen. Von dieser Identität können dann
Ziele erstellt werden, damit die Kommunikation den Benutzer erreichen
kann. In allen Fällen ist es von großer Bedeutung, die mit einer
Reticulum-Identität verknüpften privaten Schlüssel sicher und privat zu
speichern, da der Zugriff auf die Identitätsschlüssel dem Zugriff auf
und der Kontrolle der Erreichbarkeit aller von dieser Identität
erstellten Ziele entspricht.

### <span id="anchor-8"></span>Weiterkommen 

Die oben genannten Funktionen und Prinzipien bilden den Kern von
Reticulum und würden ausreichen, um funktionale Netzwerkanwendungen in
lokalen Clustern zu erstellen, beispielsweise über Funkverbindungen, bei
denen alle interessierten Knoten einander direkt hören können. Aber um
wirklich nützlich zu sein, brauchen wir eine Möglichkeit, den Verkehr
über mehrere Hops im Netzwerk zu leiten.

In den folgenden Abschnitten werden zwei Konzepte vorgestellt, die dies
ermöglichen: *Pfade* und *Links* .

## <span id="anchor-9"></span>Retikulum-Transport 

Die in herkömmlichen Netzwerken verwendeten Routing-Methoden sind
grundsätzlich nicht mit den physischen Medientypen und Umständen
kompatibel, für die Reticulum entwickelt wurde. Diese Mechanismen setzen
meist Vertrauen auf der physischen Ebene voraus und benötigen häufig
viel mehr Bandbreite, als Reticulum als verfügbar voraussetzen kann. Da
Reticulum für den Betrieb über offene Funkfrequenzen konzipiert ist,
kann kein solches Vertrauen vorausgesetzt werden und die Bandbreite ist
häufig sehr begrenzt.

Um solche Herausforderungen zu bewältigen, verwendet *das
Transportsystem* von Reticulum asymmetrische elliptische
Kurvenkryptographie, um das Konzept von *Pfaden* umzusetzen , die es
ermöglichen, herauszufinden, wie Informationen näher an ein bestimmtes
Ziel gebracht werden können. Es ist wichtig zu beachten, dass kein
einzelner Knoten in einem Reticulum-Netzwerk den vollständigen Pfad zu
einem Ziel kennt. Jeder Transportknoten, der an einem Reticulum-Netzwerk
teilnimmt, kennt nur den direktesten Weg, um ein Paket einen Hop näher
an sein Ziel zu bringen.

### <span id="anchor-10"></span>Knotentypen 

Derzeit unterscheidet Reticulum zwischen zwei Typen von Netzwerkknoten.
Alle Knoten in einem Reticulum-Netzwerk sind *Reticulum-Instanzen* und
einige sind auch *Transportknoten* . Wenn ein System, auf dem Reticulum
läuft, an einem Ort fixiert ist und die meiste Zeit verfügbar sein soll,
ist es ein guter Kandidat für die Bezeichnung *Transportknoten* .

Jede Reticulum-Instanz kann zu einem Transportknoten werden, indem sie
in der Konfiguration aktiviert wird. Diese Unterscheidung wird vom
Benutzer vorgenommen, der den Knoten konfiguriert, und wird verwendet,
um zu bestimmen, welche Knoten im Netzwerk den Datenverkehr weiterleiten
und welche Knoten für eine breitere Konnektivität auf andere Knoten
angewiesen sind.

Wenn es sich bei einem Knoten um eine *Instanz* handelt , sollte ihm die
Konfigurationsdirektive zugewiesen werden . Dies ist die
Standardeinstellung.**enable_transport = No**

Wenn es sich um einen *Transportknoten* handelt , sollte ihm die
Konfigurationsdirektive gegeben werden .**enable_transport = Yes**

### <span id="anchor-11"></span>Der Announce-Mechanismus im Detail 

Wenn eine Reticulum-Instanz eine *Ankündigung* für ein Ziel sendet, wird
sie von jedem Transportknoten, der sie empfängt, weitergeleitet,
allerdings gemäß bestimmter Regeln:

- Wenn Sie diese genaue Ankündigung bereits zuvor erhalten haben,
  ignorieren Sie sie.
- Wenn nicht, zeichnen Sie in einer Tabelle auf, von welchem
  ​​Transportknoten die Ankündigung empfangen wurde und wie oft sie
  insgesamt erneut gesendet wurde, um hierher zu gelangen.
- *Wenn die Ankündigung m+1* Mal erneut gesendet wurde , wird sie nicht
  mehr weitergeleitet. Standardmäßig ist *m* auf 128 eingestellt.
- Nach einer zufälligen Verzögerung wird die Ankündigung an alle
  Schnittstellen erneut gesendet, die über Bandbreite für die
  Verarbeitung von Ankündigungen verfügen. Standardmäßig ist die
  maximale Bandbreitenzuweisung für die Verarbeitung von Ankündigungen
  auf 2 % eingestellt, kann aber für jede Schnittstelle einzeln
  konfiguriert werden.
- Wenn für eine bestimmte Schnittstelle nicht genügend Bandbreite zum
  erneuten Senden der Ankündigung zur Verfügung steht, wird der
  Ankündigung eine Priorität zugewiesen, die umgekehrt proportional zur
  Anzahl der Hops ist, und sie wird in eine von der Schnittstelle
  verwaltete Warteschlange eingefügt.
- Wenn die Schnittstelle über die für die Verarbeitung einer Ankündigung
  verfügbare Bandbreite verfügt, werden Ankündigungen für Ziele
  priorisiert, die in Bezug auf die Anzahl der Hops am nächsten liegen.
  Auf diese Weise wird die Erreichbarkeit und Konnektivität lokaler
  Knoten priorisiert, selbst bei langsamen Netzwerken, die mit breiteren
  und schnelleren Netzwerken verbunden sind.
- Nachdem die Ankündigung erneut gesendet wurde und kein anderer Knoten
  zu hören ist, der die Ankündigung mit einer höheren Hop-Anzahl erneut
  sendet als beim Verlassen dieses Knotens, wird die
  Übertragung *r-* mal wiederholt. Standardmäßig ist *r* auf 1
  eingestellt.
- Wenn eine neuere Ankündigung vom gleichen Ziel eintrifft, während eine
  identische bereits auf die Übermittlung wartet, wird die neueste
  Ankündigung verworfen. Wenn die neueste Ankündigung andere
  anwendungsspezifische Daten enthält, wird sie die alte Ankündigung
  ersetzen.

Sobald eine Ankündigung einen Knoten im Netzwerk erreicht hat, kann
jeder andere Knoten, der in direktem Kontakt mit diesem Knoten steht,
das Ziel erreichen, von dem die Ankündigung stammt, indem er einfach ein
an dieses Ziel adressiertes Paket sendet. Jeder Knoten, der von der
Ankündigung Kenntnis hat, kann das Paket zum Ziel leiten, indem er den
nächsten Knoten mit der kürzesten Anzahl von Hops zum Ziel sucht.

Nach diesen Regeln verbreitet sich eine Ankündigung auf vorhersehbare
Weise im gesamten Netzwerk und macht das angekündigte Ziel in kurzer
Zeit erreichbar. Schnelle Netzwerke, die viele Ankündigungen verarbeiten
können, können sehr schnell vollständige Konvergenz erreichen, selbst
wenn ständig neue Ziele hinzugefügt werden. Langsamere Segmente solcher
Netzwerke brauchen möglicherweise etwas länger, um vollständige
Kenntnisse über die breiten und schnellen Netzwerke zu erlangen, mit
denen sie verbunden sind, können dies jedoch im Laufe der Zeit immer
noch tun, während sie die vollständige und schnell konvergierende
End-to-End-Konnektivität für ihre lokalen, langsameren Segmente
priorisieren.

Selbst bei extrem komplexen Netzwerken, die die maximalen 128 Hops
nutzen, wird im Allgemeinen in etwa einer Minute eine vollständige
Ende-zu-Ende-Konnektivität erreicht, vorausgesetzt, es steht ausreichend
Bandbreite zur Verarbeitung der erforderlichen Anzahl an Ankündigungen
zur Verfügung.

### <span id="anchor-12"></span>Das Ziel erreichen 

*In Netzwerken mit wechselnder Topologie und vertrauensloser
Konnektivität müssen Knoten eine Möglichkeit haben, eine verifizierte
Konnektivität* untereinander herzustellen . Da das Netzwerk als
vertrauenslos gilt, muss Reticulum eine Möglichkeit bieten, zu
garantieren, dass der Peer, mit dem Sie kommunizieren, tatsächlich der
ist, den Sie erwarten. Reticulum bietet hierfür zwei Möglichkeiten.

Für den Austausch kleiner Informationsmengen bietet Reticulum
die *Packet* API an, die genau so funktioniert, wie Sie es erwarten
würden – auf Paketebene. Beim Senden eines Pakets wird der folgende
Prozess verwendet:

- Ein Paket wird immer mit einem zugehörigen Ziel und einigen Nutzdaten
  erstellt. Wenn das Paket an einen *einzelnen* Zieltyp gesendet wird,
  erstellt Reticulum automatisch einen flüchtigen
  Verschlüsselungsschlüssel, führt einen ECDH-Schlüsselaustausch mit dem
  öffentlichen Schlüssel des Ziels durch und verschlüsselt die
  Informationen.
- Es ist wichtig zu beachten, dass dieser Schlüsselaustausch keinen
  Netzwerkverkehr erfordert. Der Absender kennt den öffentlichen
  Schlüssel des Ziels bereits aus einer zuvor
  empfangenen *Ankündigung* und kann daher den ECDH-Schlüsselaustausch
  lokal durchführen, bevor er das Paket sendet.
- Der öffentliche Teil des neu generierten flüchtigen Schlüsselpaars ist
  im verschlüsselten Token enthalten und wird zusammen mit den
  verschlüsselten Nutzdaten im Paket gesendet.
- Wenn das Ziel das Paket empfängt, kann es selbst einen
  ECDH-Schlüsselaustausch durchführen und das Paket entschlüsseln.
- Für jedes auf diese Weise gesendete Paket wird ein neuer temporärer
  Schlüssel verwendet.
- Sobald das Paket vom adressierten Ziel empfangen und entschlüsselt
  wurde, kann dieses Ziel den Empfang des Pakets *nachweisen . Dies
  geschieht, indem der SHA-256-Hash des empfangenen Pakets berechnet und
  dieser Hash mit seinem Ed25519-Signaturschlüssel signiert wird.
  Transportknoten im Netzwerk können diesen Nachweis* dann an den
  Ursprung des Pakets zurücksenden, wo die Signatur anhand des bekannten
  öffentlichen Signaturschlüssels des Ziels überprüft werden kann.
- Falls das Paket an einen *Gruppenzieltyp* adressiert ist , wird es mit
  dem vorab freigegebenen AES-128-Schlüssel verschlüsselt, der dem Ziel
  zugeordnet ist. Falls das Paket an einen *einfachen* Zieltyp
  adressiert ist, werden die Nutzdaten nicht verschlüsselt. Keiner
  dieser beiden Zieltypen bietet Vorwärtsgeheimnis. Generell wird
  empfohlen, immer den *einzelnen* Zieltyp zu verwenden, es sei denn, es
  ist unbedingt erforderlich, einen der anderen zu verwenden.

Für den Austausch größerer Datenmengen oder wenn längere bidirektionale
Kommunikationssitzungen gewünscht sind, bietet Reticulum die *Link-* API
an. Um eine *Verbindung* herzustellen , wird der folgende Prozess
verwendet:

- Zunächst sendet der Knoten, der eine Verbindung herstellen möchte, ein
  spezielles Paket aus, das das Netzwerk durchquert und das gewünschte
  Ziel findet. Unterwegs nehmen die Transportknoten, die das Paket
  weiterleiten, diese *Verbindungsanforderung* zur Kenntnis .
- *Zweitens, wenn das Ziel die Verbindungsanforderung* akzeptiert ,
  sendet es ein Paket zurück, das die Echtheit seiner Identität (und den
  Empfang der Verbindungsanforderung) an den initiierenden Knoten
  beweist. Alle Knoten, die das Paket ursprünglich weitergeleitet haben,
  können diesen Beweis ebenfalls überprüfen und somit die Gültigkeit
  der *Verbindung* im gesamten Netzwerk akzeptieren.
- Wenn die Gültigkeit des *Links* von den Weiterleitungsknoten
  akzeptiert wurde, merken sich diese Knoten den *Link* und er kann
  anschließend durch Verweisen auf einen ihn darstellenden Hash
  verwendet werden.
- Als Teil der *Verbindungsanforderung* findet ein Elliptic Curve
  Diffie-Hellman-Schlüsselaustausch statt, der einen effizient
  verschlüsselten Tunnel zwischen den beiden Knoten aufbaut. Daher wird
  dieser Kommunikationsmodus bevorzugt, selbst in Situationen, in denen
  Knoten direkt kommunizieren können, wenn die auszutauschende
  Datenmenge mehrere zehn Pakete umfasst oder wenn die Verwendung der
  erweiterten API-Funktionen gewünscht wird.
- Wenn eine *Verbindung* eingerichtet wurde, stellt sie automatisch eine
  Funktion zum Empfangen von Nachrichten bereit, und zwar über
  denselben *Nachweismechanismus* , der zuvor beschrieben wurde. So kann
  der sendende Knoten eine verifizierte Bestätigung erhalten, dass die
  Informationen den beabsichtigten Empfänger erreicht haben.
- Sobald die *Verbindung* hergestellt wurde, kann der Initiator anonym
  bleiben oder sich gegenüber dem Ziel mit einer Reticulum-Identität
  authentifizieren. Diese Authentifizierung erfolgt innerhalb der
  verschlüsselten Verbindung und wird nur dem verifizierten Ziel und
  keinen Vermittlern angezeigt.

Wir werden gleich auf die Details der Implementierung dieser Methode
eingehen, aber lassen Sie uns zunächst rekapitulieren, welchem ​​Zweck
diese Methode dient. Wir stellen zunächst sicher, dass der Knoten, der
auf unsere Anfrage antwortet, tatsächlich derjenige ist, mit dem wir
kommunizieren möchten, und nicht ein böswilliger Akteur, der dies
vorgibt. Gleichzeitig richten wir einen effizienten verschlüsselten
Kanal ein. Dessen Einrichtung ist in Bezug auf die Bandbreite relativ
günstig, sodass er nur für einen kurzen Austausch verwendet und dann
nach Bedarf neu erstellt werden kann, wobei auch die
Verschlüsselungsschlüssel rotieren. Die Verbindung kann auch für längere
Zeit aufrechterhalten werden, wenn dies für die Anwendung besser
geeignet ist. Das Verfahren fügt auch die *Link-ID* , einen aus dem
Link-Anforderungspaket berechneten Hash, in den Speicher der
Weiterleitungsknoten ein, was bedeutet, dass die kommunizierenden Knoten
sich danach einfach durch Bezugnahme auf diese *Link-ID* erreichen
können .

Die kombinierten Bandbreitenkosten für den Aufbau einer Verbindung
betragen 3 Pakete mit insgesamt 297 Bytes (weitere Informationen im
Abschnitt [Binäres
Paketformat](https://reticulum.network/manual/understanding.html#understanding-packetformat) ).
Die Bandbreite, die zum Offenhalten einer Verbindung verwendet wird, ist
mit 0,45 Bits pro Sekunde praktisch vernachlässigbar. Selbst auf einem
langsamen Paketfunkkanal mit 1200 Bits pro Sekunde bleiben bei 100
gleichzeitigen Verbindungen immer noch 96 % der Kanalkapazität für
eigentliche Daten übrig.

#### Linkaufbau im Detail 

Nachdem wir die Grundlagen des Ankündigungsmechanismus erkundet, einen
Pfad durch das Netzwerk gefunden und einen Überblick über das Verfahren
zum Verbindungsaufbau gegeben haben, werden wir in diesem Abschnitt
ausführlicher auf den Reticulum-Verbindungsaufbauprozess eingehen.

Der *Link* sollte in der Reticulum-Terminologie nicht als direkter
Knoten-zu-Knoten-Link auf der physischen Ebene betrachtet werden,
sondern als abstrakter Kanal, der für eine beliebige Zeitspanne geöffnet
sein kann und eine beliebige Anzahl von Hops umfassen kann, in denen
Informationen zwischen zwei Knoten ausgetauscht werden.

- Wenn ein Knoten im Netzwerk eine verifizierte Verbindung mit einem
  anderen Knoten herstellen möchte, generiert er nach dem Zufallsprinzip
  ein neues privates/öffentliches X25519-Schlüsselpaar. Anschließend
  erstellt er ein *Link-* Anforderungspaket und sendet es.

  *Es ist zu beachten, dass das oben erwähnte öffentliche/private
  Schlüsselpaar X25519 aus zwei separaten Schlüsselpaaren besteht: Ein
  Verschlüsselungsschlüsselpaar, das zur Ableitung eines gemeinsamen
  symmetrischen Schlüssels verwendet wird, und ein
  Signaturschlüsselpaar, das zum Signieren und Überprüfen von
  Nachrichten auf der Verbindung verwendet wird. Sie werden zusammen
  über die Leitung gesendet und können der Einfachheit halber in dieser
  Erklärung als ein einziger öffentlicher Schlüssel betrachtet werden.*

- Die *Link-Anfrage* ist an den Ziel-Hash des gewünschten Ziels
  gerichtet und enthält folgende Daten: Den neu generierten öffentlichen
  Schlüssel X25519 *LKi* .

- Das gesendete Paket wird gemäß den zuvor festgelegten Regeln durch das
  Netzwerk geleitet.

- Jeder Knoten, der die Link-Anforderung weiterleitet, speichert
  eine *Link-ID* in seiner *Link-Tabelle* , zusammen mit der Anzahl der
  Hops, die das Paket beim Empfang durchlaufen hat. Die Link-ID ist ein
  Hash des gesamten Link-Anforderungspakets. Wenn das
  Link-Anforderungspaket nicht innerhalb einer festgelegten Zeitspanne
  vom adressierten Ziel *bestätigt wird, wird der Eintrag erneut aus
  der Link-Tabelle* gelöscht .

- Wenn das Ziel das Link-Anforderungspaket empfängt, entscheidet es, ob
  es die Anforderung akzeptiert. Wenn sie akzeptiert wird, generiert das
  Ziel außerdem ein neues X25519-Schlüsselpaar aus privatem und
  öffentlichem Schlüssel und führt einen
  Diffie-Hellman-Schlüsselaustausch durch, wodurch ein neuer
  symmetrischer Schlüssel abgeleitet wird, der zum Verschlüsseln des
  Kanals verwendet wird, sobald dieser eingerichtet wurde.

- Nun wird ein *Link-Proof-* Paket erstellt und über das Netzwerk
  übertragen. Dieses Paket ist an die *Link-ID* des *Links* adressiert .
  Es enthält die folgenden Daten: Den neu generierten öffentlichen
  X25519-Schlüssel *LKr* und eine Ed25519-Signatur
  der *Link-ID* und *des LKr* , die mit dem *ursprünglichen
  Signaturschlüssel* des adressierten Ziels erstellt wurde.

- Durch die Überprüfung dieses *Link-Proof-* Pakets können nun alle
  Knoten, die das *Link-* Anforderungspaket ursprünglich vom Absender
  zum Ziel transportiert haben, überprüfen, ob das beabsichtigte Ziel
  die Anforderung empfangen und akzeptiert hat und ob der von ihnen für
  die Weiterleitung der Anforderung gewählte Pfad gültig war. Bei
  erfolgreicher Durchführung dieser Überprüfung markiert der
  Transportknoten den Link als aktiv. Entlang eines Pfads im Netzwerk
  wurde nun ein abstrakter bidirektionaler Kommunikationskanal
  eingerichtet. Pakete können nun von beiden Enden des Links
  bidirektional ausgetauscht werden, indem die Pakete einfach an
  die *Link-ID* des Links adressiert werden.

- Wenn die Quelle den *Nachweis* erhält , weiß sie eindeutig, dass ein
  verifizierter Pfad zum Ziel hergestellt wurde. Sie kann nun auch den
  im *Linknachweis* enthaltenen öffentlichen Schlüssel X25519 verwenden
  , um ihren eigenen Diffie-Hellman-Schlüsselaustausch durchzuführen und
  den symmetrischen Schlüssel abzuleiten, der zum Verschlüsseln des
  Kanals verwendet wird. Informationen können nun zuverlässig und sicher
  ausgetauscht werden.

Es ist wichtig zu beachten, dass diese Methode sicherstellt, dass die
Quelle der Anfrage keine identifizierenden Informationen über sich
selbst preisgeben muss. Der Linkinitiator bleibt vollständig anonym.

Bei der Verwendung von *Links* überprüft Reticulum automatisch alle über
den Link gesendeten Daten und kann bei Verwendung *von Ressourcen auch
erneute Übertragungen automatisieren.*

### <span id="anchor-13"></span>Ressourcen 

Für den Austausch kleiner Datenmengen über ein Reticulum-Netzwerk reicht
die [Paketschnittstelle](https://reticulum.network/manual/reference.html#api-packet) aus.
Für den Datenaustausch, der viele Pakete erfordern würde, ist jedoch
eine effiziente Möglichkeit zur Koordination der Übertragung
erforderlich.

Dies ist der Zweck der
Reticulum- [Ressource](https://reticulum.network/manual/reference.html#api-resource) .
Eine *Ressource* kann automatisch die zuverlässige Übertragung einer
beliebigen Datenmenge über eine
bestehende [Verbindung](https://reticulum.network/manual/reference.html#api-link) handhaben
. Ressourcen können Daten automatisch komprimieren, die Aufteilung der
Daten in einzelne Pakete übernehmen, die Sequenzierung der Übertragung,
die Integritätsprüfung und die erneute Zusammenstellung der Daten am
anderen Ende.

[Ressourcen](https://reticulum.network/manual/reference.html#api-resource) sind
programmtechnisch sehr einfach zu verwenden und erfordern nur wenige
Codezeilen, um jede beliebige Datenmenge zuverlässig zu übertragen. Sie
können verwendet werden, um im Speicher gespeicherte Daten zu übertragen
oder Daten direkt aus Dateien zu streamen.

## <span id="anchor-14"></span>Referenz-Setup 

In diesem Abschnitt wird eine empfohlene *Referenzkonfiguration* für
Reticulum ausführlich beschrieben. Es ist wichtig zu beachten, dass
Reticulum so konzipiert ist, dass es auf praktisch jedem Computergerät
und über praktisch jedes Medium verwendet werden kann, mit dem Sie Daten
senden und empfangen können, und dass einige sehr niedrige
Mindestanforderungen erfüllt werden.

Der Kommunikationskanal muss mindestens Halbduplex-Betrieb unterstützen
und einen durchschnittlichen Durchsatz von 5 Bits pro Sekunde oder mehr
bieten sowie eine MTU der physischen Schicht von 500 Bytes unterstützen.
Der Reticulum-Stack sollte auf praktisch jeder Hardware laufen können,
die eine Python 3.x-Laufzeitumgebung bereitstellen kann.

Dieses Referenz-Setup wurde entworfen, um eine gemeinsame Plattform für
alle bereitzustellen, die bei der Entwicklung von Reticulum helfen
möchten, und für alle, die ein empfohlenes Setup kennen möchten, um mit
dem Experimentieren zu beginnen. Ein Referenzsystem besteht aus drei
Teilen:

- **Ein Schnittstellengerät**

  > Bietet Zugriff auf das physische Medium, über das die Kommunikation
  > stattfindet, z. B. ein Radio mit integriertem Modem. Ein Setup mit
  > einem separaten Modem, das an ein Radio angeschlossen ist, wäre
  > ebenfalls ein Schnittstellengerät.

- **Ein Host-Gerät**

  > Eine Art Computergerät, das die erforderliche Software ausführen,
  > mit dem Schnittstellengerät kommunizieren und Benutzerinteraktion
  > ermöglichen kann.

- **Ein Software-Stack**

  > Die Software, die das Reticulum-Protokoll implementiert, und die
  > Anwendungen, die es verwenden.

Das Referenz-Setup kann als relativ stabile Plattform für die
Entwicklung und auch für den Aufbau von Netzwerken oder Anwendungen
angesehen werden. Während sich die Details der Implementierung im
aktuellen Entwicklungsstadium noch ändern können, ist es das Ziel, die
Hardwarekompatibilität so lange wie möglich aufrechtzuerhalten, und das
aktuelle Referenz-Setup wurde so konzipiert, dass es auch in Zukunft
noch viele Jahre lang eine funktionsfähige Plattform bietet. Das
aktuelle Referenzsystem-Setup sieht wie folgt aus:

- **Schnittstellengerät**

  > Ein Datenradio, das aus einem LoRa-Funkmodul und einem
  > Mikrocontroller mit Open-Source-Firmware besteht und über USB mit
  > Host-Geräten verbunden werden kann. Es arbeitet entweder in den
  > Frequenzbändern 430, 868 oder 900 MHz. Weitere Einzelheiten finden
  > Sie auf der [RNode-Seite](https://unsigned.io/rnode) .

- **Host-Gerät**

  > Jedes Computergerät, auf dem Linux und Python läuft. Ein Raspberry
  > Pi mit einem Debian-basierten Betriebssystem wird empfohlen.

- **Software-Stack**

  > Die jüngste veröffentlichte Python-Implementierung von Reticulum,
  > die auf einem Debian-basierten Betriebssystem läuft.

Um Verwirrung zu vermeiden, ist es sehr wichtig zu beachten, dass das
Referenzschnittstellengerät **nicht** den LoRaWAN-Standard verwendet,
sondern eine benutzerdefinierte MAC-Schicht über der einfachen
LoRa-Modulation! Daher benötigen Sie ein einfaches LoRa-Funkmodul, das
an einen Controller mit der richtigen Firmware angeschlossen ist.
Ausführliche Informationen zum Erhalt oder zur Herstellung eines solchen
Geräts finden Sie auf der [RNode-Seite](https://unsigned.io/rnode) .

Mit der aktuellen Referenzkonfiguration sollte es möglich sein, für etwa
100 $ in ein Reticulum-Netzwerk einzusteigen, selbst wenn Sie noch keine
der Hardware besitzen und alles kaufen müssen.

Dieses Referenz-Setup ist natürlich nur eine Empfehlung für den
einfachen Einstieg und Sie sollten es an Ihre eigenen spezifischen
Bedürfnisse bzw. die Ihnen zur Verfügung stehende Hardware anpassen.

## <span id="anchor-15"></span>Protokollspezifikationen 

In diesem Kapitel werden protokollspezifische Informationen ausführlich
beschrieben, die für die Implementierung von Reticulum wichtig sind,
jedoch nicht unbedingt erforderlich sind, um die Funktionsweise des
Protokolls im Allgemeinen zu verstehen. Es sollte eher als Referenz denn
als unverzichtbare Lektüre betrachtet werden.

### Paketpriorisierung 

Derzeit ist Reticulum hinsichtlich des allgemeinen Datenverkehrs völlig
prioritätsunabhängig. Der gesamte Datenverkehr wird nach dem Prinzip
„Wer zuerst kommt, mahlt zuerst“ abgewickelt. Ankündigungen für die
erneute Übertragung werden gemäß den zuvor in diesem Kapitel
beschriebenen Wiederholungszeiten und Prioritäten abgewickelt.

### Schnittstellen-Zugriffscodes 

Reticulum kann benannte virtuelle Netzwerke und Netzwerke erstellen, die
nur mit Kenntnis einer vorab freigegebenen Passphrase zugänglich sind.
Die Konfiguration hierfür wird im Abschnitt [„Gemeinsame
Schnittstellenoptionen“](https://reticulum.network/manual/interfaces.html#interfaces-options) ausführlich
beschrieben . Zur Implementierung dieser Funktion verwendet Reticulum
das Konzept von Schnittstellenzugriffscodes, die pro Paket berechnet und
überprüft werden.

Eine Schnittstelle mit einem benannten virtuellen Netzwerk oder
aktivierter Passphrase-Authentifizierung leitet eine gemeinsame
Ed25519-Signaturidentität ab und generiert für jedes ausgehende Paket
eine Signatur des gesamten Pakets. Diese Signatur wird dann vor der
Übertragung als Schnittstellenzugriffscode in das Paket eingefügt.
Abhängig von der Geschwindigkeit und den Fähigkeiten der Schnittstelle
kann der IFAC die vollständige 512-Bit-Ed25519-Signatur oder eine
gekürzte Version sein. Die konfigurierte IFAC-Länge kann für alle
Schnittstellen mit dem **rnstatus**Dienstprogramm überprüft werden.

Beim Empfang überprüft die Schnittstelle, ob die Signatur mit dem
erwarteten Wert übereinstimmt, und verwirft das Paket, wenn dies nicht
der Fall ist. Dadurch wird sichergestellt, dass nur Pakete mit den
richtigen Benennungs- und/oder Passphrase-Parametern in das Netzwerk
gelangen dürfen.

### <span id="anchor-16"></span>Drahtformat 

<span id="anchor-17"></span>== Reticulum Wire Format ======

A Reticulum packet is composed of the following fields:

\[HEADER 2 bytes\] \[ADDRESSES 16/32 bytes\] \[CONTEXT 1 byte\] \[DATA
0-465 bytes\]

\* The HEADER field is 2 bytes long.

\* Byte 1: \[IFAC Flag\], \[Header Type\], \[Propagation Type\],
\[Destination Type\] and \[Packet Type\]

\* Byte 2: Number of hops

\* Interface Access Code field if the IFAC flag was set.

\* The length of the Interface Access Code can vary from

1 to 64 bytes according to physical interface

capabilities and configuration.

\* The ADDRESSES field contains either 1 or 2 addresses.

\* Each address is 16 bytes long.

\* The Header Type flag in the HEADER field determines

whether the ADDRESSES field contains 1 or 2 addresses.

\* Addresses are SHA-256 hashes truncated to 16 bytes.

\* The CONTEXT field is 1 byte.

\* It is used by Reticulum to determine packet context.

\* The DATA field is between 0 and 465 bytes.

\* It contains the packets data payload.

IFAC Flag

-----------------

open 0 Packet for publically accessible interface

authenticated 1 Interface authentication is included in packet

Header Types

-----------------

type 1 0 Two byte header, one 16 byte address field

type 2 1 Two byte header, two 16 byte address fields

Propagation Types

-----------------

broadcast 00

transport 01

reserved 10

reserved 11

Destination Types

-----------------

single 00

group 01

plain 10

link 11

Packet Types

-----------------

data 00

announce 01

link request 10

proof 11

+- Packet Example -+

HEADER FIELD DESTINATION FIELDS CONTEXT FIELD DATA FIELD

\_\_\_\_\_\_\_|\_\_\_\_\_\_\_
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
\_\_\_\_\_\_\_\_|\_\_\_\_\_\_ \_\_|\_

| | | | | | | |

01010000 00000100 \[HASH1, 16 bytes\] \[HASH2, 16 bytes\] \[CONTEXT, 1
byte\] \[DATA\]

|| | | | |

|| | | | +-- Hops = 4

|| | | +------- Packet Type = DATA

|| | +--------- Destination Type = SINGLE

|| +----------- Propagation Type = TRANSPORT

|+------------- Header Type = HEADER_2 (two byte header, two address
fields)

+-------------- Access Codes = DISABLED

+- Packet Example -+

HEADER FIELD DESTINATION FIELD CONTEXT FIELD DATA FIELD

\_\_\_\_\_\_\_|\_\_\_\_\_\_\_ \_\_\_\_\_\_\_|\_\_\_\_\_\_\_
\_\_\_\_\_\_\_\_|\_\_\_\_\_\_ \_\_|\_

| | | | | | | |

00000000 00000111 \[HASH1, 16 bytes\] \[CONTEXT, 1 byte\] \[DATA\]

|| | | | |

|| | | | +-- Hops = 7

|| | | +------- Packet Type = DATA

|| | +--------- Destination Type = SINGLE

|| +----------- Propagation Type = BROADCAST

|+------------- Header Type = HEADER_1 (two byte header, one address
field)

+-------------- Access Codes = DISABLED

+- Packet Example -+

HEADER FIELD IFAC FIELD DESTINATION FIELD CONTEXT FIELD DATA FIELD

\_\_\_\_\_\_\_|\_\_\_\_\_\_\_ \_\_\_\_\_\_|\_\_\_\_\_\_
\_\_\_\_\_\_\_|\_\_\_\_\_\_\_ \_\_\_\_\_\_\_\_|\_\_\_\_\_\_ \_\_|\_

| | | | | | | | | |

10000000 00000111 \[IFAC, N bytes\] \[HASH1, 16 bytes\] \[CONTEXT, 1
byte\] \[DATA\]

|| | | | |

|| | | | +-- Hops = 7

|| | | +------- Packet Type = DATA

|| | +--------- Destination Type = SINGLE

|| +----------- Propagation Type = BROADCAST

|+------------- Header Type = HEADER_1 (two byte header, one address
field)

+-------------- Access Codes = ENABLED

Size examples of different packet types

---------------------------------------

The following table lists example sizes of various

packet types. The size listed are the complete on-

wire size counting all fields including headers,

but excluding any interface access codes.

\- Path Request : 51 bytes

\- Announce : 167 bytes

\- Link Request : 83 bytes

\- Link Proof : 115 bytes

\- Link RTT packet : 99 bytes

\- Link keepalive : 20 bytes

### <span id="anchor-18"></span>Verbreitungsregeln bekannt geben 

Die folgende Tabelle veranschaulicht die Regeln für die automatische
Verbreitung von Ankündigungen von einem Schnittstellentyp zu einem
anderen, und zwar für alle möglichen Kombinationen. Für die Verbreitung
von Ankündigungen sind die Modi *„Voll* “ und *„Gateway“* identisch.

<img src="https://reticulum.network/manual/_images/if_mode_graph_b.png"
title="imagesif_mode_graph_b.png"
style="width:1.997cm;height:0.998cm" />

Einen konzeptionellen Überblick über die verschiedenen
Schnittstellenmodi und ihre Konfiguration finden Sie im
Abschnitt [„Schnittstellenmodi“
.](https://reticulum.network/manual/interfaces.html#interfaces-modes)

### <span id="anchor-19"></span>Kryptografische Grundelemente 

Reticulum wurde so konzipiert, dass es eine einfache Suite effizienter,
starker und moderner kryptografischer Primitive verwendet, deren
Implementierungen weithin verfügbar sind und sowohl auf Allzweck-CPUs
als auch auf Mikrocontrollern verwendet werden können. Die
erforderlichen Primitive sind:

- Ed25519 für Signaturen

- X25519 für ECDH-Schlüsselaustausch

- HKDF zur Schlüsselableitung

- Fernet für verschlüsselte Token

  - AES-128 im CBC-Modus
  - HMAC zur Nachrichtenauthentifizierung

- SHA-256

- SHA-512

In der Standardinstallationskonfiguration werden die
Primitive **X25519**, **Ed25519**und
von [OpenSSL](https://www.openssl.org/)**AES-128-CBC** bereitgestellt (über
das Paket [PyCA/cryptography](https://github.com/pyca/cryptography) ).
Die Hashfunktionen und werden von der
Standard-Python- [Hashlib](https://docs.python.org/3/library/hashlib.html) bereitgestellt
. Die Primitive , , und die Füllfunktion werden immer von den folgenden
internen Implementierungen
bereitgestellt:**SHA-256SHA-512HKDFHMACFernetPKCS7**

- **RNS/Cryptography/HKDF.py**
- **RNS/Cryptography/HMAC.py**
- **RNS/Cryptography/Fernet.py**
- **RNS/Cryptography/PKCS7.py**

Reticulum enthält außerdem eine vollständige Implementierung aller
erforderlichen Primitive in reinem Python. Wenn OpenSSL und PyCA beim
Start von Reticulum nicht auf dem System verfügbar sind, verwendet
Reticulum stattdessen die internen Primitive in reinem Python. Eine
triviale Folge davon ist die Leistung, da das
OpenSSL-Backend *viel* schneller ist. Die wichtigste Folge ist jedoch
der potenzielle Sicherheitsverlust durch die Verwendung von Primitiven,
die nicht so genau geprüft, getestet und überprüft wurden wie die von
OpenSSL.

Wenn Sie die internen reinen Python-Grundelemente verwenden möchten,
sollten **Sie** sich über die damit verbundenen Risiken im Klaren sein
und eine fundierte Entscheidung darüber treffen, ob diese Risiken für
Sie akzeptabel sind.
