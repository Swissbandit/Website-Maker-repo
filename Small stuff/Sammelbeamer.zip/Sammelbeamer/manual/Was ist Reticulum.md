# Was ist Reticulum?

Reticulum ist ein kryptografiebasierter Netzwerk-Stack zum Aufbau sowohl
lokaler als auch Weitverkehrsnetze mit leicht verfügbarer Hardware, der
auch unter widrigen Bedingungen wie extrem geringer Bandbreite und sehr
hoher Latenz weiterbetrieben werden kann.

Reticulum ermöglicht Ihnen den Aufbau von Weitverkehrsnetzen mit
handelsüblichen Tools und bietet End-to-End-Verschlüsselung,
Vorwärtsgeheimnis, automatisch konfigurierenden, kryptografisch
unterstützten Multi-Hop-Transport, effiziente Adressierung,
fälschungssichere Paketbestätigungen und mehr.

Aus Anwendersicht ermöglicht Reticulum die Erstellung von Anwendungen,
die die Autonomie und Souveränität von Gemeinschaften und Einzelpersonen
respektieren und stärken. Reticulum ermöglicht eine sichere digitale
Kommunikation, die keiner externen Kontrolle, Manipulation oder Zensur
unterworfen werden kann.

Reticulum ermöglicht den Aufbau sowohl kleiner als auch potenziell
planetenweiter Netzwerke, ohne dass zu deren Kontrolle oder Verwaltung
hierarchische oder bürokratische Strukturen erforderlich sind, und
gewährleistet gleichzeitig die volle Souveränität von Einzelpersonen und
Gemeinschaften über ihre eigenen Netzwerksegmente.

Reticulum ist ein **vollständiger Netzwerk-Stack** und benötigt weder IP
noch höhere Schichten, obwohl es einfach ist, IP (mit TCP oder UDP) als
zugrunde liegenden Träger für Reticulum zu verwenden. Es ist daher
trivial, Reticulum über das Internet oder private IP-Netzwerke zu
tunneln. Reticulum basiert direkt auf kryptografischen Prinzipien und
ermöglicht so Ausfallsicherheit und stabile Funktionalität in offenen
und vertrauenslosen Netzwerken.

Es sind keine Kernelmodule oder Treiber erforderlich. Reticulum kann
vollständig im Userland ausgeführt werden und läuft auf praktisch jedem
System, auf dem Python 3 läuft. Reticulum läuft sogar auf kleinen
Einplatinencomputern wie dem Pi Zero gut.

## Aktueller Status 

**Bitte beachten!** Reticulum sollte derzeit als Beta-Software
betrachtet werden. Alle Kernfunktionen des Protokolls sind implementiert
und funktionieren, aber es werden wahrscheinlich Ergänzungen
hinzukommen, wenn die Verwendung in der Praxis erprobt wird. *Es wird
Fehler geben* . Die API und das Wire-Format können derzeit als
vollständig und stabil betrachtet werden, könnten sich aber ändern, wenn
es unbedingt erforderlich ist.

## Was bietet Reticulum? 

- Koordinationslose, weltweit eindeutige Adressierung und Identifikation

- Vollständig selbstkonfigurierendes Multi-Hop-Routing

- Vollständige Anonymität des Initiators, kommunizieren Sie, ohne Ihre
  Identität preiszugeben

- Asymmetrische Verschlüsselung basierend auf X25519 und
  Ed25519-Signaturen als Grundlage für die gesamte Kommunikation

- Forward Secrecy durch Verwendung flüchtiger Elliptic Curve
  Diffie-Hellman-Schlüssel auf Curve25519

- Reticulum verwendet die **Fernet** @ <https://github.com/fernet/spec/blob/master/Spec.md> Spezifikation
  für On-the-Wire / Over-the-Air-Verschlüsselung

  - Alle Schlüssel sind flüchtig und stammen aus einem
    ECDH-Schlüsselaustausch auf Curve25519
  - AES-128 im CBC-Modus mit PKCS7-Padding
  - HMAC verwendet SHA256 zur Authentifizierung
  - IVs werden durch os.urandom() generiert.

- Fälschungssichere Paketzustellungsbestätigungen

- Eine Vielzahl unterstützter Schnittstellentypen

- Eine intuitive und entwicklerfreundliche API

- Effizienter Linkaufbau

  - Die Gesamtkosten für die Einrichtung einer verschlüsselten und
    verifizierten Verbindung betragen nur 3 Pakete mit insgesamt 297
    Bytes
  - Geringe Kosten für die Aufrechterhaltung von Verbindungen mit nur
    0,44 Bit pro Sekunde

- Zuverlässige und effiziente Übertragung beliebiger Datenmengen

  - Reticulum kann einige wenige Bytes Daten oder Dateien mit vielen
    Gigabyte verarbeiten
  - Sequenzierung, Transferkoordination und Prüfsummenbildung erfolgen
    automatisch
  - Die API ist sehr einfach zu bedienen und bietet
    Übertragungsfortschritt

- Authentifizierung und virtuelle Netzwerksegmentierung auf allen
  unterstützten Schnittstellentypen

- Flexible Skalierbarkeit, die die Koexistenz und Interoperabilität von
  Netzwerken mit extrem geringer Bandbreite neben großen Netzwerken mit
  hoher Bandbreite ermöglicht

## Wo kann Reticulum eingesetzt werden? 

Über praktisch jedes Medium, das mindestens einen Halbduplexkanal mit
einem Durchsatz von mehr als 5 Bits pro Sekunde und einer MTU von 500
Bytes unterstützt. Datenfunkgeräte, Modems, LoRa-Funkgeräte, serielle
Leitungen, AX.25-TNCs, digitale Amateurfunkmodi, Ad-hoc-WLAN, optische
Freiraumverbindungen und ähnliche Systeme sind alles Beispiele für die
Schnittstellentypen, für die Reticulum entwickelt wurde.

Eine Open-Source-Schnittstelle auf LoRa-Basis
namens [RNode](https://unsigned.io/rnode) wurde als Beispiel-Transceiver
entwickelt, der sich sehr gut für Reticulum eignet. Sie können ihn
selbst bauen, eine gängige LoRa-Entwicklungsplatine in einen solchen
umwandeln oder ihn als kompletten Transceiver erwerben.

Reticulum kann auch über vorhandene IP-Netzwerke gekapselt werden,
sodass Sie es auch über kabelgebundenes Ethernet oder Ihr lokales
WLAN-Netzwerk verwenden können, wo es genauso gut funktioniert.
Tatsächlich ist eine der Stärken von Reticulum, wie einfach es Ihnen
ermöglicht, verschiedene Medien zu einem selbstkonfigurierenden,
widerstandsfähigen und verschlüsselten Netz zu verbinden.

Beispielsweise ist es möglich, einen Raspberry Pi so einzurichten, dass
er sowohl mit einem LoRa-Radio, einem Packet-Radio-TNC als auch mit
einem WiFi-Netzwerk verbunden ist. Sobald die Schnittstellen hinzugefügt
sind, kümmert sich Reticulum um den Rest und jedes Gerät im
WiFi-Netzwerk kann mit Knoten auf der LoRa- und Packet-Radio-Seite des
Netzwerks kommunizieren und umgekehrt.

## Schnittstellentypen und Geräte 

Reticulum implementiert eine Reihe allgemeiner Schnittstellentypen, die
die Kommunikationshardware abdecken, über die Reticulum laufen kann.
Wenn Ihre Hardware nicht unterstützt wird, ist es relativ einfach, eine
Schnittstellenklasse zu implementieren. Derzeit kann Reticulum die
folgenden Geräte und Kommunikationsmedien verwenden:

- Jedes Ethernet-Gerät

  - WiFi-Geräte
  - Kabelgebundene Ethernet-Geräte
  - Glasfaser-Transceiver
  - Datenfunkgeräte mit Ethernet-Anschlüssen

- LoRa mit [RNode](https://unsigned.io/rnode)

  - [Kann auf vielen gängigen
    LoRa-Boards](https://github.com/markqvist/rnodeconfigutil#supported-devices) installiert
    werden
  - [Kann als gebrauchsfertiger
    Transceiver](https://unsigned.io/rnode) erworben werden

- Packet Radio TNCs, wie [OpenModem](https://unsigned.io/openmodem)

  - Jedes Packetradio-TNC im KISS-Modus
  - Ideal für VHF- und UHF-Radio

- Jedes Gerät mit einem seriellen Anschluss

- Das I2P-Netzwerk

- TCP über IP-Netzwerke

- UDP über IP-Netzwerke

- Alles, was Sie über stdio verbinden können

  - Reticulum kann externe Programme und Pipes als Schnittstellen
    verwenden
  - Damit lassen sich leicht virtuelle Schnittstellen hacken
  - Oder um schnell Schnittstellen mit kundenspezifischer Hardware zu
    erstellen

Eine vollständige Liste und weitere Einzelheiten finden Sie im
Kapitel [[Unterstützte Schnittstellen]].

## Caveat Emptor

Reticulum ist ein experimenteller Netzwerk-Stack und sollte auch als solcher betrachtet werden. 
Obwohl er unter Berücksichtigung der besten kryptografischen Praktiken entwickelt wurde, 
wurde er noch nicht extern auf Sicherheit geprüft und es könnten durchaus Fehler vorhanden sein,
die die Privatsphäre verletzen. 
Um als sicher zu gelten, muss Reticulum einer gründlichen Sicherheitsüberprüfung durch unabhängige Kryptografen
und Sicherheitsforscher unterzogen werden. 
Wenn Sie dabei helfen oder eine Prüfung sponsern möchten, nehmen Sie bitte Kontakt mit uns auf.
