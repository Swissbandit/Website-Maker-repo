# Schnittstellen konfigurieren 

Reticulum unterstützt die Verwendung vieler Arten von Geräten als
Netzwerkschnittstellen und ermöglicht Ihnen, diese nach Belieben zu
kombinieren. Die Anzahl der unterschiedlichen Netzwerktopologien, die
Sie mit Reticulum erstellen können, ist mehr oder weniger endlos. Allen
gemeinsam ist jedoch, dass Sie eine oder
mehrere **Schnittstellen** definieren müssen , die Reticulum verwenden
kann.

Die folgenden Abschnitte beschreiben die derzeit in Reticulum
verfügbaren Schnittstellen und geben Beispielkonfigurationen für die
jeweiligen Schnittstellentypen.

Einen allgemeinen Überblick darüber, wie Netzwerke über verschiedene
Schnittstellentypen gebildet werden können, finden Sie im
Kapitel [„Netzwerke
erstellen“](https://reticulum.network/manual/networks.html#networks-main) dieses
Handbuchs.

## <span id="anchor"></span>Auto-Schnittstelle 

Das Auto Interface ermöglicht die Kommunikation mit anderen erkennbaren
Reticulum-Knoten über automatisch konfiguriertes IPv6 und UDP. Es
benötigt keine funktionale IP-Infrastruktur wie Router oder DHCP-Server,
erfordert aber zumindest eine Art Schaltmedium zwischen den Peers (einen
kabelgebundenen Switch, einen Hub, einen WLAN-Zugangspunkt oder
ähnliches) und dass Link-Local-IPv6 in Ihrem Betriebssystem aktiviert
ist, was in fast allen Betriebssystemen standardmäßig aktiviert sein
sollte.

<span id="anchor-1"></span>\# This example demonstrates a bare-minimum
setup

\# of an Auto Interface. It will allow communica-

\# tion with all other reachable devices on all

\# usable physical ethernet-based devices that

\# are available on the system.

**\[\[**Default Interface**\]\]**

type **=** AutoInterface

interface_enabled **=** **True**

\# This example demonstrates an more specifically

\# configured Auto Interface, that only uses spe-

\# cific physical interfaces, and has a number of

\# other configuration options set.

**\[\[**Default Interface**\]\]**

type **=** AutoInterface

interface_enabled **=** **True**

*\# You can create multiple isolated Reticulum*

*\# networks on the same physical LAN by*

*\# specifying different Group IDs.*

group_id **=** reticulum

*\# You can also choose the multicast address type:*

*\# temporary (default, Temporary Multicast Address)*

*\# or permanent (Permanent Multicast Address)*

multicast_address_type **=** permanent

*\# You can also select specifically which*

*\# kernel networking devices to use.*

devices **=** wlan0**,**eth1

*\# Or let AutoInterface use all suitable*

*\# devices except for a list of ignored ones.*

ignored_devices **=** tun0**,**eth0

Wenn Sie über IPv6 mit dem Internet verbunden sind und Ihr Provider
IPv6-Multicast weiterleitet, können Sie die Auto-Schnittstelle so
konfigurieren, dass andere Reticulum-Knoten innerhalb Ihrer ausgewählten
Gruppen-ID automatisch erkannt werden. Sie können den Erkennungsbereich
angeben, indem Sie ihn auf einen der
Werte **link**, **admin**, **site**, **organisation**oder
setzen **global**.

<span id="anchor-2"></span>**\[\[**Default Interface**\]\]**

type **=** AutoInterface

interface_enabled **=** **True**

*\# Configure global discovery*

group_id **=** custom_network_name

discovery_scope **=** **global**

*\# Other configuration options*

discovery_port **=** **48555**

data_port **=** **49555**

## <span id="anchor-3"></span>I2P-Schnittstelle 

[Mit der I2P-Schnittstelle können Sie Reticulum-Instanzen über das
Invisible Internet Protocol](https://i2pd.website/) verbinden . Dies
kann insbesondere dann nützlich sein, wenn Sie eine global erreichbare
Reticulum-Instanz hosten möchten, aber keinen Zugriff auf öffentliche
IP-Adressen haben, Ihre IP-Adresse häufig wechselt oder Firewalls den
eingehenden Datenverkehr blockieren.

Mithilfe der I2P-Schnittstelle erhalten Sie eine global erreichbare,
portable und dauerhafte I2P-Adresse, unter der Ihre Reticulum-Instanz
erreichbar ist.

Um die I2P-Schnittstelle verwenden zu können, muss auf Ihrem System ein
I2P-Router laufen. Am einfachsten erreichen Sie dies, indem Sie
die [neueste
Version](https://github.com/PurpleI2P/i2pd/releases/latest) des **i2pd**Pakets
herunterladen und installieren. Weitere Einzelheiten zu I2P finden Sie
auf der [Website geti2p.net](https://geti2p.net/en/about/intro) .

Wenn auf Ihrem System ein I2P-Router läuft, können Sie Reticulum einfach
eine I2P-Schnittstelle hinzufügen:

<span id="anchor-4"></span>**\[\[**I2P**\]\]**

type **=** I2PInterface

interface_enabled **=** yes

connectable **=** yes

Beim ersten Start generiert Reticulum eine neue I2P-Adresse für die
Schnittstelle und beginnt, auf eingehenden Datenverkehr zu warten. Dies
kann beim ersten Mal eine Weile dauern, insbesondere wenn Ihr I2P-Router
ebenfalls gerade erst gestartet wurde und noch nicht gut mit dem
I2P-Netzwerk verbunden ist. Wenn Sie fertig sind, sollte die
I2P-Base32-Adresse in Ihrer Protokolldatei angezeigt werden. Sie können
den Status der Schnittstelle auch mit dem **rnstatus**Dienstprogramm
überprüfen.

**peers**Um über I2P eine Verbindung zu anderen Reticulum-Instanzen
herzustellen, fügen Sie der Option der Schnittstelle einfach eine durch
Kommas getrennte Liste von I2P-Base32-Adressen hinzu :

<span id="anchor-5"></span>**\[\[**I2P**\]\]**

type **=** I2PInterface

interface_enabled **=** yes

connectable **=** yes

peers **=**
**5**urvjicpzi7q3ybztsef4i5ow2aq4soktfj7zedz53s47r54jnqq**.**b32**.**i2p

Das Herstellen von I2P-Verbindungen zu den gewünschten Peers kann
zwischen einigen Sekunden und einigen Minuten dauern, daher verarbeitet
Reticulum den Vorgang im Hintergrund und gibt relevante Ereignisse in
das Protokoll aus.

**Bitte beachten!** Während die I2P-Schnittstelle die einfachste
Möglichkeit ist, Reticulum über I2P zu verwenden, ist es auch möglich,
die TCP-Server- und Client-Schnittstellen manuell über I2P zu tunneln.
Dies kann in Situationen nützlich sein, in denen mehr Kontrolle
erforderlich ist, erfordert jedoch eine manuelle Tunneleinrichtung über
die I2P-Daemon-Konfiguration.

Es ist wichtig zu beachten, dass die beiden Methoden *austauschbar und
kompatibel* sind . Sie können beispielsweise die I2P-Schnittstelle
verwenden, um eine Verbindung zu einer TCP-Serverschnittstelle
herzustellen, die manuell über I2P getunnelt wurde. Dies bietet ein
hohes Maß an Flexibilität bei der Netzwerkeinrichtung und bleibt
gleichzeitig in einfacheren Anwendungsfällen benutzerfreundlich.

## <span id="anchor-6"></span>TCP-Serverschnittstelle 

Die TCP-Serverschnittstelle eignet sich dazu, anderen Peers die
Verbindung über das Internet oder private IP-Netzwerke zu ermöglichen.
Wenn eine TCP-Serverschnittstelle konfiguriert wurde, können andere
Reticulum-Peers über eine TCP-Clientschnittstelle eine Verbindung zu ihr
herstellen.

<span id="anchor-7"></span>\# This example demonstrates a TCP server
interface.

\# It will listen for incoming connections on the

\# specified IP address and port number.

**\[\[**TCP Server Interface**\]\]**

type **=** TCPServerInterface

interface_enabled **=** **True**

*\# This configuration will listen on all IP*

*\# interfaces on port 4242*

listen_ip **=** **0.0.0.0**

listen_port **=** **4242**

*\# Alternatively you can bind to a specific IP*

*\# listen_ip = 10.0.0.88*

*\# listen_port = 4242*

*\# Or a specific network device*

*\# device = eth0*

*\# port = 4242*

**Bitte beachten!** Die TCP-Schnittstellen unterstützen Tunneling über
I2P, aber um dies zuverlässig zu tun, müssen Sie die Option i2p_tunneled
verwenden:

<span id="anchor-8"></span>**\[\[**TCP Server on I2P**\]\]**

type **=** TCPServerInterface

interface_enabled **=** yes

listen_ip **=** **127.0.0.1**

listen_port **=** **5001**

i2p_tunneled **=** yes

In fast allen Fällen ist es einfacher, den dedizierten zu
verwenden **I2PInterface**, aber für die vollständige Kontrolle und die
Verwendung von I2P-Routern, die auf externen Systemen laufen, besteht
auch diese Option.

## <span id="anchor-9"></span>TCP-Client-Schnittstelle 

Um eine Verbindung zu einer TCP-Serverschnittstelle herzustellen,
verwenden Sie natürlich die TCP-Clientschnittstelle. Mehrere
TCP-Clientschnittstellen von verschiedenen Peers können gleichzeitig
eine Verbindung zur gleichen TCP-Serverschnittstelle herstellen.

Die TCP-Schnittstellentypen können auch Unterbrechungen in der
IP-Verbindungsschicht tolerieren. Das bedeutet, dass Reticulum
IP-Verbindungen, die hoch- und herunterfallen, problemlos handhabt und
die Verbindung nach einem Fehler wiederherstellt, sobald das andere Ende
einer TCP-Schnittstelle wieder verfügbar ist.

<span id="anchor-10"></span>\# Here's an example of a TCP Client
interface. The

\# target_host can either be an IP address or a hostname.

**\[\[**TCP Client Interface**\]\]**

type **=** TCPClientInterface

interface_enabled **=** **True**

target_host **=** **127.0.0.1**

target_port **=** **4242**

Es ist auch möglich, diesen Schnittstellentyp zu verwenden, um
Verbindungen über andere Programme oder Hardwaregeräte herzustellen, die
eine KISS-Schnittstelle auf einem TCP-Port bereitstellen, beispielsweise
softwarebasierte Soundmodems. Verwenden Sie dazu
die **kiss_framing**Option:

<span id="anchor-11"></span>\# Here's an example of a TCP Client
interface that connects

\# to a software TNC soundmodem on a KISS over TCP port.

**\[\[**TCP KISS Interface**\]\]**

type **=** TCPClientInterface

interface_enabled **=** **True**

kiss_framing **=** **True**

target_host **=** **127.0.0.1**

target_port **=** **8001**

**Achtung!** Verwenden Sie die KISS-Framing-Option nur, wenn Sie über
TCP eine Verbindung zu externen Geräten und Programmen wie Soundmodems
und Ähnlichem herstellen. Wenn Sie **TCPClientInterface**in Verbindung
mit verwenden **TCPServerInterface**, sollten Sie niemals
aktivieren **kiss_framing**, da dadurch interne Zuverlässigkeits- und
Wiederherstellungsmechanismen deaktiviert werden, die die Leistung bei
unzuverlässigen und zeitweiligen TCP-Verbindungen erheblich verbessern.

**Bitte beachten!** Die TCP-Schnittstellen unterstützen Tunneling über
I2P, aber um dies zuverlässig zu tun, müssen Sie die Option i2p_tunneled
verwenden:

<span id="anchor-12"></span>**\[\[**TCP Client over I2P**\]\]**

type **=** TCPClientInterface

interface_enabled **=** yes

target_host **=** **127.0.0.1**

target_port **=** **5001**

i2p_tunneled **=** yes

## <span id="anchor-13"></span>UDP-Schnittstelle 

Eine UDP-Schnittstelle kann für die Kommunikation über IP-Netzwerke
(privat und Internet) nützlich sein. Sie kann auch
Broadcast-Kommunikation über IP-Netzwerke ermöglichen und so eine
einfache Möglichkeit bieten, die Verbindung mit allen anderen Peers in
einem lokalen Netzwerk herzustellen.

*Bitte beachten!* Die Verwendung von Broadcast-UDP-Verkehr hat
Auswirkungen auf die Leistung, insbesondere bei WLAN. Wenn Ihr Ziel
lediglich darin besteht, eine einfache Kommunikation mit allen Peers in
Ihrer lokalen Ethernet-Broadcast-Domäne zu ermöglichen, ist die
Leistung [des Auto
Interface](https://reticulum.network/manual/interfaces.html#interfaces-auto) besser
und sogar noch einfacher zu verwenden.

<span id="anchor-14"></span>\# This example enables communication with
other

\# local Reticulum peers over UDP.

**\[\[**UDP Interface**\]\]**

type **=** UDPInterface

interface_enabled **=** **True**

listen_ip **=** **0.0.0.0**

listen_port **=** **4242**

forward_ip **=** **255.255.255.255**

forward_port **=** **4242**

*\# The above configuration will allow communication*

*\# within the local broadcast domains of all local*

*\# IP interfaces.*

*\# Instead of specifying listen_ip, listen_port,*

*\# forward_ip and forward_port, you can also bind*

*\# to a specific network device like below.*

*\# device = eth0*

*\# port = 4242*

*\# Assuming the eth0 device has the address*

*\# 10.55.0.72/24, the above configuration would*

*\# be equivalent to the following manual setup.*

*\# Note that we are both listening and forwarding to*

*\# the broadcast address of the network segments.*

*\# listen_ip = 10.55.0.255*

*\# listen_port = 4242*

*\# forward_ip = 10.55.0.255*

*\# forward_port = 4242*

*\# You can of course also communicate only with*

*\# a single IP address*

*\# listen_ip = 10.55.0.15*

*\# listen_port = 4242*

*\# forward_ip = 10.55.0.16*

*\# forward_port = 4242*

## <span id="anchor-15"></span>RNode LoRa-Schnittstelle 

Um Reticulum über LoRa zu verwenden, kann die [RNode- Schnittstelle
verwendet werden und bietet vollständige Kontrolle über die
LoRa-Parameter.](https://unsigned.io/rnode/)

<span id="anchor-16"></span>\# Here's an example of how to add a LoRa
interface

\# using the RNode LoRa transceiver.

**\[\[**RNode LoRa Interface**\]\]**

type **=** RNodeInterface

*\# Enable interface if you want use it!*

interface_enabled **=** **True**

*\# Serial port for the device*

port **=** **/**dev**/**ttyUSB0

*\# Set frequency to 867.2 MHz*

frequency **=** **867200000**

*\# Set LoRa bandwidth to 125 KHz*

bandwidth **=** **125000**

*\# Set TX power to 7 dBm (5 mW)*

txpower **=** **7**

*\# Select spreading factor 8. Valid*

*\# range is 7 through 12, with 7*

*\# being the fastest and 12 having*

*\# the longest range.*

spreadingfactor **=** **8**

*\# Select coding rate 5. Valid range*

*\# is 5 throough 8, with 5 being the*

*\# fastest, and 8 the longest range.*

codingrate **=** **5**

*\# You can configure the RNode to send*

*\# out identification on the channel with*

*\# a set interval by configuring the*

*\# following two parameters.*

*\# id_callsign = MYCALL-0*

*\# id_interval = 600*

*\# For certain homebrew RNode interfaces*

*\# with low amounts of RAM, using packet*

*\# flow control can be useful. By default*

*\# it is disabled.*

*\# flow_control = False*

*\# It is possible to limit the airtime*

*\# utilisation of an RNode by using the*

*\# following two configuration options.*

*\# The short-term limit is applied in a*

*\# window of approximately 15 seconds,*

*\# and the long-term limit is enforced*

*\# over a rolling 60 minute window. Both*

*\# options are specified in percent.*

*\# airtime_limit_long = 1.5*

*\# airtime_limit_short = 33*

## <span id="anchor-17"></span>Serielle Schnittstelle 

Reticulum kann direkt über serielle Schnittstellen oder über jedes Gerät
mit einer seriellen Schnittstelle verwendet werden, das Daten
transparent überträgt. Nützlich für die direkte Kommunikation über ein
Kabelpaar oder für die Verwendung von Geräten wie Datenradios und
Lasern.

<span id="anchor-18"></span>**\[\[**Serial Interface**\]\]**

type **=** SerialInterface

interface_enabled **=** **True**

*\# Serial port for the device*

port **=** **/**dev**/**ttyUSB0

*\# Set the serial baud-rate and other*

*\# configuration parameters.*

speed **=** **115200**

databits **=** **8**

parity **=** none

stopbits **=** **1**

## <span id="anchor-19"></span>Pipe-Schnittstelle 

*Mithilfe dieser Schnittstelle kann Reticulum jedes Programm über
stdin* und *stdout* als Schnittstelle verwenden . Damit können ganz
einfach virtuelle Schnittstellen erstellt oder eine Schnittstelle zu
benutzerdefinierter Hardware oder anderen Systemen hergestellt werden.

<span id="anchor-20"></span>**\[\[**Pipe Interface**\]\]**

type **=** PipeInterface

interface_enabled **=** **True**

*\# External command to execute*

command **=** netcat **-**l **5757**

*\# Optional respawn delay, in seconds*

respawn_delay **=** **5**

Reticulum schreibt alle Pakete auf *die
Standardeingabe* der **command**Option und liest und durchsucht
kontinuierlich seine *Standardausgabe* nach Reticulum-Paketen. Wenn
dieser **EOF**Wert erreicht ist, versucht Reticulum nach einer Wartezeit
von **respawn_interval**einigen Sekunden, das Programm neu zu starten.

## <span id="anchor-21"></span>KISS-Schnittstelle 

Mit der KISS-Schnittstelle können Sie Reticulum über eine Vielzahl von
Packet-Radio-Modems und TNCs,
einschließlich [OpenModem](https://unsigned.io/openmodem/) , verwenden .
KISS-Schnittstellen können auch so konfiguriert werden, dass sie
regelmäßig Beacons zur Stationsidentifikation aussenden.

<span id="anchor-22"></span>**\[\[**Packet Radio KISS Interface**\]\]**

type **=** KISSInterface

interface_enabled **=** **True**

*\# Serial port for the device*

port **=** **/**dev**/**ttyUSB1

*\# Set the serial baud-rate and other*

*\# configuration parameters.*

speed **=** **115200**

databits **=** **8**

parity **=** none

stopbits **=** **1**

*\# Set the modem preamble.*

preamble **=** **150**

*\# Set the modem TX tail.*

txtail **=** **10**

*\# Configure CDMA parameters. These*

*\# settings are reasonable defaults.*

persistence **=** **200**

slottime **=** **20**

*\# You can configure the interface to send*

*\# out identification on the channel with*

*\# a set interval by configuring the*

*\# following two parameters. The KISS*

*\# interface will only ID if the set*

*\# interval has elapsed since it's last*

*\# actual transmission. The interval is*

*\# configured in seconds.*

*\# This option is commented out and not*

*\# used by default.*

*\# id_callsign = MYCALL-0*

*\# id_interval = 600*

*\# Whether to use KISS flow-control.*

*\# This is useful for modems that have*

*\# a small internal packet buffer, but*

*\# support packet flow control instead.*

flow_control **=** false

## <span id="anchor-23"></span>AX.25 KISS-Schnittstelle 

Wenn Sie Reticulum im Amateurfunkspektrum verwenden, möchten Sie
möglicherweise die AX.25 KISS-Schnittstelle verwenden. Auf diese Weise
kapselt Reticulum seinen Datenverkehr automatisch in AX.25 und
identifiziert die Übertragungen Ihrer Stationen außerdem mit Ihrem
Rufzeichen und Ihrer SSID.

Tun Sie dies nur, wenn es wirklich nötig ist! Reticulum benötigt die
AX.25-Schicht für nichts und verursacht zusätzlichen Overhead bei der
Einkapselung jedes Pakets in AX.25.

Effizienter ist die Verwendung der einfachen KISS-Schnittstelle mit der
oben beschriebenen Beaconing-Funktionalität.

<span id="anchor-24"></span>**\[\[**Packet Radio AX**.25** KISS
Interface**\]\]**

type **=** AX25KISSInterface

*\# Set the station callsign and SSID*

callsign **=** NO1CLL

ssid **=** **0**

*\# Enable interface if you want use it!*

interface_enabled **=** **True**

*\# Serial port for the device*

port **=** **/**dev**/**ttyUSB2

*\# Set the serial baud-rate and other*

*\# configuration parameters.*

speed **=** **115200**

databits **=** **8**

parity **=** none

stopbits **=** **1**

*\# Set the modem preamble. A 150ms*

*\# preamble should be a reasonable*

*\# default, but may need to be*

*\# increased for radios with slow-*

*\# opening squelch and long TX/RX*

*\# turnaround*

preamble **=** **150**

*\# Set the modem TX tail. In most*

*\# cases this should be kept as low*

*\# as possible to not waste airtime.*

txtail **=** **10**

*\# Configure CDMA parameters. These*

*\# settings are reasonable defaults.*

persistence **=** **200**

slottime **=** **20**

*\# Whether to use KISS flow-control.*

*\# This is useful for modems with a*

*\# small internal packet buffer.*

flow_control **=** false

## <span id="anchor-25"></span>Gemeinsame Schnittstellenoptionen 

Für die meisten Schnittstellen stehen eine Reihe allgemeiner
Konfigurationsoptionen zur Verfügung. Mit diesen können verschiedene
Aspekte des Schnittstellenverhaltens gesteuert werden.

- Die **enabled**Option teilt Reticulum mit, ob die Schnittstelle
  > angezeigt werden soll oder nicht. Der Standardwert ist **False**.
  > Damit eine Schnittstelle angezeigt werden kann, muss die Option
  > auf oder **enabled**gesetzt sein .**TrueYes**

- Die **mode**Option ermöglicht die Auswahl des High-Level-Verhaltens
  > der Schnittstelle aus einer Reihe von Optionen.

  - Der Standardwert ist **full**. In diesem Modus sind alle
    > Erkennungs-, Vernetzungs- und Transportfunktionen verfügbar.

  - Im Modus **access_point**(oder Kurzform **ap**) fungiert die
    > Schnittstelle als Netzwerkzugriffspunkt. In diesem Modus werden
    > Ankündigungen nicht automatisch über die Schnittstelle gesendet
    > und Pfade zu Zielen auf der Schnittstelle haben eine viel kürzere
    > Ablaufzeit. Dieser Modus ist nützlich, um Schnittstellen zu
    > erstellen, die größtenteils ruhig sind, es sei denn, jemand
    > verwendet sie tatsächlich. Ein Beispiel hierfür könnte eine
    > Funkschnittstelle sein, die ein weites Gebiet bedient, bei der
    > Benutzer sich kurz verbinden, das Netzwerk verwenden und dann
    > wieder verschwinden sollen.

- Die **outgoing**Option legt fest, ob eine Schnittstelle senden darf.
  > Der Standardwert ist . Wenn oder **True**festgelegt ist, empfängt
  > die Schnittstelle nur Daten und sendet nie.**FalseNo**

- Die **network_name**Option legt den virtuellen Netzwerknamen für die
  > Schnittstelle fest. Dadurch können mehrere separate Netzwerksegmente
  > auf demselben physischen Kanal oder Medium vorhanden sein.

- Die **passphrase**Option legt eine Authentifizierungspassphrase für
  > die Schnittstelle fest. Diese Option kann in Verbindung mit
  > der **network_name**Option oder allein verwendet werden.

- Mit dieser **ifac_size**Option können Sie die Länge der
  > Schnittstellenauthentifizierungscodes anpassen, die von jedem Paket
  > in benannten und/oder authentifizierten Netzwerksegmenten übertragen
  > werden. Sie ist standardmäßig auf eine für die jeweilige
  > Schnittstelle geeignete Größe eingestellt, kann aber mit dieser
  > Option auf eine benutzerdefinierte Größe zwischen 8 und 512 Bit
  > eingestellt werden. Bei normaler Verwendung sollte diese Option
  > nicht von der Standardeinstellung geändert werden.

- Mit dieser **announce_cap**Option können Sie die maximale Bandbreite
  > konfigurieren, die zu einem bestimmten Zeitpunkt für die Verbreitung
  > von Ankündigungen und anderen Netzwerkwartungsverkehr zugewiesen
  > werden soll. Die Standardeinstellung ist 2 % und muss normalerweise
  > nicht geändert werden. Kann auf jeden Wert zwischen **1**und
  > eingestellt werden **100**.

  > *Wenn eine Schnittstelle ihre Ankündigungskapazität überschreitet,
  > werden Ankündigungen für eine spätere Übertragung in die
  > Warteschlange gestellt. Reticulum priorisiert immer zuerst die
  > Verbreitung von Ankündigungen von nahegelegenen Knoten. Dadurch wird
  > sichergestellt, dass die lokale Topologie priorisiert wird und
  > langsame Netzwerke nicht durch miteinander verbundene schnelle
  > Netzwerke überlastet werden.*

  > *Ziele, die schnell neue Ankündigungen machen, werden weiter
  > herabgestuft. Der Versuch, durch Ankündigungs-Spam „First-in-Line“
  > zu werden, hat genau den gegenteiligen Effekt: Sie werden jedes Mal
  > ans Ende der Warteschlange verschoben, wenn eine neue Ankündigung
  > von dem Ziel mit den vielen Ankündigungen eingeht.*

  > *Dies bedeutet, dass es immer von Vorteil ist, eine ausgewogene
  > Ankündigungsrate auszuwählen und nicht häufiger Ankündigungen zu
  > machen, als für die Funktion Ihrer Anwendung tatsächlich
  > erforderlich ist.*

- Mit dieser **bitrate**Option wird die Schnittstellenbitrate
  > konfiguriert. Reticulum verwendet die von der Hardware gemeldete
  > Schnittstellengeschwindigkeit oder versucht, eine geeignete Rate zu
  > erraten, wenn die Hardware keine meldet. In den meisten Fällen
  > sollte die automatisch ermittelte Rate ausreichen, sie kann jedoch
  > mit der Option „Schnittstellengeschwindigkeit in *Bits pro
  > Sekunde*bitrate** festlegen“ konfiguriert werden .

## <span id="anchor-26"></span>Schnittstellenmodi 

Die optionale **mode**Einstellung ist auf allen Schnittstellen verfügbar
und ermöglicht die Auswahl des High-Level-Verhaltens der Schnittstelle
aus einer Reihe von Modi. Diese Modi beeinflussen, wie Reticulum Pfade
im Netzwerk auswählt, wie Ankündigungen verbreitet werden, wie lange
Pfade gültig sind und wie Pfade erkannt werden.

Das Konfigurieren von Schnittstellenmodi ist **nicht** unbedingt
erforderlich, kann aber beim Erstellen oder Verbinden mit komplexeren
Netzwerken nützlich sein. Wenn Ihre Reticulum-Instanz keinen
Transportknoten ausführt, ist das Konfigurieren von Schnittstellenmodi
selten sinnvoll. In solchen Fällen sollten Schnittstellen im Allgemeinen
im Standardmodus belassen werden.

- Der Standardmodus ist **full**. In diesem Modus sind sämtliche
  > Erkennungs-, Vernetzungs- und Transportfunktionen aktiviert.

- Der **gateway**Modus (oder die Kurzform **gw**) verfügt ebenfalls über
  > alle Funktionen für Erkennung, Vernetzung und Transport, versucht
  > aber zusätzlich, unbekannte Pfade im Auftrag anderer Knoten zu
  > erkennen, die sich auf der **gateway**Schnittstelle befinden. Wenn
  > Reticulum von einem Knoten auf einer Schnittstelle eine
  > Pfadanforderung für ein unbekanntes Ziel
  > empfängt, **gateway**versucht es, diesen Pfad über alle anderen
  > aktiven Schnittstellen zu erkennen und leitet den erkannten Pfad an
  > den Anforderer weiter, wenn einer gefunden wird.

  > Wenn Sie anderen Knoten erlauben möchten, Pfade umfassend aufzulösen
  > oder sich über eine Schnittstelle mit einem Netzwerk zu verbinden,
  > kann es sinnvoll sein, diesen Modus zu aktivieren. Durch die
  > Erstellung einer Schnittstellenkette **gateway**können andere Knoten
  > sofort Pfade zu jedem Ziel entlang der Kette finden.

  > *Bitte beachten!* Damit dies funktioniert, muss die
  > Schnittstelle *zu den Clients* in den -Modus versetzt werden , nicht
  > die Schnittstelle zum weiteren Netzwerk (hierfür kann der -Modus
  > jedoch nützlich sein).**gatewayboundary**

- Im Modus **access_point**(oder Kurzform **ap**) fungiert die
  > Schnittstelle als Netzwerkzugriffspunkt. In diesem Modus werden
  > Ankündigungen nicht automatisch über die Schnittstelle gesendet und
  > Pfade zu Zielen auf der Schnittstelle haben eine viel kürzere
  > Ablaufzeit. Darüber hinaus werden Pfadanfragen von Clients auf der
  > Zugriffspunktschnittstelle auf die gleiche Weise behandelt wie
  > die **gateway**Schnittstelle.

  > Dieser Modus ist nützlich, um Schnittstellen zu erstellen, die ruhig
  > bleiben, bis jemand sie tatsächlich verwendet. Ein Beispiel hierfür
  > könnte eine Funkschnittstelle sein, die ein weites Gebiet bedient,
  > bei der Benutzer sich kurz verbinden, das Netzwerk verwenden und
  > dann wieder verschwinden.

- Der **roaming**Modus sollte bei Schnittstellen verwendet werden, die
  > aus der Perspektive anderer Knoten im Netzwerk Roaming betreiben
  > (physisch mobil sind). Wenn ein Fahrzeug beispielsweise mit einer
  > externen LoRa-Schnittstelle und einer internen, WiFi-basierten
  > Schnittstelle ausgestattet ist, die Geräte bedient, die
  > sich *mit* dem Fahrzeug bewegen, sollte die externe
  > LoRa-Schnittstelle als konfiguriert werden **roaming**und die
  > interne Schnittstelle kann im Standardmodus belassen werden. Wenn
  > der Transport aktiviert ist, können bei einer solchen Konfiguration
  > alle internen Geräte einander und alle anderen Geräte, die auf der
  > LoRa-Seite des Netzwerks verfügbar sind, erreichen, wenn sie in
  > Reichweite sind. Geräte auf der LoRa-Seite des Netzwerks können auch
  > Geräte innerhalb des Fahrzeugs erreichen, wenn dieses in Reichweite
  > ist. Pfade über **roaming**Schnittstellen laufen auch schneller ab.

- Der Zweck des **boundary**Modus besteht darin, Schnittstellen
  > anzugeben, die eine Verbindung zu Netzwerksegmenten herstellen, die
  > sich erheblich von dem unterscheiden, in dem sich dieser Knoten
  > befindet. Wenn beispielsweise eine Reticulum-Instanz Teil eines
  > LoRa-basierten Netzwerks ist, aber auch über eine
  > Hochgeschwindigkeitsverbindung zu einem öffentlichen Transportknoten
  > verfügt, der im Internet verfügbar ist, sollte die Schnittstelle,
  > die über das Internet eine Verbindung herstellt, auf
  > den **boundary**Modus eingestellt werden.

Eine Tabelle mit einer Beschreibung der Auswirkungen aller Modi auf die
Ankündigungsausbreitung finden Sie im Abschnitt „ [Regeln für die
Ankündigungsausbreitung“](https://reticulum.network/manual/understanding.html#understanding-announcepropagation) .

## <span id="anchor-27"></span>Rate Control ankündigen 

Die integrierten Kontrollmechanismen für Ankündigungen und
die **announce_cap** oben beschriebene Standardoption reichen in den
meisten Fällen aus, aber in manchen Fällen, insbesondere bei schnellen
Schnittstellen, kann es sinnvoll sein, die Zielankündigungsrate zu
steuern. Mit den
Optionen **announce_rate_target**, **announce_rate_grace**und **announce_rate_penalty** kann
dies für jede Schnittstelle einzeln erfolgen und die *Rate regulieren,
mit der empfangene Ankündigungen an andere Schnittstellen weitergeleitet
werden* .

- Die **announce_rate_target**Option legt die Mindestzeit in Sekunden
  > fest, die zwischen empfangenen Ankündigungen für ein Ziel vergehen
  > soll. Wenn Sie diesen Wert beispielsweise auf
  > festlegen, **3600**bedeutet dies, dass Ankündigungen, die über diese
  > Schnittstelle *empfangen werden* , nur einmal pro Stunde erneut
  > gesendet und an andere Schnittstellen weitergeleitet werden,
  > unabhängig davon, wie oft sie empfangen werden.

- Die Option **announce_rate_grace**definiert, wie oft ein Ziel die
  > Ankündigungsrate verletzen kann, bevor die Zielrate erzwungen wird.

- Mit dieser Option **announce_rate_penalty**können Sie eine zusätzliche
  > Zeitspanne konfigurieren, die zum normalen Ratenziel hinzugefügt
  > wird. Wenn beispielsweise eine Strafe von **7200**Sekunden definiert
  > ist, werden die Ankündigungen des betreffenden Ziels nach der
  > Durchsetzung des Ratenziels nur alle 3 Stunden verbreitet, bis die
  > tatsächliche Ankündigungsrate auf das Ziel gesenkt wird.

Diese Mechanismen in Verbindung mit den **annouce_cap**oben genannten
Mechanismen bedeuten, dass es wichtig ist, eine ausgewogene
Ankündigungsstrategie für Ihre Ziele auszuwählen. Je ausgewogener Sie
diese Entscheidung treffen können, desto einfacher wird es für Ihre
Ziele, in langsamere Netzwerke zu gelangen, die viele Hops entfernt
sind. Oder Sie können priorisieren, nur Netzwerke mit hoher Kapazität
mit häufigeren Ankündigungen zu erreichen.

Aktuelle Statistiken und Informationen zu Announcement-Raten können mit
dem Befehl eingesehen werden.**rnpath -r**

Es ist wichtig zu beachten, dass es keinen richtigen oder falschen Weg
gibt, Ankündigungsraten einzurichten. Langsamere Netzwerke tendieren
natürlich dazu, weniger häufige Ankündigungen zu verwenden, um
Bandbreite zu sparen, während sehr schnelle Netzwerke Anwendungen
unterstützen können, die sehr häufige Ankündigungen benötigen. Reticulum
implementiert diese Mechanismen, um sicherzustellen, dass eine große
Bandbreite an Netzwerktypen nahtlos *koexistieren* und miteinander
verbunden werden kann.

## <span id="anchor-28"></span>Neue Zielratenbegrenzung 

Bei öffentlichen Schnittstellen, bei denen sich jeder verbinden und neue
Ziele ankündigen kann, kann es sinnvoll sein, die Rate zu steuern, mit
der Ankündigungen für *neue* Ziele verarbeitet werden.

Kommt es innerhalb kurzer Zeit zu einem großen Zustrom von Ankündigungen
für neu erstellte oder bislang unbekannte Ziele, stellt Reticulum diese
Ankündigungen zurück, damit der Ankündigungsverkehr für bekannte und
bereits etablierte Ziele ohne Unterbrechungen weiter verarbeitet werden
kann.

Nachdem der Burst abgeklungen ist und eine zusätzliche Wartezeit
verstrichen ist, werden die zurückgehaltenen Ankündigungen langsam
freigegeben, bis die Warteschlange geleert ist. Das bedeutet auch, dass,
wenn sich ein Knoten entscheidet, eine Verbindung zu einer öffentlichen
Schnittstelle herzustellen, eine große Anzahl falscher Ziele ankündigt
und dann die Verbindung trennt, diese Ziele nie in die Pfadtabellen
gelangen und Netzwerkbandbreite für erneut übertragene Ankündigungen
verschwenden.

**Es ist wichtig zu beachten** , dass die Eingangskontrolle auf der
Ebene *einzelner Subschnittstellen* funktioniert . Das bedeutet
beispielsweise, dass ein Client an
einer [TCP-Serverschnittstelle](https://reticulum.network/manual/interfaces.html#interfaces-tcps) die
Verarbeitung eingehender Ankündigungen für andere verbundene Clients an
derselben [TCP-Serverschnittstelle](https://reticulum.network/manual/interfaces.html#interfaces-tcps) nicht
unterbrechen kann . Für alle anderen Clients an derselben Schnittstelle
werden neue Ankündigungen weiterhin ohne Unterbrechung verarbeitet.

Standardmäßig wird Reticulum dies automatisch handhaben und die Ingress
Announce-Steuerung wird auf der Schnittstelle aktiviert, wo dies
sinnvoll ist. Es sollte im Allgemeinen nicht notwendig sein, die
Ingress-Steuerungskonfiguration zu ändern, aber alle Parameter werden
bei Bedarf zur Konfiguration bereitgestellt.

- Die **ingress_control**Option teilt Reticulum mit, ob die
  > Ankündigungs-Eingangskontrolle auf der Schnittstelle aktiviert
  > werden soll oder nicht. Der Standardwert ist **True**.

- Die **ic_new_time**Option konfiguriert, wie lange (in Sekunden) eine
  > Schnittstelle als neu erstellt gilt. Der Standardwert
  > ist **2\*60\*60**Sekunden. Diese Option ist bei öffentlich
  > zugänglichen Schnittstellen nützlich, die neue Unterschnittstellen
  > erstellen, wenn ein neuer Client eine Verbindung herstellt.

- Die **ic_burst_freq_new**Option legt die maximale Ankündigungsfrequenz
  > für neu erstellte Schnittstellen fest. Der Standardwert
  > ist **3.5** Ankündigungen pro Sekunde.

- Mit dieser **ic_burst_freq**Option legen Sie die maximale Häufigkeit
  > eingehender Ankündigungen für andere Schnittstellen fest. Der
  > Standardwert sind **12**Ankündigungen pro Sekunde.

  > *Überschreitet eine Schnittstelle ihre Burst-Frequenz, werden
  > eingehende Ankündigungen für unbekannte Ziele vorübergehend in einer
  > Warteschlange zurückgehalten und erst später verarbeitet.*

- Mit dieser **ic_max_held_announces**Option wird die maximale Anzahl
  > eindeutiger Ankündigungen festgelegt, die in der Warteschlange
  > gehalten werden. Alle weiteren eindeutigen Ankündigungen werden
  > gelöscht. Standardmäßig werden **256**Ankündigungen verwendet.

- Die **ic_burst_hold**Option legt fest, wie viel Zeit (in Sekunden)
  > vergehen muss, nachdem die Burst-Frequenz unter ihren Schwellenwert
  > gefallen ist, damit der Ankündigungsburst als gelöscht gilt. Der
  > Standardwert ist **60** Sekunden.

- Mit dieser **ic_burst_penalty**Option legen Sie fest, wie viel Zeit
  > (in Sekunden) vergehen muss, nachdem der Burst als gelöscht gilt,
  > bevor angehaltene Ankündigungen aus der Warteschlange freigegeben
  > werden können. Der Standardwert ist **5\*60** Sekunden.

- Mit dieser **ic_held_release_interval**Option legen Sie fest, wie viel
  > Zeit (in Sekunden) zwischen der Freigabe jeder gehaltenen
  > Ankündigung aus der Warteschlange vergehen muss. Der Standardwert
  > ist **30**Sekunden.
