# API-Referenz 

Die Kommunikation über Reticulum-Netzwerke wird mithilfe eines einfachen
Satzes von Klassen erreicht, die von der RNS-API bereitgestellt werden.
Dieses Kapitel listet alle von der Reticulum Network Stack API
bereitgestellten Klassen auf und erläutert sie zusammen mit ihren
Methodensignaturen und ihrer Verwendung. Es kann als Referenz beim
Schreiben von Anwendungen verwendet werden, die Reticulum verwenden,
oder es kann vollständig gelesen werden, um ein Verständnis der
vollständigen Funktionalität von RNS aus der Sicht eines Entwicklers zu
erlangen.

### <span id="anchor"></span>Netzhaut

<span id="anchor-1"></span>****Klasse ****RNS. **Reticulum ( ******configdir = Keine****** ,****** loglevel = Keine****** ,****** logdest = Keine****** ,****** verbosity = Keine****** ) **

> Diese Klasse wird verwendet, um den Zugriff auf Reticulum innerhalb
> eines Programms zu initialisieren. Sie müssen genau eine Instanz
> dieser Klasse erstellen, bevor Sie andere RNS-Vorgänge ausführen, z.
> B. Ziele erstellen oder Datenverkehr senden. Jedes unabhängig
> ausgeführte Programm muss seine eigene Instanz der Reticulum-Klasse
> erstellen, aber Reticulum übernimmt automatisch die Kommunikation
> zwischen Programmen auf demselben System und stellt alle verbundenen
> Programme auch externen Schnittstellen zur Verfügung.

> Sobald eine Instanz dieser Klasse erstellt wurde, beginnt Reticulum
> mit dem Öffnen und Konfigurieren aller in der bereitgestellten
> Konfiguration angegebenen Hardwaregeräte.

> Derzeit muss die erste laufende Instanz weiterlaufen, während andere
> lokale Instanzen verbunden sind, da die erste erstellte Instanz als
> Masterinstanz fungiert, die direkt mit externer Hardware wie Modems,
> TNCs und Radios kommuniziert. Wenn eine Masterinstanz zum Beenden
> aufgefordert wird, wird sie erst beendet, wenn alle Clientprozesse
> beendet wurden (es sei denn, sie werden zwangsweise beendet).

> Wenn Sie Reticulum auf einem System mit mehreren verschiedenen
> Programmen ausführen, die RNS verwenden und zu unterschiedlichen
> Zeiten starten und beenden, ist es von Vorteil, eine
> Master-RNS-Instanz als Daemon auszuführen, damit andere Programme sie
> bei Bedarf verwenden können.

> <span id="anchor-2"></span>**PERSON ******= 500****[** **](https://reticulum.network/manual/reference.html#RNS.Reticulum.MTU)[\#](https://reticulum.network/manual/reference.html#RNS.Reticulum.MTU)

> Die MTU, die Reticulum einhält und von der auch andere Peers erwartet,
> dass sie sie einhalten. Standardmäßig beträgt die MTU 500 Byte. In
> benutzerdefinierten RNS-Netzwerkimplementierungen ist es möglich,
> diesen Wert zu ändern, aber dadurch wird die Kompatibilität mit allen
> anderen RNS-Netzwerken vollständig aufgehoben. Eine identische MTU ist
> Voraussetzung dafür, dass Peers im selben Netzwerk kommunizieren
> können.

> Sofern Sie nicht wirklich wissen, was Sie tun, sollten Sie die MTU auf
> dem Standardwert belassen.

> <span id="anchor-3"></span>**ANNOUNCE_CAP ******= 2****[** **](https://reticulum.network/manual/reference.html#RNS.Reticulum.ANNOUNCE_CAP)[\#](https://reticulum.network/manual/reference.html#RNS.Reticulum.ANNOUNCE_CAP)

> Der maximale Prozentsatz der Schnittstellenbandbreite, der zu einem
> bestimmten Zeitpunkt zur Verbreitung von Ankündigungen verwendet
> werden kann. Wenn eine Ankündigung für die Übertragung über eine
> Schnittstelle geplant war, dies jedoch die zulässige
> Bandbreitenzuweisung überschreiten würde, wird die Ankündigung zur
> Übertragung in die Warteschlange gestellt, wenn Bandbreite verfügbar
> ist.

> Reticulum priorisiert immer die Verbreitung von Ankündigungen mit
> weniger Hops und stellt so sicher, dass weit entfernte, große
> Netzwerke mit vielen Peers auf schnellen Verbindungen die Kapazität
> kleinerer Netzwerke auf langsameren Medien nicht überfordern. Wenn
> eine Ankündigung längere Zeit in der Warteschlange bleibt, wird sie
> schließlich gelöscht.

> Dieser Wert wird standardmäßig auf alle erstellten Schnittstellen
> angewendet, kann aber für jede Schnittstelle einzeln konfiguriert
> werden. Im Allgemeinen sollte die globale Standardeinstellung nicht
> geändert werden. Änderungen sollten stattdessen für jede Schnittstelle
> einzeln vorgenommen werden.

> <span id="anchor-4"></span>**MINIMUM_BITRATE ******= 5****[** **](https://reticulum.network/manual/reference.html#RNS.Reticulum.MINIMUM_BITRATE)[\#](https://reticulum.network/manual/reference.html#RNS.Reticulum.MINIMUM_BITRATE)

> Mindestbitrate, die über ein Medium erforderlich ist, damit Reticulum
> erfolgreich Verbindungen herstellen kann. Derzeit 5 Bits pro Sekunde.

> <span id="anchor-5"></span>****statische ******get_instance ( ) **

> Gibt die aktuell ausgeführte Reticulum-Instanz zurück

> <span id="anchor-6"></span>****statischer ******sollte_implicit_proof_verwenden ( ) **

> Gibt zurück, ob die gesendeten Nachweise explizit oder implizit sind.

> KEHRT ZURÜCK :

> „True“, wenn die aktuell ausgeführte Konfiguration die Verwendung
> impliziter Beweise angibt. „False“, wenn nicht.

> <span id="anchor-7"></span>****statischer ******transport_enabled ( ) **

> Gibt zurück, ob der Transport für die laufende Instanz aktiviert ist.

> Wenn Transport aktiviert ist, leitet Reticulum den Datenverkehr für
> andere Peers weiter, antwortet auf Pfadanforderungen und leitet
> Ankündigungen über das Netzwerk weiter.

> KEHRT ZURÜCK :

> „True“, wenn Transport aktiviert ist, „False“, wenn nicht.

### <span id="anchor-8"></span>Identität

<span id="anchor-9"></span>****Klasse ****RNS.Identität** ( ******create_keys = True****** ) **[\#](https://reticulum.network/manual/reference.html#RNS.Identity)**​**

> Diese Klasse wird zur Verwaltung von Identitäten in Reticulum
> verwendet. Sie bietet Methoden zur Verschlüsselung, Entschlüsselung,
> Signatur und Verifizierung und ist die Grundlage für die gesamte
> verschlüsselte Kommunikation über Reticulum-Netzwerke.

> PARAMETER :

> **create_keys** – Gibt an, ob neue Verschlüsselungs- und
> Signaturschlüssel generiert werden sollen.

> <span id="anchor-10"></span>**KURVE ******= 'Kurve25519'****[** **](https://reticulum.network/manual/reference.html#RNS.Identity.CURVE)[\#](https://reticulum.network/manual/reference.html#RNS.Identity.CURVE)

> Die für den Elliptic Curve DH-Schlüsselaustausch verwendete Kurve

> <span id="anchor-11"></span>**SCHLÜSSELGRÖSSE ******= 512****[** **](https://reticulum.network/manual/reference.html#RNS.Identity.KEYSIZE)[\#](https://reticulum.network/manual/reference.html#RNS.Identity.KEYSIZE)

> X25519-Schlüsselgröße in Bits. Ein vollständiger Schlüssel ist die
> Verkettung eines 256-Bit-Verschlüsselungsschlüssels und eines
> 256-Bit-Signaturschlüssels.

> <span id="anchor-12"></span>**TRUNCATED_HASHLENGTH ******= 128****[** **](https://reticulum.network/manual/reference.html#RNS.Identity.TRUNCATED_HASHLENGTH)[\#](https://reticulum.network/manual/reference.html#RNS.Identity.TRUNCATED_HASHLENGTH)

> Konstante, die die gekürzte Hash-Länge (in Bits) angibt, die von
> Reticulum für adressierbare Hashes und andere Zwecke verwendet wird.
> Nicht konfigurierbar.

> <span id="anchor-13"></span>****statischer ******Rückruf ( ******Ziel-Hash****** ) **

> Identität für einen Ziel-Hash zurückrufen.

> PARAMETER :

> **destination_hash** – Ziel-Hash in **Bytes** .

> KEHRT ZURÜCK :

> Eine [RNS.Identity -Instanz, die zum Erstellen eines
> ausgehenden ](https://reticulum.network/manual/reference.html#api-identity)[RNS.Destination](https://reticulum.network/manual/reference.html#api-destination) verwendet
> werden kann , oder **None** , wenn das Ziel unbekannt ist.

> <span id="anchor-14"></span>****statische ******Recall_App_Data ( ******Ziel-Hash****** ) **

> Rufen Sie die zuletzt gehörten App-Daten für einen Ziel-Hash ab.

> PARAMETER :

> **destination_hash** – Ziel-Hash in **Bytes** .

> KEHRT ZURÜCK :

> **Bytes,** die App-Daten enthalten, oder **Keine** , wenn das Ziel
> unbekannt ist.

> <span id="anchor-15"></span>****statischer ******full_hash ( ******Daten****** ) **

> Holen Sie sich einen SHA-256-Hash der übermittelten Daten.

> PARAMETER :

> **Daten – Als ****Bytes** zu hashende Daten .

> KEHRT ZURÜCK :

> SHA-256-Hash als **Bytes**

> <span id="anchor-16"></span>****statischer ******truncated_hash ( ******Daten****** ) **

> Holen Sie sich einen gekürzten SHA-256-Hash der übermittelten Daten.

> PARAMETER :

> **Daten – Als ****Bytes** zu hashende Daten .

> KEHRT ZURÜCK :

> Abgeschnittener SHA-256-Hash als **Bytes**

> <span id="anchor-17"></span>****statischer ******get_random_hash ( ) **

> Holen Sie sich einen zufälligen SHA-256-Hash.

> PARAMETER :

> **Daten – Als ****Bytes** zu hashende Daten .

> KEHRT ZURÜCK :

> Abgeschnittener SHA-256-Hash von Zufallsdaten als **Bytes**

> <span id="anchor-18"></span>****statische ******from_bytes ( ******prv_bytes****** ) **

> Erstellen Sie eine
> neue [RNS.Identity](https://reticulum.network/manual/reference.html#api-identity) -Instanz
> aus **Bytes** des privaten Schlüssels. Kann verwendet werden, um zuvor
> erstellte und gespeicherte Identitäten in Reticulum zu laden.

> PARAMETER :

> **prv_bytes** – Die **Bytes** eines gespeicherten privaten
> Schlüssels. **ACHTUNG!** Verwenden Sie dies niemals, um einen neuen
> Schlüssel zu generieren, indem Sie zufällige Daten in prv_bytes
> eingeben.

> KEHRT ZURÜCK :

> Eine [RNS.Identity-](https://reticulum.network/manual/reference.html#api-identity) Instanz
> oder **Keine** , wenn die **Bytedaten** ungültig waren.

> <span id="anchor-19"></span>****statische ******From_File ( ******Pfad****** ) **

> Erstellt eine
> neue [RNS.Identity](https://reticulum.network/manual/reference.html#api-identity) -Instanz
> aus einer Datei. Kann verwendet werden, um zuvor erstellte und
> gespeicherte Identitäten in Reticulum zu laden.

> PARAMETER :

> **Pfad** – Der vollständige Pfad zu den
> gespeicherten [RNS.Identity](https://reticulum.network/manual/reference.html#api-identity) -Daten

> KEHRT ZURÜCK :

> Eine [RNS.Identity-](https://reticulum.network/manual/reference.html#api-identity) Instanz
> oder **Keine** , wenn die geladenen Daten ungültig waren.

> <span id="anchor-20"></span>**to_file ( ******Pfad****** ) **

> Speichert die Identität in einer Datei. Dadurch wird der private
> Schlüssel auf die Festplatte geschrieben und jeder mit Zugriff auf
> diese Datei kann die gesamte Kommunikation für die Identität
> entschlüsseln. Gehen Sie bei dieser Methode sehr vorsichtig vor.

> PARAMETER :

> **Pfad** – Der vollständige Pfad, der angibt, wo die Identität
> gespeichert werden soll.

> KEHRT ZURÜCK :

> Wahr, wenn die Datei gespeichert wurde, andernfalls Falsch.

> <span id="anchor-21"></span>get_private_key ( ) 

> KEHRT ZURÜCK :

> Der private Schlüssel als **Bytes**

> <span id="anchor-22"></span>get_public_key ( ) 

> KEHRT ZURÜCK :

> Der öffentliche Schlüssel als **Bytes**

> <span id="anchor-23"></span>**lade_private_schlüssel ( ******prv_bytes****** ) **

> Laden Sie einen privaten Schlüssel in die Instanz.

> PARAMETER :

> **prv_bytes** – Der private Schlüssel als **Bytes** .

> KEHRT ZURÜCK :

> Wahr, wenn der Schlüssel geladen wurde, andernfalls Falsch.

> <span id="anchor-24"></span>**lade_öffentlichen_Schlüssel ( ******pub_bytes****** ) **

> Laden Sie einen öffentlichen Schlüssel in die Instanz.

> PARAMETER :

> **pub_bytes** – Der öffentliche Schlüssel als **Bytes** .

> KEHRT ZURÜCK :

> Wahr, wenn der Schlüssel geladen wurde, andernfalls Falsch.

> <span id="anchor-25"></span>**verschlüsseln ( ******Klartext****** ) **

> Verschlüsselt Informationen für die Identität.

> PARAMETER :

> **Klartext – Der als ****Bytes** zu verschlüsselnde Klartext .

> KEHRT ZURÜCK :

> Chiffretext-Token als **Bytes** .

> ERHÖHT SICH UM :

> **KeyError** , wenn die Instanz keinen öffentlichen Schlüssel besitzt.

> <span id="anchor-26"></span>**entschlüsseln ( ******ciphertext_token****** ) **

> Entschlüsselt Informationen für die Identität.

> PARAMETER :

> **Chiffretext – Der als ****Bytes** zu entschlüsselnde Chiffretext .

> KEHRT ZURÜCK :

> Klartext als **Bytes** oder **Keine** , wenn die Entschlüsselung
> fehlschlägt.

> ERHÖHT SICH UM :

> **KeyError** , wenn die Instanz keinen privaten Schlüssel besitzt.

> <span id="anchor-27"></span>**Zeichen ( ******Nachricht****** ) **

> Kennzeichnet Informationen anhand der Identität.

> PARAMETER :

> **Nachricht – Die als ****Bytes** zu signierende Nachricht .

> KEHRT ZURÜCK :

> Signatur als **Bytes** .

> ERHÖHT SICH UM :

> **KeyError** , wenn die Instanz keinen privaten Schlüssel besitzt.

> <span id="anchor-28"></span>**validieren ( ******Signatur****** ,****** Nachricht****** ) **

> Validiert die Signatur einer signierten Nachricht.

> PARAMETER :

- **Signatur** – Die zu validierende Signatur in **Bytes** .

- **Nachricht** – Die zu validierende Nachricht in **Bytes** .

> KEHRT ZURÜCK :

> Wahr, wenn die Signatur gültig ist, andernfalls Falsch.

> ERHÖHT SICH UM :

> **KeyError** , wenn die Instanz keinen öffentlichen Schlüssel besitzt.

### <span id="anchor-29"></span>Ziel

<span id="anchor-30"></span>****Klasse ****RNS. **Ziel ( ******Identität****** ,****** Richtung****** ,****** Typ****** ,****** App-Name****** ,****** \* Aspekte****** ) **

> Eine Klasse, die zur Beschreibung von Endpunkten in einem
> Reticulum-Netzwerk verwendet wird. Zielinstanzen werden sowohl zum
> Erstellen ausgehender als auch eingehender Endpunkte verwendet. Der
> Zieltyp entscheidet, ob und welche Verschlüsselung bei der
> Kommunikation mit dem Endpunkt verwendet wird. Ein Ziel kann auch
> seine Präsenz im Netzwerk ankündigen, wodurch auch die erforderlichen
> Schlüssel für die verschlüsselte Kommunikation mit ihm verteilt
> werden.

> PARAMETER :

- **Identität** – Eine Instanz
  > von [RNS.Identity](https://reticulum.network/manual/reference.html#api-identity) .
  > Kann nur öffentliche Schlüssel für ein ausgehendes Ziel oder private
  > Schlüssel für ein eingehendes Ziel enthalten.

- **Richtung** – **RNS.Destination.IN**oder **RNS.Destination.OUT**.

- **Geben
  > Sie** – **RNS.Destination.SINGLE**, **RNS.Destination.GROUP**oder
  > ein **RNS.Destination.PLAIN**.

- **app_name** – Eine Zeichenfolge, die den App-Namen angibt.

- **\*Aspekte** – Jede beliebige Anzahl von Zeichenfolgenargumenten
  > ungleich Null.

> <span id="anchor-31"></span>****static ******expand_name ( ******Identität****** ,****** App-Name****** ,****** \* Aspekte****** ) **

> KEHRT ZURÜCK :

> Eine Zeichenfolge, die den vollständigen, für Menschen lesbaren Namen
> des Ziels für einen App-Namen und eine Reihe von Aspekten enthält.

> <span id="anchor-32"></span>****static ******app_and_aspects_from_name ( ******vollständiger_Name****** ) **

> KEHRT ZURÜCK :

> Ein Tupel, das den App-Namen und eine Liste von Aspekten für eine
> vollständige Namenszeichenfolge enthält.

> <span id="anchor-33"></span>****static ******hash_from_name_and_identity ( ******vollständiger_Name****** ,****** Identität****** ) **

> KEHRT ZURÜCK :

> Ein Zielname in adressierbarer Hash-Form für eine vollständige
> Namenszeichenfolge und eine Identitätsinstanz.

> <span id="anchor-34"></span>****statischer ******Hash ( ******Identität****** ,****** App-Name****** ,****** \* Aspekte****** ) **

> KEHRT ZURÜCK :

> Ein Zielname in adressierbarer Hash-Form für einen App-Namen und eine
> Reihe von Aspekten.

> <span id="anchor-35"></span>**ankündigen ( ******app_data = Keine****** ,****** path_response = False****** ,****** attached_interface = Keine****** ,****** tag = Keine****** ,****** send = True****** ) **

> Erstellt ein Ankündigungspaket für dieses Ziel und sendet es an alle
> relevanten Schnittstellen. Der Ankündigung können
> anwendungsspezifische Daten hinzugefügt werden.

> PARAMETER :

- **app_data** – **Bytes,** die die app_data enthalten.

- **path_response** – Internes Flag, das
  > von [RNS.Transport](https://reticulum.network/manual/reference.html#api-transport) verwendet
  > wird . Ignorieren.

> <span id="anchor-36"></span>**accepts_links ( ******accepts = Keine****** ) **

> Festlegen oder Abfragen, ob das Ziel eingehende Linkanforderungen
> akzeptiert.

> PARAMETER :

> **accepts** – Wenn **True**oder **False**, legt diese Methode fest, ob
> das Ziel eingehende Linkanforderungen akzeptiert. Wenn nicht angegeben
> oder **None**, gibt die Methode zurück, ob das Ziel derzeit
> Linkanforderungen akzeptiert.

> KEHRT ZURÜCK :

> **True**oder **False**abhängig davon, ob das Ziel eingehende
> Linkanforderungen akzeptiert, wenn der Parameter **„accepts“** nicht
> angegeben ist oder **None**.

> <span id="anchor-37"></span>**set_link_established_callback ( ******Rückruf****** ) **

> Registriert eine Funktion, die aufgerufen werden soll, wenn eine
> Verknüpfung zu diesem Ziel hergestellt wurde.

> PARAMETER :

> **callback** – Eine Funktion oder Methode mit der
> Signatur **callback(link),** die aufgerufen werden soll, wenn eine
> neue Verbindung zu diesem Ziel hergestellt wird.

> <span id="anchor-38"></span>**set_packet_callback ( ******Rückruf****** ) **

> Registriert eine Funktion, die aufgerufen werden soll, wenn ein Paket
> von diesem Ziel empfangen wurde.

> PARAMETER :

> **Rückruf** – Eine Funktion oder Methode mit der Signatur **„Rückruf
> (Daten, Paket)“,** die aufgerufen werden soll, wenn dieses Ziel ein
> Paket empfängt.

> <span id="anchor-39"></span>**set_proof_requested_callback ( ******Rückruf****** ) **

> Registriert eine Funktion, die aufgerufen wird, wenn ein Nachweis für
> ein an dieses Ziel gesendetes Paket angefordert wurde. Ermöglicht die
> Kontrolle darüber, wann und ob Nachweise für empfangene Pakete
> zurückgegeben werden sollen.

> PARAMETER :

> **callback** – Eine Funktion oder Methode mit der
> Signatur **callback(packet),** die aufgerufen wird, wenn ein Paket
> empfangen wird, das einen Nachweis anfordert. Der Rückruf muss
> entweder True oder False zurückgeben. Wenn der Rückruf True
> zurückgibt, wird ein Nachweis gesendet. Wenn er False zurückgibt, wird
> kein Nachweis gesendet.

> <span id="anchor-40"></span>**set_proof_strategy ( ******Beweisstrategie****** ) **

> Legt die Proof-Strategie des Ziels fest.

> PARAMETER :

> **proof_strategy** – Eines
> von **RNS.Destination.PROVE_NONE**, **RNS.Destination.PROVE_ALL**oder **RNS.Destination.PROVE_APP**.
> Wenn **RNS.Destination.PROVE_APP**gesetzt
> ist, wird **proof_requested_callback aufgerufen, um zu bestimmen, ob
> ein Proof gesendet werden soll oder nicht.**

> <span id="anchor-41"></span>**register_request_handler ( ******Pfad****** ,****** Antwortgenerator = Keiner****** ,****** erlauben = ALLOW_NONE****** ,****** erlaubte_Liste = Keiner****** ) **

> Registriert einen Anforderungshandler.

> PARAMETER :

- **Pfad** – Der Pfad für den zu registrierenden Anforderungshandler.

- **response_generator** – Eine Funktion oder Methode mit der
  > Signatur **response_generator(path, data, request_id, link_id,
  > remote_identity, requested_at),** die aufgerufen werden soll. Was
  > auch immer diese Funktion zurückgibt, wird als Antwort an den
  > Anforderer gesendet. Wenn die Funktion zurückgibt **None**, wird
  > keine Antwort gesendet.

- **allow** – Eines
  > von **RNS.Destination.ALLOW_NONE**, **RNS.Destination.ALLOW_ALL**oder **RNS.Destination.ALLOW_LIST**.
  > Wenn **RNS.Destination.ALLOW_LIST**gesetzt ist, antwortet der
  > Anforderungshandler nur auf Anforderungen für identifizierte Peers
  > in der bereitgestellten Liste.

- **allowed_list** – Eine
  > Liste **byteähnlicher **[RNS.Identity-](https://reticulum.network/manual/reference.html#api-identity) Hashes.

> ERHÖHT SICH UM :

> **ValueError**wenn eines der angegebenen Argumente ungültig ist.

> <span id="anchor-42"></span>**deregister_request_handler ( ******Pfad****** ) **

> Meldet einen Anforderungshandler ab.

> PARAMETER :

> **Pfad** – Der Pfad für den abzumeldenden Anforderungshandler.

> KEHRT ZURÜCK :

> Wahr, wenn der Handler abgemeldet wurde, andernfalls Falsch.

> <span id="anchor-43"></span>Schlüssel erstellen ( ) 

> Erstellt für ein **RNS.Destination.GROUP**Typziel einen neuen
> symmetrischen Schlüssel.

> ERHÖHT SICH UM :

> **TypeError**wenn es für einen inkompatiblen Zieltyp aufgerufen wird.

> <span id="anchor-44"></span>get_private_key ( ) 

> Gibt für ein **RNS.Destination.GROUP**Typziel den symmetrischen
> privaten Schlüssel zurück.

> ERHÖHT SICH UM :

> **TypeError**wenn es für einen inkompatiblen Zieltyp aufgerufen wird.

> <span id="anchor-45"></span>**load_private_key ( ******Schlüssel****** ) **

> Lädt für ein **RNS.Destination.GROUP**Typziel einen symmetrischen
> privaten Schlüssel.

> PARAMETER :

> **Schlüssel** – Eine **byteähnliche Einheit,** die den symmetrischen
> Schlüssel enthält.

> ERHÖHT SICH UM :

> **TypeError**wenn es für einen inkompatiblen Zieltyp aufgerufen wird.

> <span id="anchor-46"></span>**verschlüsseln ( ******Klartext****** ) **

> Verschlüsselt Informationen
> für **RNS.Destination.SINGLE**oder **RNS.Destination.GROUP**gibt das
> Ziel ein.

> PARAMETER :

> **Klartext** – Eine **byteähnliche Datei,** die den zu
> verschlüsselnden Klartext enthält.

> ERHÖHT SICH UM :

> **ValueError**wenn das Ziel nicht über einen für die Verschlüsselung
> erforderlichen Schlüssel verfügt.

> <span id="anchor-47"></span>**entschlüsseln ( ******Chiffretext****** ) **

> Entschlüsselt Informationen
> für **RNS.Destination.SINGLE**oder **RNS.Destination.GROUP**gibt das
> Ziel ein.

> PARAMETER :

> **Chiffretext** – **Bytes** , die den zu entschlüsselnden Chiffretext
> enthalten.

> ERHÖHT SICH UM :

> **ValueError**wenn das Ziel nicht über den erforderlichen Schlüssel
> zur Entschlüsselung verfügt.

> <span id="anchor-48"></span>**Zeichen ( ******Nachricht****** ) **

> Gibt Informationen zum **RNS.Destination.SINGLE**Typziel an.

> PARAMETER :

> **Nachricht** – **Bytes,** die die zu signierende Nachricht enthalten.

> KEHRT ZURÜCK :

> Eine **byteähnliche Datei,** die die Signatur der Nachricht enthält,
> oder **„None“** , wenn das Ziel die Nachricht nicht signieren konnte.

> <span id="anchor-49"></span>**set_default_app_data ( ******app_data = Keine****** ) **

> Legt die Standard-App-Daten für das Ziel fest. Wenn festgelegt, werden
> die Standard-App-Daten in jede vom Ziel gesendete Ankündigung
> aufgenommen, sofern in der **Ankündigungsmethode** keine anderen
> App-Daten angegeben sind .

> PARAMETER :

> **app_data** – Eine **byteähnliche Datei,** die die Standard-App-Daten
> enthält, oder eine **aufrufbare Datei , die eine byteähnliche
> Datei** zurückgibt, die die App-Daten enthält.

> <span id="anchor-50"></span>Standardanwendungsdaten löschen ( ) 

> Löscht die zuvor für das Ziel festgelegten Standard-App-Daten.

### <span id="anchor-51"></span>Paket

<span id="anchor-52"></span>****Klasse ****RNS.Paket** ( ******Ziel****** ,****** Daten****** ,****** create_receipt = True****** ) **[\#](https://reticulum.network/manual/reference.html#RNS.Packet)**​**

> Die Klasse Packet wird verwendet, um Paketinstanzen zu erstellen, die
> über ein Reticulum-Netzwerk gesendet werden können. Pakete werden
> automatisch verschlüsselt, wenn sie an
> ein **RNS.Destination.SINGLE**Ziel, **RNS.Destination.GROUP**eine
> Destination oder
> einen [RNS.Link](https://reticulum.network/manual/reference.html#api-link) adressiert
> sind .

> Für **RNS.Destination.GROUP**Ziele verwendet Reticulum den für das
> Ziel konfigurierten Pre-Shared Key. Alle Pakete an Gruppenziele werden
> mit demselben AES-128-Schlüssel verschlüsselt.

> Als **RNS.Destination.SINGLE**Ziele verwendet Reticulum für jedes
> Paket einen neu abgeleiteten, flüchtigen AES-128-Schlüssel.

> Für [RNS.Link-](https://reticulum.network/manual/reference.html#api-link) Ziele
> verwendet Reticulum temporäre Schlüssel pro Link und bietet **Forward
> Secrecy** .

> PARAMETER :

- **Ziel** –
  > Eine [RNS.Destination](https://reticulum.network/manual/reference.html#api-destination) -Instanz,
  > an die das Paket gesendet wird.

- **Daten** – Die in das Paket aufzunehmende Datennutzlast
  > in **Bytes** .

- **create_receipt** – Gibt an, ob beim Instanziieren des Pakets
  > ein [RNS.PacketReceipt](https://reticulum.network/manual/reference.html#api-packetreceipt) erstellt
  > werden soll.

> <span id="anchor-53"></span>**ENCRYPTED_MDU ******= 383****[** **](https://reticulum.network/manual/reference.html#RNS.Packet.ENCRYPTED_MDU)[\#](https://reticulum.network/manual/reference.html#RNS.Packet.ENCRYPTED_MDU)

> Die maximale Größe der Nutzdaten in einem einzelnen verschlüsselten
> Paket

> <span id="anchor-54"></span>**PLAIN_MDU ******= 464****[** **](https://reticulum.network/manual/reference.html#RNS.Packet.PLAIN_MDU)[\#](https://reticulum.network/manual/reference.html#RNS.Packet.PLAIN_MDU)

> Die maximale Größe der Nutzdaten in einem einzelnen unverschlüsselten
> Paket

> <span id="anchor-55"></span>schicken ( ) 

> Sendet das Paket.

> KEHRT ZURÜCK :

> Eine [RNS.PacketReceipt](https://reticulum.network/manual/reference.html#api-packetreceipt) -Instanz,
> wenn **create_receipt beim Erstellen des Pakets auf True** gesetzt
> wurde . Andernfalls wird **None** zurückgegeben . Wenn das Paket nicht
> gesendet werden konnte, wird **False zurückgegeben.**

> <span id="anchor-56"></span>erneut senden ( ) 

> Sendet das Paket erneut.

> KEHRT ZURÜCK :

> Eine [RNS.PacketReceipt](https://reticulum.network/manual/reference.html#api-packetreceipt) -Instanz,
> wenn **create_receipt beim Erstellen des Pakets auf True** gesetzt
> wurde . Andernfalls wird **None** zurückgegeben . Wenn das Paket nicht
> gesendet werden konnte, wird **False zurückgegeben.**

### <span id="anchor-57"></span>Paketempfang

<span id="anchor-58"></span>****Klasse ****RNS. **PacketReceipt**

> Die Klasse PacketReceipt wird verwendet, um Benachrichtigungen
> über [RNS.Packet-](https://reticulum.network/manual/reference.html#api-packet) Instanzen
> zu empfangen, die über das Netzwerk gesendet werden. Instanzen dieser
> Klasse werden nie manuell erstellt, sondern immer von
> der **send()-** Methode
> einer [RNS.Packet-](https://reticulum.network/manual/reference.html#api-packet) Instanz
> zurückgegeben.

> <span id="anchor-59"></span>Status bekommen ( ) 

> KEHRT ZURÜCK :

> Der Status der
> zugehörigen [RNS.Packet](https://reticulum.network/manual/reference.html#api-packet) -Instanz.
> Kann einer der folgenden Werte
> sein: **RNS.PacketReceipt.SENT**, **RNS.PacketReceipt.DELIVERED**, **RNS.PacketReceipt.FAILED**oder **RNS.PacketReceipt.CULLED**.

> <span id="anchor-60"></span>get_rtt ( ) 

> KEHRT ZURÜCK :

> Die Round-Trip-Time in Sekunden

> <span id="anchor-61"></span>**set_timeout ( ******Zeitüberschreitung****** ) **

> Legt ein Timeout in Sekunden fest

> PARAMETER :

> **Timeout** – Das Timeout in Sekunden.

> <span id="anchor-62"></span>**set_delivery_callback ( ******Rückruf****** ) **

> Legt eine Funktion fest, die aufgerufen wird, wenn eine erfolgreiche
> Zustellung nachgewiesen wurde.

> PARAMETER :

> **callback** – Eine **aufrufbare Funktion** mit der
> Signatur **callback(packet_receipt)**

> <span id="anchor-63"></span>**set_timeout_callback ( ******Rückruf****** ) **

> Legt eine Funktion fest, die aufgerufen wird, wenn die Zustellung ein
> Zeitlimit überschreitet.

> PARAMETER :

> **callback** – Eine **aufrufbare Funktion** mit der
> Signatur **callback(packet_receipt)**

### <span id="anchor-64"></span>Verknüpfung

<span id="anchor-65"></span>****Klasse ****RNS. **Link ( ******Ziel****** ,****** established_callback = Keine****** ,****** closed_callback = Keine****** ) **

> Diese Klasse wird zum Erstellen und Verwalten von Links zu anderen
> Peers verwendet. Wenn eine Link-Instanz erstellt wird, versucht
> Reticulum, eine verifizierte und verschlüsselte Verbindung mit dem
> angegebenen Ziel herzustellen.

> PARAMETER :

- **Ziel** –
  > Eine [RNS.Destination](https://reticulum.network/manual/reference.html#api-destination) -Instanz,
  > zu der eine Verbindung hergestellt werden soll.

- **established_callback** – Eine optionale Funktion oder Methode mit
  > der Signatur **callback(link),** die aufgerufen werden soll, wenn
  > die Verbindung hergestellt wurde.

- **closed_callback** – Eine optionale Funktion oder Methode mit der
  > Signatur **callback(link),** die aufgerufen wird, wenn der Link
  > geschlossen wird.

> <span id="anchor-66"></span>**KURVE ******= 'Kurve25519'****[** **](https://reticulum.network/manual/reference.html#RNS.Link.CURVE)[\#](https://reticulum.network/manual/reference.html#RNS.Link.CURVE)

> Die für den Elliptic Curve DH-Schlüsselaustausch verwendete Kurve

> <span id="anchor-67"></span>**ESTABLISHMENT_TIMEOUT_PER_HOP ******= 6****[** **](https://reticulum.network/manual/reference.html#RNS.Link.ESTABLISHMENT_TIMEOUT_PER_HOP)[\#](https://reticulum.network/manual/reference.html#RNS.Link.ESTABLISHMENT_TIMEOUT_PER_HOP)

> Timeout für den Verbindungsaufbau in Sekunden pro Hop zum Ziel.

> <span id="anchor-68"></span>**KEEPALIVE_TIMEOUT_FACTOR ******= 4****[** **](https://reticulum.network/manual/reference.html#RNS.Link.KEEPALIVE_TIMEOUT_FACTOR)[\#](https://reticulum.network/manual/reference.html#RNS.Link.KEEPALIVE_TIMEOUT_FACTOR)

> RTT-Timeout-Faktor, der bei der Berechnung des Link-Timeouts verwendet
> wird.

> <span id="anchor-69"></span>**STALE_GRACE ******= 2****[** **](https://reticulum.network/manual/reference.html#RNS.Link.STALE_GRACE)[\#](https://reticulum.network/manual/reference.html#RNS.Link.STALE_GRACE)

> Karenzzeit in Sekunden, die bei der Berechnung des Link-Timeouts
> verwendet wird.

> <span id="anchor-70"></span>**KEEPALIVE ******= 360****[** **](https://reticulum.network/manual/reference.html#RNS.Link.KEEPALIVE)[\#](https://reticulum.network/manual/reference.html#RNS.Link.KEEPALIVE)

> Intervall für das Senden von Keep-Alive-Paketen über bestehende Links
> in Sekunden.

> <span id="anchor-71"></span>**STALE_TIME ******= 720****[** **](https://reticulum.network/manual/reference.html#RNS.Link.STALE_TIME)[\#](https://reticulum.network/manual/reference.html#RNS.Link.STALE_TIME)

> Wenn innerhalb dieser Zeit kein Datenverkehr oder keine
> Keep-Alive-Pakete empfangen werden, wird die Verbindung als veraltet
> markiert und ein letztes Keep-Alive-Paket gesendet. Wenn danach
> innerhalb von **RTT**\* **KEEPALIVE_TIMEOUT_FACTOR**+ kein
> Datenverkehr oder keine Keep-Alive-Pakete empfangen
> werden **STALE_GRACE**, gilt die Verbindung als abgelaufen und wird
> abgebaut.

> <span id="anchor-72"></span>**identifizieren ( ******Identität****** ) **

> Identifiziert den Initiator der Verbindung zur Gegenstelle. Dies kann
> erst nach dem Verbindungsaufbau erfolgen und erfolgt über die
> verschlüsselte Verbindung. Die Identität wird nur der Gegenstelle
> mitgeteilt und die Anonymität des Initiators bleibt somit gewahrt.
> Diese Methode kann zur Authentifizierung verwendet werden.

> PARAMETER :

> **Identität** – Eine RNS.Identity-Instanz zur Identifizierung.

> <span id="anchor-73"></span>**Anfrage ( ******Pfad****** ,****** Daten = Keine****** ,****** Antwortrückruf = Keine****** ,****** fehlgeschlagener
> Rückruf = Keine****** ,****** Fortschrittsrückruf = Keine****** ,****** Zeitüberschreitung = Keine****** ) **

> Sendet eine Anfrage an den Remote-Peer.

> PARAMETER :

- **Pfad** – Der Anforderungspfad.

- **response_callback** – Eine optionale Funktion oder Methode mit der
  > Signatur **response_callback(request_receipt),** die aufgerufen
  > wird, wenn eine Antwort empfangen wird. Weitere Informationen finden
  > Sie im [Anforderungsbeispiel
  > .](https://reticulum.network/manual/examples.html#example-request)

- **failed_callback** – Eine optionale Funktion oder Methode mit der
  > Signatur **failed_callback(request_receipt),** die aufgerufen wird,
  > wenn eine Anfrage fehlschlägt. Weitere Informationen finden Sie
  > im [Anfragebeispiel
  > .](https://reticulum.network/manual/examples.html#example-request)

- **progress_callback** – Eine optionale Funktion oder Methode mit der
  > Signatur **progress_callback(request_receipt),** die aufgerufen
  > wird, wenn beim Empfangen der Antwort Fortschritte erzielt werden.
  > Der Fortschritt kann als Float zwischen 0,0 und 1,0 über
  > die Eigenschaft **request_receipt.progress abgerufen werden.**

- **Timeout** – Ein optionales Timeout in Sekunden für die Anfrage.
  > Wenn **„Keines“** angegeben wird, wird es basierend auf der Link-RTT
  > berechnet.

> KEHRT ZURÜCK :

> Eine [RNS.RequestReceipt](https://reticulum.network/manual/reference.html#api-requestreceipt) -Instanz,
> wenn die Anforderung gesendet wurde, oder **„False“** , wenn dies
> nicht der Fall war.

> <span id="anchor-74"></span>**track_phy_stats ( ******verfolgen****** ) **

> Sie können Statistiken zur physischen Schicht für einzelne
> Verbindungen aktivieren. Wenn diese Option aktiviert ist und die
> Verbindung über eine Schnittstelle läuft, die die Meldung von
> Statistiken zur physischen Schicht unterstützt, können Sie Statistiken
> wie **RSSI** , **SNR** und physische **Verbindungsqualität** für die
> Verbindung abrufen.

> PARAMETER :

> **track** – Gibt an, ob Statistiken der physischen Schicht verfolgt
> werden sollen oder nicht. Der Wert muss **True**oder sein **False**.

> <span id="anchor-75"></span>get_rssi ( ) 

> KEHRT ZURÜCK :

> Die **Anzeige der empfangenen Signalstärke auf** der physischen Ebene
> , falls verfügbar, andernfalls **None**. Damit diese Methode einen
> Wert zurückgibt, müssen auf der Verbindung Statistiken zur physischen
> Ebene aktiviert sein.

> <span id="anchor-76"></span>get_snr ( ) 

> KEHRT ZURÜCK :

> **Das Signal-Rausch-Verhältnis** der physischen Schicht, falls
> verfügbar, andernfalls **None**. Damit diese Methode einen Wert
> zurückgibt, müssen auf der Verbindung Statistiken zur physischen
> Schicht aktiviert sein.

> <span id="anchor-77"></span>get_q ( ) 

> KEHRT ZURÜCK :

> **Die Verbindungsqualität** der physischen Schicht, falls verfügbar,
> andernfalls **None**. Damit diese Methode einen Wert zurückgibt,
> müssen Statistiken zur physischen Schicht auf der Verbindung aktiviert
> sein.

> <span id="anchor-78"></span>get_establishment_rate ( ) 

> KEHRT ZURÜCK :

> Die Datenübertragungsrate in Bits pro Sekunde, mit der der
> Verbindungsaufbau erfolgte.

> <span id="anchor-79"></span>kein_eingehender_Kontakt für ( ) 

> KEHRT ZURÜCK :

> Die Zeit in Sekunden seit dem letzten eingehenden Paket auf der
> Verbindung. Dies schließt Keepalive-Pakete ein.

> <span id="anchor-80"></span>kein_Ausgang für ( ) 

> KEHRT ZURÜCK :

> Die Zeit in Sekunden seit dem letzten ausgehenden Paket auf der
> Verbindung. Dies schließt Keepalive-Pakete ein.

> <span id="anchor-81"></span>keine_daten_für ( ) 

> KEHRT ZURÜCK :

> Die Zeit in Sekunden, seit die Nutzdaten die Verbindung durchlaufen
> haben. Keep-Alive-Pakete werden hiervon nicht erfasst.

> <span id="anchor-82"></span>inaktiv_für ( ) 

> KEHRT ZURÜCK :

> Die Zeit in Sekunden seit der Aktivität auf dem Link. Dies schließt
> Keepalive-Pakete ein.

> <span id="anchor-83"></span>get_remote_identity ( ) 

> KEHRT ZURÜCK :

> Die Identität des Remote-Peers, sofern bekannt. Beim Aufrufen dieser
> Methode wird der Remote-Initiator nicht nach seiner Identität gefragt.
> Wird zurückgegeben, **None**wenn der Link-Initiator die Methode nicht
> bereits unabhängig aufgerufen hat **identify(identity)**.

> <span id="anchor-84"></span>abreißen ( ) 

> Schließt die Verbindung und löscht die Verschlüsselungsschlüssel. Neue
> Schlüssel werden verwendet, wenn eine neue Verbindung zum gleichen
> Ziel hergestellt wird.

> <span id="anchor-85"></span>get_channel ( ) 

> Holen Sie sich das **Channel**über diesen Link.

> KEHRT ZURÜCK :

> **Channel**Objekt

> <span id="anchor-86"></span>**set_link_closed_callback ( ******Rückruf****** ) **

> Registriert eine Funktion, die aufgerufen werden soll, wenn eine
> Verbindung getrennt wurde.

> PARAMETER :

> **callback** – Eine aufzurufende Funktion oder Methode mit der
> Signatur **callback(link) .**

> <span id="anchor-87"></span>**set_packet_callback ( ******Rückruf****** ) **

> Registriert eine Funktion, die aufgerufen werden soll, wenn über
> diesen Link ein Paket empfangen wurde.

> PARAMETER :

> **Rückruf** – Eine aufzurufende Funktion oder Methode mit der
> Signatur **„Rückruf (Nachricht, Paket)“ .**

> <span id="anchor-88"></span>**set_resource_callback ( ******Rückruf****** ) **

> Registriert eine Funktion, die aufgerufen wird, wenn eine Ressource
> über diesen Link angekündigt wurde. Wenn die
> Funktion **True** zurückgibt , wird die Ressource akzeptiert. Wenn
> sie **False** zurückgibt , wird sie ignoriert.

> PARAMETER :

> **callback** – Eine aufzurufende Funktion oder Methode mit der
> Signatur **callback(resource) . Bitte beachten Sie, dass derzeit nur
> die grundlegenden Informationen der Ressource verfügbar sind,
> **wie get_transfer_size()** , **get_data_size()** , **get_parts()** und **is_compressed()** .

> <span id="anchor-89"></span>**set_resource_started_callback ( ******Rückruf****** ) **

> Registriert eine Funktion, die aufgerufen werden soll, wenn mit der
> Übertragung einer Ressource über diesen Link begonnen wurde.

> PARAMETER :

> **callback** – Eine aufzurufende Funktion oder Methode mit der
> Signatur **callback(resource) .**

> <span id="anchor-90"></span>**set_resource_concluded_callback ( ******Rückruf****** ) **

> Registriert eine Funktion, die aufgerufen werden soll, wenn die
> Übertragung einer Ressource über diesen Link abgeschlossen ist.

> PARAMETER :

> **callback** – Eine aufzurufende Funktion oder Methode mit der
> Signatur **callback(resource) .**

> <span id="anchor-91"></span>**set_remote_identified_callback ( ******Rückruf****** ) **

> Registriert eine Funktion, die aufgerufen werden soll, wenn ein
> initiierender Peer über diesen Link identifiziert wurde.

> PARAMETER :

> **callback** – Eine aufzurufende Funktion oder Methode mit der
> Signatur **callback(link, identity) .**

> <span id="anchor-92"></span>**set_resource_strategy ( ******Ressourcenstrategie****** ) **

> Legt die Ressourcenstrategie für den Link fest.

> PARAMETER :

> **resource_strategy** – Eines
> von **RNS.Link.ACCEPT_NONE**, **RNS.Link.ACCEPT_ALL**oder **RNS.Link.ACCEPT_APP**.
> Wenn **RNS.Link.ACCEPT_APP**gesetzt ist, wird **resource_callback
> aufgerufen, um zu bestimmen, ob die Ressource akzeptiert werden soll
> oder nicht.**

> ERHÖHT SICH UM :

> **TypeError** , wenn die Ressourcenstrategie nicht unterstützt wird.

### <span id="anchor-93"></span>Empfangsbestätigung anfordern

<span id="anchor-94"></span>****Klasse ****RNS.RequestReceipt[** **](https://reticulum.network/manual/reference.html#RNS.RequestReceipt)[\#](https://reticulum.network/manual/reference.html#RNS.RequestReceipt)**​**

> Eine Instanz dieser Klasse wird von der **request**Methode
> der **RNS.Link** Instanzen zurückgegeben. Sie sollte niemals manuell
> instanziiert werden. Sie bietet Methoden zum Überprüfen von Status,
> Antwortzeit und Antwortdaten, wenn die Anforderung abgeschlossen ist.

> <span id="anchor-95"></span>get_request_id ( ) 

> KEHRT ZURÜCK :

> Die Anforderungs-ID in **Bytes** .

> <span id="anchor-96"></span>Status bekommen ( ) 

> KEHRT ZURÜCK :

> Der aktuelle Status der Anfrage, einer
> von **RNS.RequestReceipt.FAILED**, **RNS.RequestReceipt.SENT**, **RNS.RequestReceipt.DELIVERED**, **RNS.RequestReceipt.READY**.

> <span id="anchor-97"></span>get_progress ( ) 

> KEHRT ZURÜCK :

> Der Fortschritt einer empfangenen Antwort wird
> als **Gleitkommazahl** zwischen 0,0 und 1,0 angezeigt.

> <span id="anchor-98"></span>erhalten Antwort ( ) 

> KEHRT ZURÜCK :

> Die Antwort in **Bytes** , wenn es bereit ist, andernfalls **Keine** .

> <span id="anchor-99"></span>get_response_time ( ) 

> KEHRT ZURÜCK :

> Die Antwortzeit der Anfrage in Sekunden.

### <span id="anchor-100"></span>Ressource

<span id="anchor-101"></span>****Klasse ****RNS. **Ressource ( ******Daten****** ,****** Link****** ,****** Werbung = True****** ,****** automatische
Komprimierung = True****** ,****** Rückruf = Keine****** ,****** Fortschrittsrückruf = Keine****** ,****** Zeitüberschreitung = Keine****** ) **

> Die Ressourcenklasse ermöglicht die Übertragung beliebiger Datenmengen
> über eine Verbindung. Sie übernimmt automatisch die Sequenzierung,
> Komprimierung, Koordination und Prüfsummenbildung.

> PARAMETER :

- **Daten** – Die zu übertragenden Daten. Können **Bytes** oder ein
  > geöffneter **Datei-Handle** sein . Weitere Informationen finden Sie
  > im [Dateiübertragungsbeispiel](https://reticulum.network/manual/examples.html#example-filetransfer) .

- **Link** –
  > Die [RNS.Link-](https://reticulum.network/manual/reference.html#api-link) Instanz,
  > auf die die Daten übertragen werden sollen.

- **advertise** – Optional. Gibt an, ob die Ressource automatisch
  > beworben werden soll. Kann **True** oder **False** sein .

- **auto_compress** – Optional. Gibt an, ob die Ressource automatisch
  > komprimiert werden soll. Kann **True** oder **False** sein .

- **callback** – Ein optionales **aufrufbares Objekt** mit der
  > Signatur **callback(resource)** . Wird aufgerufen, wenn die
  > Ressourcenübertragung abgeschlossen ist.

- **progress_callback** – Ein optionales **aufrufbares Element** mit der
  > Signatur **callback(resource)** . Wird aufgerufen, wenn der
  > Fortschritt der Ressourcenübertragung aktualisiert wird.

> <span id="anchor-102"></span>werben ( ) 

> Geben Sie die Ressource bekannt. Wenn das andere Ende der Verbindung
> die Ressourcenankündigung akzeptiert, beginnt die Übertragung.

> <span id="anchor-103"></span>stornieren ( ) 

> Bricht die Übertragung der Ressource ab.

> <span id="anchor-104"></span>get_progress ( ) 

> KEHRT ZURÜCK :

> Der aktuelle Fortschritt der Ressourcenübertragung
> als **Float** zwischen 0,0 und 1,0.

> <span id="anchor-105"></span>get_transfer_size ( ) 

> KEHRT ZURÜCK :

> Die Anzahl der Bytes, die zum Übertragen der Ressource benötigt
> werden.

> <span id="anchor-106"></span>get_data_size ( ) 

> KEHRT ZURÜCK :

> Die Gesamtdatengröße der Ressource.

> <span id="anchor-107"></span>Teile_erhalten ( ) 

> KEHRT ZURÜCK :

> Die Anzahl der Teile, in denen die Ressource übertragen wird.

> <span id="anchor-108"></span>get_segments ( ) 

> KEHRT ZURÜCK :

> Die Anzahl der Segmente, in die die Ressource unterteilt ist.

> <span id="anchor-109"></span>get_hash ( ) 

> KEHRT ZURÜCK :

> Der Hash der Ressource.

> <span id="anchor-110"></span>Ist komprimiert ( ) 

> KEHRT ZURÜCK :

> Ob die Ressource komprimiert ist.

### <span id="anchor-111"></span>Kanal

<span id="anchor-112"></span>****Klasse ****RNS.Channel. **Kanal**

> Ermöglicht die zuverlässige Übermittlung von Nachrichten über einen
> Link.

> **Channel**unterscheidet sich in einigen wichtigen
> Punkten **Request**von :**Resource**

> **Kontinuierlich**

> Solange die Verbindung **Link**geöffnet ist, können Nachrichten
> gesendet oder empfangen werden.

> **Bidirektional**

> Nachrichten können in beide Richtungen gesendet werden **Link**; kein
> Ende ist Client oder Server.

> **Größenbeschränkt**

> Nachrichten müssen in einem einzigen Paket codiert werden.

> **Channel**ist ähnlich wie **Packet**, bietet jedoch eine zuverlässige
> Übermittlung (automatische Wiederholungsversuche) sowie eine Struktur
> für den Austausch mehrerer Nachrichtentypen über das **Link**.

> **Channel**wird nicht direkt instanziiert, sondern mit aus
> einem **Link**abgerufen **get_channel()**.

> <span id="anchor-113"></span>**register_message_type ( ******Nachrichtenklasse : Typ \[ ****[****MessageBase ****](https://reticulum.network/manual/reference.html#RNS.MessageBase)****\] ******) **

> Registrieren Sie eine Nachrichtenklasse für den Empfang über
> eine **Channel**.

> Nachrichtenklassen müssen erweitert werden **MessageBase**.

> PARAMETER :

> **message_class** – Zu registrierende Klasse

> <span id="anchor-114"></span>**add_message_handler ( ******Rückruf : MessageCallbackType ******) **

> Fügen Sie einen Handler für eingehende Nachrichten hinzu. Ein Handler
> hat die folgende Signatur:

> **(message: MessageBase) -\> bool**

> Handler werden in der Reihenfolge verarbeitet, in der sie hinzugefügt
> werden. Wenn ein Handler True zurückgibt, wird die Verarbeitung der
> Nachricht beendet. Handler nach dem zurückgegebenen Handler werden
> nicht aufgerufen.

> PARAMETER :

> **callback** – aufzurufende Funktion

> <span id="anchor-115"></span>**remove_message_handler ( ******Rückruf : Nachrichtenrückruftyp ******) **

> Entfernen Sie einen mit hinzugefügten Handler **add_message_handler**.

> PARAMETER :

> **Rückruf** – Handler zum Entfernen

> <span id="anchor-116"></span>ist_bereit_zum_senden ( ) → bool

> Prüfen Sie, ob **Channel**es zum Senden bereit ist.

> KEHRT ZURÜCK :

> Wahr, wenn bereit

> <span id="anchor-117"></span>**sende ( ******Nachricht : ****[****MessageBase****](https://reticulum.network/manual/reference.html#RNS.MessageBase)**** ******) → Umschlag**

> Senden Sie eine Nachricht. Wenn versucht wird, eine Nachricht zu
> senden, dies jedoch **Channel**nicht möglich ist, wird eine Ausnahme
> ausgelöst.

> PARAMETER :

> **Nachricht** – eine Instanz einer **MessageBase**Unterklasse

> <span id="anchor-118"></span>****Eigenschaft ******MDU**

> Maximale Dateneinheit: die Anzahl der Bytes, die eine Nachricht in
> einem einzigen Sendevorgang verbrauchen kann. Dieser Wert wird von
> der **Link**MDU angepasst, um Nachrichtenkopfinformationen
> aufzunehmen.

> KEHRT ZURÜCK :

> Anzahl der verfügbaren Bytes

### <span id="anchor-119"></span>Nachrichtenbasis

<span id="anchor-120"></span>****Klasse ****RNS. **MessageBase**

> Basistyp für alle Nachrichten, die über einen Kanal gesendet oder
> empfangen werden. Unterklassen müssen die beiden abstrakten Methoden
> sowie die **MSGTYPE**Klassenvariable definieren.

> <span id="anchor-121"></span>**MSGTYPE ******= Keine****[** **](https://reticulum.network/manual/reference.html#RNS.MessageBase.MSGTYPE)[\#](https://reticulum.network/manual/reference.html#RNS.MessageBase.MSGTYPE)

> Definiert eine eindeutige Kennung für eine Nachrichtenklasse.

- Muss innerhalb aller Klassen eindeutig sein, die mit einem**Channel**

- Muss kleiner sein als **0xf000**. Werte größer oder
  > gleich **0xf000**sind reserviert.

> <span id="anchor-122"></span>****abstraktes ******Paket ( ) → Bytes**

> Erstellen und Zurückgeben der binären Darstellung der Nachricht

> KEHRT ZURÜCK :

> Binäre Darstellung der Nachricht

> <span id="anchor-123"></span>****abstraktes ******Entpacken ( ******roh : Bytes ******) **

> Nachricht aus binärer Darstellung auffüllen

> PARAMETER :

> **Rohdarstellung** – binäre Darstellung

### <span id="anchor-124"></span>Puffer

<span id="anchor-125"></span>****Klasse ****RNS. **Puffer**

> Statische Funktionen zum Erstellen gepufferter Streams, die über ein
> gesendet und empfangen werden **Channel**.

> Diese Funktionen verwenden **BufferedReader**, **BufferedWriter**,
> und **BufferedRWPair**um Pufferung zu **RawChannelReader**und
> hinzuzufügen **RawChannelWriter**.

> <span id="anchor-126"></span>****statischer ******create_reader ( ******stream_id : int ******,****** channel : ****[****Kanal****](https://reticulum.network/manual/reference.html#RNS.Channel.Channel)**** ******,****** ready_callback : Optional \[ Aufrufbar \[ \[ int \] , Keine \] \] = Keine ******) → BufferedReader**

> Erstellen Sie einen gepufferten Reader, der über ein gesendete
> Binärdaten liest **Channel**, mit einem optionalen Rückruf, wenn neue
> Daten verfügbar sind.

> Rückrufsignatur:**(ready_bytes: int) -\> None**

> Weitere Informationen zu den leserspezifischen Funktionen dieses
> Objekts finden Sie in der Python-Dokumentation für **BufferedReader**

> PARAMETER :

- **stream_id** – die lokale Stream-ID, von der empfangen werden soll

- **Kanal** – der Kanal, auf dem empfangen werden soll

- **ready_callback** – Funktion, die aufgerufen wird, wenn neue Daten
  > verfügbar sind

> KEHRT ZURÜCK :

> ein BufferedReader-Objekt

> <span id="anchor-127"></span>****statischer ******create_writer ( ******stream_id : int ******,****** channel : ****[****Channel****](https://reticulum.network/manual/reference.html#RNS.Channel.Channel)**** ******) → BufferedWriter**

> Erstellen Sie einen gepufferten Writer, der Binärdaten über einen
> schreibt **Channel**.

> Weitere Informationen zu den Writer-spezifischen Funktionen dieses
> Objekts finden Sie in der Python-Dokumentation für **BufferedWriter**

> PARAMETER :

- **stream_id** – die Remote-Stream-ID, an die gesendet werden soll

- **Kanal** – der Kanal, über den gesendet werden soll

> KEHRT ZURÜCK :

> ein BufferedWriter-Objekt

> <span id="anchor-128"></span>****statischer ******create_bidirectional_buffer ( ******receive_stream_id : int ******,****** send_stream_id : int ******,****** channel : ****[****Kanal****](https://reticulum.network/manual/reference.html#RNS.Channel.Channel)**** ******,****** ready_callback : Optional \[ Aufrufbar \[ \[ int \] , Keine \] \] = Keine ******) → BufferedRWPair**

> Erstellen Sie ein gepuffertes Leser-/Schreibpaar, das Binärdaten über
> einen liest und schreibt **Channel**, mit einem optionalen Rückruf,
> wenn neue Daten verfügbar sind.

> Rückrufsignatur:**(ready_bytes: int) -\> None**

> Weitere Informationen zu den leserspezifischen Funktionen dieses
> Objekts finden Sie in der Python-Dokumentation für **BufferedRWPair**

> PARAMETER :

- **receive_stream_id** – die lokale Stream-ID zum Empfangen

- **send_stream_id** – die Remote-Stream-ID, an die gesendet werden soll

- **Kanal** – der Kanal zum Senden und Empfangen

- **ready_callback** – Funktion, die aufgerufen wird, wenn neue Daten
  > verfügbar sind

> KEHRT ZURÜCK :

> ein BufferedRWPair-Objekt

### <span id="anchor-129"></span>RawChannelReader

<span id="anchor-130"></span>****Klasse ****RNS. **RawChannelReader ( ******stream_id : int ******,****** channel : ****[****Channel****](https://reticulum.network/manual/reference.html#RNS.Channel.Channel)**** ******) **

> Eine Implementierung von RawIOBase, die über ein gesendete binäre
> Streamdaten empfängt **Channel**.

> Diese Klasse muss im Allgemeinen nicht direkt instanziiert werden.
> Verwenden Sie die
> Funktionen [**RNS.Buffer.create_reader()**](https://reticulum.network/manual/reference.html#RNS.Buffer.create_reader), [**RNS.Buffer.create_writer()**](https://reticulum.network/manual/reference.html#RNS.Buffer.create_writer),
> und [**RNS.Buffer.create_bidirectional_buffer()**](https://reticulum.network/manual/reference.html#RNS.Buffer.create_bidirectional_buffer),
> um gepufferte Streams mit optionalen Rückrufen zu erstellen.

> Weitere Informationen zur API dieses Objekts finden Sie in der
> Python-Dokumentation für **RawIOBase**.

> <span id="anchor-131"></span>**\_\_init\_\_ ( ******stream_id : int ******,****** channel : ****[****Kanal****](https://reticulum.network/manual/reference.html#RNS.Channel.Channel)**** ******) **

> Erstellen Sie einen Rohkanalleser.

> PARAMETER :

- **stream_id** – lokale Stream-ID zum Empfangen

- **Kanal** – **Channel**Objekt, von dem empfangen werden soll

> <span id="anchor-132"></span>**add_ready_callback ( ******cb : Aufrufbar \[ \[ int \] , Keine \] ******) **

> Fügen Sie eine Funktion hinzu, die aufgerufen wird, wenn neue Daten
> verfügbar sind. Die Funktion sollte die Signatur
> haben**(ready_bytes: int) -\> None**

> PARAMETER :

> **cb** – aufzurufende Funktion

> <span id="anchor-133"></span>**remove_ready_callback ( ******cb : Aufrufbar \[ \[ int \] , Keine \] ******) **

> Entfernen Sie eine Funktion, die hinzugefügt wurde
> mit[**RNS.RawChannelReader.add_ready_callback()**](https://reticulum.network/manual/reference.html#RNS.RawChannelReader.add_ready_callback)

> PARAMETER :

> **cb** – Funktion zum Entfernen

### <span id="anchor-134"></span>RawChannelWriter

<span id="anchor-135"></span>****Klasse ****RNS. **RawChannelWriter ( ******stream_id : int ******,****** channel : ****[****Channel****](https://reticulum.network/manual/reference.html#RNS.Channel.Channel)**** ******) **

> Eine Implementierung von RawIOBase, die über einen Kanal gesendete
> binäre Streamdaten empfängt.

> Diese Klasse muss im Allgemeinen nicht direkt instanziiert werden.
> Verwenden Sie die
> Funktionen [**RNS.Buffer.create_reader()**](https://reticulum.network/manual/reference.html#RNS.Buffer.create_reader), [**RNS.Buffer.create_writer()**](https://reticulum.network/manual/reference.html#RNS.Buffer.create_writer),
> und [**RNS.Buffer.create_bidirectional_buffer()**](https://reticulum.network/manual/reference.html#RNS.Buffer.create_bidirectional_buffer),
> um gepufferte Streams mit optionalen Rückrufen zu erstellen.

> Weitere Informationen zur API dieses Objekts finden Sie in der
> Python-Dokumentation für **RawIOBase**.

> <span id="anchor-136"></span>**\_\_init\_\_ ( ******stream_id : int ******,****** channel : ****[****Kanal****](https://reticulum.network/manual/reference.html#RNS.Channel.Channel)**** ******) **

> Erstellen Sie einen Rohkanalschreiber.

> PARAMETER :

- **stream_id** – Remote-Stream-ID, die gesendet werden soll

- **Kanal** – **Channel**zu sendendes Objekt

### <span id="anchor-137"></span>Transport

<span id="anchor-138"></span>****Klasse ****RNS. **Transport**

> Durch statische Methoden dieser Klasse können Sie mit dem
> Transportsystem von Reticulum interagieren.

> <span id="anchor-139"></span>**PATHFINDER_M ******= 128****[** **](https://reticulum.network/manual/reference.html#RNS.Transport.PATHFINDER_M)[\#](https://reticulum.network/manual/reference.html#RNS.Transport.PATHFINDER_M)

> Maximale Anzahl an Hops, mit denen Reticulum ein Paket transportiert.

> <span id="anchor-140"></span>****statischer ******register_announce_handler ( ******Handler****** ) **

> Registriert einen Ankündigungshandler.

> PARAMETER :

> **Handler** – Muss ein Objekt mit einem **Aspektfilterattribut** und
> einem aufrufbaren **Received_announce(Destination_Hash,
> Announced_Identity, App_Data)** sein . Weitere Informationen finden
> Sie im [Announce-Beispiel
> .](https://reticulum.network/manual/examples.html#example-announce)

> <span id="anchor-141"></span>****statischer ******deregister_announce_handler ( ******Handler****** ) **

> Melden Sie einen Announce-Handler ab.

> PARAMETER :

> **Handler** – Der abzumeldende Ankündigungshandler.

> <span id="anchor-142"></span>****statischer ******has_path ( ******Ziel-Hash****** ) **

> PARAMETER :

> **destination_hash** – Ein Ziel-Hash als **Bytes** .

> KEHRT ZURÜCK :

> **True** , wenn ein Pfad zum Ziel bekannt ist, andernfalls **False** .

> <span id="anchor-143"></span>****statisches ******hops_to ( ******Ziel-Hash****** ) **

> PARAMETER :

> **destination_hash** – Ein Ziel-Hash als **Bytes** .

> KEHRT ZURÜCK :

> Die Anzahl der Hops zum angegebenen Ziel
> oder **RNS.Transport.PATHFINDER_M**ob die Anzahl der Hops unbekannt
> ist.

> <span id="anchor-144"></span>****statischer ******nächster
> Hop ( ******Ziel-Hash****** ) **

> PARAMETER :

> **destination_hash** – Ein Ziel-Hash als **Bytes** .

> KEHRT ZURÜCK :

> Der Ziel-Hash als **Bytes** für den nächsten Hop zum angegebenen Ziel
> oder **„Keine“** , wenn der nächste Hop unbekannt ist.

> <span id="anchor-145"></span>****statisches ******Next_Hop_Interface ( ******Ziel-Hash****** ) **

> PARAMETER :

> **destination_hash** – Ein Ziel-Hash als **Bytes** .

> KEHRT ZURÜCK :

> Die Schnittstelle für den nächsten Hop zum angegebenen Ziel
> oder **Keine** , wenn die Schnittstelle unbekannt ist.

> <span id="anchor-146"></span>****statischer ******Anforderungspfad ( ******Ziel-Hash****** ,****** On-Interface = Keine****** ,****** Tag = Keine****** ,****** rekursiv = Falsch****** ) **

> Fordert vom Netzwerk einen Pfad zum Ziel an. Wenn ein anderer
> erreichbarer Peer im Netzwerk einen Pfad kennt, wird er ihn bekannt
> geben.

> PARAMETER :

- **destination_hash** – Ein Ziel-Hash als **Bytes** .

- **on_interface** – Wenn angegeben, wird die Pfadanforderung nur über
  > diese Schnittstelle gesendet. Bei normaler Verwendung erledigt
  > Reticulum dies automatisch und dieser Parameter sollte nicht
  > verwendet werden.
