# Kommunikationshardware 

Einer der wirklich wertvollen Aspekte von Reticulum ist die Möglichkeit,
es über nahezu jedes erdenkliche Kommunikationsmedium zu verwenden. Die
in Reticulum
konfigurierbaren [Schnittstellentypen](https://reticulum.network/manual/interfaces.html#interfaces-main) sind
flexibel genug, um die Verwendung der meisten verfügbaren
kabelgebundenen und kabellosen Kommunikationshardware abzudecken, von
jahrzehntealten Paketfunkmodems bis hin zu modernen
Millimeterwellen-Backhaul-Systemen.

Wenn Sie bereits Kommunikationshardware besitzen oder verwenden, ist die
Wahrscheinlichkeit sehr hoch, dass diese sofort mit Reticulum
funktioniert. Falls nicht, können Sie die notwendige Verbindung mit sehr
geringem Aufwand herstellen, indem Sie beispielsweise
das [PipeInterface](https://reticulum.network/manual/interfaces.html#interfaces-pipe) oder
das [TCPClientInterface](https://reticulum.network/manual/interfaces.html#interfaces-tcpc) in
Kombination mit Code wie [dem TCP KISS
Server](https://github.com/simplyequipped/tcpkissserver) von [simplyequipped](https://github.com/simplyequipped) verwenden
.

Diese umfassende Unterstützung und Flexibilität ist zwar sehr nützlich,
doch angesichts der Fülle an Optionen kann es manchmal schwierig sein,
zu wissen, wo man anfangen soll, insbesondere wenn man bei Null anfängt.

In diesem Kapitel werden einige verschiedene sinnvolle Einstiegspfade
beschrieben, um mit minimalem Aufwand und Kosten eine funktionsfähige
drahtlose Kommunikation in der Praxis zum Laufen zu bringen. Dabei
werden zwei grundlegende Gerätekategorien
behandelt: **RNodes** und **WiFi-basierte Funkgeräte** . Darüber hinaus
werden weitere gängige Optionen kurz beschrieben.

Wenn man weiß, wie man nur wenige unterschiedliche Hardwaretypen
einsetzt, kann man mit geringem Aufwand eine breite Palette nützlicher
Netzwerke aufbauen.

## Kombinieren von Hardwaretypen 

Beim Entwerfen und Aufbauen eines Netzwerks ist es sinnvoll,
verschiedene Verbindungs- und Hardwaretypen zu kombinieren. Ein
nützliches Entwurfsmuster besteht darin, hochleistungsfähige
Punkt-zu-Punkt-Verbindungen auf Basis von WLAN oder Millimeterwellenfunk
(mit hochverstärkenden Richtantennen) für das Netzwerk-Backbone zu
verwenden und LoRa-basierte RNodes zu verwenden, um große Bereiche mit
Konnektivität für Client-Geräte abzudecken.

## <span id="anchor"></span>RNode 

Zuverlässige und universelle digitale Funk-Transceiversysteme mit großer
Reichweite sind üblicherweise entweder sehr teuer, schwierig
einzurichten und zu bedienen, schwer zu beschaffen, verbrauchen viel
Strom oder alles davon gleichzeitig. Um diese Situation zu verbessern,
wurde das Transceiversystem *RNode* entwickelt. Es ist wichtig zu
beachten, dass RNode kein bestimmtes Gerät eines bestimmten Anbieters
ist, sondern *eine offene Plattform* , mit der jeder interoperable
digitale Transceiver bauen kann, die seinen Anforderungen und besonderen
Situationen entsprechen.

Ein RNode ist ein universell einsetzbares, interoperables,
zuverlässiges, offenes und flexibles Funkkommunikationsgerät mit
geringem Stromverbrauch und großer Reichweite. Abhängig von seinen
Komponenten kann es auf vielen verschiedenen Frequenzbändern betrieben
werden und viele verschiedene Modulationsschemata verwenden. In der
Regel beschränken wir uns in diesem Kapitel jedoch auf RNodes,
die *LoRa-* Modulation in gängigen ISM-Bändern verwenden.

**Vermeiden Sie Verwirrung!** RNodes können LoRa als *Modulation auf
physikalischer Ebene* verwenden , aber es verwendet nicht
das *LoRaWAN* -Protokoll und den LoRaWAN-Standard, die üblicherweise für
zentral gesteuerte IoT-Geräte verwendet werden, und hat auch nichts
damit zu tun. RNodes verwenden *reine LoRa-Modulation* ohne zusätzlichen
Protokoll-Overhead. Alle Protokollfunktionen auf hoher Ebene werden
direkt von Reticulum gehandhabt.

### <span id="anchor-1"></span>RNodes erstellen 

RNode wurde als System konzipiert, das sich zeitlich und räumlich leicht
replizieren lässt. Sie können einen funktionierenden Transceiver mit
allgemein verfügbaren Komponenten und einigen Open-Source-Softwaretools
zusammenstellen. Sie können RNodes zwar komplett von Grund auf neu
entwerfen und bauen, und zwar genau nach Ihren gewünschten
Spezifikationen. In diesem Kapitel wird jedoch der einfachste Ansatz zum
Erstellen von RNodes erläutert: die Verwendung gängiger
LoRa-Entwicklungsboards. Dieser Ansatz lässt sich auf zwei einfache
Schritte reduzieren:

1.  Besorgen Sie sich ein oder mehrere unterstützte Entwicklungsboards
2.  Installieren Sie die RNode-Firmware mit dem automatisierten
    Installationsprogramm

Sobald die Firmware installiert und vom Installationsskript
bereitgestellt wurde, kann sie mit jeder Software verwendet werden, die
RNodes unterstützt, einschließlich Reticulum. Das Gerät kann mit
Reticulum verwendet werden, indem der Konfiguration ein [RNodeInterface
hinzugefügt
wird.](https://reticulum.network/manual/interfaces.html#interfaces-rnode)

### <span id="anchor-2"></span>Unterstützte Boards 

Um einen oder mehrere RNodes zu erstellen, benötigen Sie unterstützte
Entwicklungsboards. Die folgenden Boards werden vom Auto-Installer
unterstützt.

#### LilyGO LoRa32 v2.1 

- **Unterstützte Firmware-Linien** v1.x und v2.x
- **Transceiver-IC** Semtech SX1276
- **Geräteplattform** ESP32
- **Hersteller **[LilyGO](https://lilygo.cn/)

#### LilyGO LoRa32 v2.0 

- **Unterstützte Firmware-Linien** v1.x und v2.x
- **Transceiver-IC** Semtech SX1276
- **Geräteplattform** ESP32
- **Hersteller **[LilyGO](https://lilygo.cn/)

#### LilyGO T-Träger 

- **Unterstützte Firmware-Linien** v1.x und v2.x
- **Transceiver-IC** Semtech SX1276
- **Geräteplattform** ESP32
- **Hersteller **[LilyGO](https://lilygo.cn/)

#### Heltec LoRa32 v2.0 

- **Unterstützte Firmware-Linien** v1.x und v2.x
- **Transceiver-IC** Semtech SX1276
- **Geräteplattform** ESP32
- **Hersteller **[Heltec Automation](https://heltec.org/)

#### Nicht signierter RNode v2.x 

- **Unterstützte Firmware-Linien** v1.x und v2.x
- **Transceiver-IC** Semtech SX1276
- **Geräteplattform** ESP32
- **Hersteller **[unsigned.io](https://unsigned.io/)

#### Nicht signierter RNode v1.x 

- **Unterstützte Firmware-Linien** v1.x
- **Transceiver-IC** Semtech SX1276
- **Geräteplattform** AVR ATmega1284p
- **Hersteller **[unsigned.io](https://unsigned.io/)

### <span id="anchor-3"></span>Installationsnummer

Sobald Sie kompatible Karten erhalten haben, können Sie
die [RNode-Firmware](https://github.com/markqvist/RNode_Firmware) mit
dem [RNode-Konfigurationsprogramm](https://github.com/markqvist/rnodeconfigutil) installieren
. Wenn Sie Reticulum auf Ihrem System installiert
haben, **rnodeconf**ist das Programm bereits verfügbar. Wenn nicht,
stellen Sie sicher, dass **Python3**und **pip**auf Ihrem System
installiert ist, und installieren Sie Reticulum dann mit **pip**:

<span id="anchor-4"></span>pip install rns

Sobald die Installation abgeschlossen ist, können Sie mit der
Installation der Firmware auf Ihren Geräten beginnen. Führen Sie die
Installation **rnodeconf**im automatischen Installationsmodus wie folgt
aus:

<span id="anchor-5"></span>rnodeconf **--**autoinstall

Das Dienstprogramm führt Sie durch den Installationsvorgang, indem es
eine Reihe von Fragen zu Ihrer Hardware stellt. Folgen Sie einfach der
Anleitung und das Dienstprogramm installiert und konfiguriert Ihre
Geräte automatisch.

### <span id="anchor-6"></span>Verwendung mit Reticulum 

Wenn die Geräte installiert und bereitgestellt wurden, können Sie sie
mit Reticulum verwenden, indem Sie den [entsprechenden
Schnittstellenabschnitt](https://reticulum.network/manual/interfaces.html#interfaces-rnode) zur
Konfigurationsdatei von Reticulum hinzufügen. Für Firmware v1.x müssen
Sie alle Schnittstellenparameter angeben, wie z. B. serielle
Schnittstelle und On-Air-Parameter. Für Firmware v2.x müssen Sie nur die
Verbindungs-ID des RNode angeben, und Reticulum wird den RNode
automatisch finden und eine Verbindung zu ihm herstellen, wobei die im
RNode selbst gespeicherten Parameter verwendet werden.

## WiFi-basierte Hardware 

Es ist möglich, alle Arten von WLAN-basierter Hardware mit kurzer und
langer Reichweite mit Reticulum zu verwenden. Jede Art von Hardware, die
Bridged Ethernet über die WLAN-Schnittstelle vollständig unterstützt,
funktioniert mit
dem [AutoInterface](https://reticulum.network/manual/interfaces.html#interfaces-auto) in
Reticulum. Die meisten Geräte verhalten sich standardmäßig so oder
lassen es über Konfigurationsoptionen zu.

Das bedeutet, dass Sie einfach die physischen Verbindungen der
WiFi-basierten Geräte konfigurieren und mit Reticulum über sie
kommunizieren können. Es ist nicht notwendig, eine IP-Infrastruktur wie
DHCP-Server, DNS oder ähnliches zu aktivieren, solange mindestens
Ethernet verfügbar ist und Pakete transparent über die physischen
WiFi-basierten Geräte weitergeleitet werden.

 

Nachfolgend finden Sie eine Liste mit Beispielen für WiFi-Funkgeräte
(und ähnliche Funkgeräte), die sich gut für Reticulum-Verbindungen mit
hoher Kapazität über lange Distanzen eignen:

- [Ubiquiti
  airMAX-Radios](https://store.ui.com/collections/operator-airmax-devices)
- [Ubiquiti LTU-Radios](https://store.ui.com/collections/operator-ltu)
- [MikroTik-Radios](https://mikrotik.com/products/group/wireless-systems)

Diese Liste ist keineswegs vollständig und dient nur als Beispiel für
relativ günstige Funkhardware, die eine große Reichweite und hohe
Kapazität für Reticulum-Netzwerke bietet. Wie in allen anderen Fällen
ist es auch möglich, dass Reticulum mit gleichzeitig auf solchen Geräten
laufenden IP-Netzwerken koexistiert.

## Ethernet-basierte Hardware 

Reticulum kann auf jeder Art von Hardware ausgeführt werden, die ein
Switched Ethernet-basiertes Medium bereitstellen kann. Das bedeutet,
dass Reticulum alles von einem einfachen Ethernet-Switch über
Glasfasersysteme bis hin zu Datenfunkgeräten mit Ethernet-Schnittstellen
verwenden kann.

Für das Ethernet-Medium ist es nicht erforderlich, dass eine
IP-Infrastruktur wie DHCP-Server oder Routing eingerichtet ist. Falls
jedoch eine solche Infrastruktur vorhanden ist, wird Reticulum einfach
parallel dazu betrieben.

Um Reticulum über Ethernet-basierte Medien zu verwenden, reicht es im
Allgemeinen aus, das
enthaltene [AutoInterface](https://reticulum.network/manual/interfaces.html#interfaces-auto) zu
verwenden . Diese Schnittstelle funktioniert auch über jede Art von
virtuellem Netzwerkadapter, wie z. B. **tun**und **tap**Geräte in Linux.

## Serielle Leitungen und Geräte 

[Mit
SerialInterface](https://reticulum.network/manual/interfaces.html#interfaces-serial) ist
es auch möglich, Reticulum über jede Art von serieller Leitung zu
verwenden . Dieser Schnittstellentyp ist auch für die Verwendung von
Reticulum über Kommunikationshardware nützlich, die eine serielle
Schnittstelle bereitstellt.

## Packet Radio Modems 

Jedes Packet-Radio-Modem, das eine Standard-KISS-Schnittstelle über USB,
seriell oder TCP bereitstellt, kann mit Reticulum verwendet werden. Dazu
gehören virtuelle Softwaremodems wie [FreeDV
TNC](https://github.com/xssfox/freedv-tnc) und [Dire
Wolf](https://github.com/wb2osz/direwolf) .
